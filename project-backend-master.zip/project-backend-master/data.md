```javascript
let data = {
    // TODO: insert your data structure that contains 
    // users + quizzes here

    user_details : 
        {
            userId: 1,
            name: 'Jar Jar Brinks',
            email: 'mesasosorry@naboo.com.au',
            password: 'testing123'
            numSuccessfulLogins: 3,
            numFailedPasswordsSinceLastLogin: 1,
        },
}
```

[Optional] short description: 
