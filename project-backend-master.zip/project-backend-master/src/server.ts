import express, { json, Request, Response } from 'express';
import { echo } from './newecho';
import morgan from 'morgan';
import config from './config.json';
import cors from 'cors';
import YAML from 'yaml';
import sui from 'swagger-ui-express';
import fs from 'fs';
import path from 'path';
import process from 'process';
import { getData, setData, Quiz, User } from './dataStore';
import {
  ERR_INVALID_TOKEN,
  ERR_INVALID_USER_AUTHORISATION,
  ERR_INVALID_NAME,
  ERR_NAME_LESS,
  ERR_NAME_MORE,
  ERR_NAME_IS_USED,
  ERR_ID_IVALID,
  ERR_NP_NEG,
  ERR_NP_MORE_N,
  ERR_NEWOLDPOS_SAME,
  ERR_INVALID_QID,
  ERR_QUIZ_IS_USED,
  ERR_QUIZ_NOT_IN_TRASH,
  ERR_EMAIL_USED_AUDU,
  ERR_EMAIL_VALIDATOR_AUDU,
  ERR_NAMEFIRST_INVALID_AUDU,
  ERR_NAMEFIRST_LESS_AUDU,
  ERR_NAMEFIRST_MORE_AUDU,
  ERR_NAMELAST_INVALID_AUDU,
  ERR_NAMELAST_LESS_AUDU,
  ERR_NAMELAST_MORE_AUDU,
  ERR_LESS_QUESTION,
  ERR_MORE_QUESTION,
  ERR_LESS_ANS,
  ERR_MORE_ANS,
  ERR_NOT_POS_DURATON,
  ERR_SUM_DUR_MORE,
  ERR_LESS_POINT,
  ERR_MORE_POINT,
  ERR_LESS_CHAR_ANS,
  ERR_MORE_CHAR_ANS,
  ERR_ANS_DUPLICATE,
  ERR_NO_CORRECT_ANS,
  ERR_USEREMAIL_INVALID,
  ERR_USEREMAIL_CURRENT_LOGGED,
  ERR_USER_NOT_EXIST,
  ERR_QUIZID_USED_QUIZ_NAME,
  ERR_NOT_OWNED_QUIZ,
  ERR_OLD_PASSWORD_INCORRECT,
  ERR_OLD_PASSWORD_MATCH,
  ERR_NEW_PASSWORD_USED,
  ERR_NEW_PASSWORD_SHORT,
  ERR_NEW_PASSWORD_LET,
   ERR_NEW_PASSWORD_NUM

} from './error';
import { clear } from './other';
import {
  adminQuizCreate,
  adminQuizList,
  // adminQuizRemove,
  adminQuizNameUpdate,
  adminQuizDescriptionUpdate,
  // adminQuizRestore,
  adminQuizQuestionDuplicate,
  adminQuizQuestionUpdate,
  adminQuizQuestionDelete,
  adminQuizMoveQuestion,
  isCurrentLoggedInUser,
  deleteQuizzes,
  adminQuizCreateQuestion,
  adminGetQuizTrash,
  adminQuizTrashEmpty,
  transferQuizOwnership
} from './quiz';
import {
  adminAuthRegister,
  adminAuthLogin,
  adminUserDetailsUpdate,
  adminUserDetails,
  adminAuthLogout,
  adminUserPasswordUpdate,
  decodeToken
} from './auth';

import { adminQuizInfo, adminQuizRemove, adminQuizRestore } from './getQuizInfo';
// Set up web app
const app = express();
// Use middleware that allows us to access the JSON body of requests
app.use(json());
// Use middleware that allows for access from other domains
app.use(cors());
// for logging errors (print to terminal)
app.use(morgan('dev'));
// for producing the docs that define the API
const file = fs.readFileSync(path.join(process.cwd(), 'swagger.yaml'), 'utf8');
app.get('/', (req: Request, res: Response) => res.redirect('/docs'));
app.use('/docs', sui.serve, sui.setup(YAML.parse(file), { swaggerOptions: { docExpansion: config.expandDocs ? 'full' : 'list' } }));

const PORT: number = parseInt(process.env.PORT || config.port);
const HOST: string = process.env.IP || 'localhost';

// ====================================================================
//  ================= WORK IS DONE BELOW THIS LINE ===================
// ====================================================================

// Example get request
app.get('/echo', (req: Request, res: Response) => {
  const data = req.query.echo as string;
  const ret = echo(data);
  if ('error' in ret) {
    res.status(400);
  }
  return res.json(ret);
});

app.post('/v1/admin/auth/register', (req: Request, rest: Response) => {
  const { email, password, nameFirst, nameLast } = req.body as { email: string; password: string; nameFirst: string, nameLast: string };
  console.log(`email: ${email}, nameFirst: ${nameFirst}`);
  const result = adminAuthRegister(email, password, nameFirst, nameLast);
  if (result.error) {
    console.log(result.error);
    return rest.status(400).json({ error: result.error });
  } else {
    console.log(result.token);
    return rest.status(200).json({ token: result.token });
  }
});

app.post('/v1/admin/auth/login', (req: Request, res: Response) => {
  const { email, password } = req.body as string;
  const result = adminAuthLogin(email, password);

  if (result.error) {
    return res.status(400).json(result.error);
  } else {
    return res.json(result.token);
  }
});

app.get('/v1/admin/user/details', (req: Request, res: Response) => {
  const { token } = req.query;
  const authUserId = decodeToken(token);
  console.log(`id: ${authUserId}`);
  const result = adminUserDetails(authUserId);
  console.log(result);
  if (result.error) {
    return res.status(401).json(ERR_INVALID_TOKEN);
  } else {
    return res.status(200).json(result);
  }
});

app.get('/v1/admin/quiz/list', (req: Request, res: Response) => {
  const token = req.query.token as string;

  const result = adminQuizList(token);
  if (result.error) {
    console.log(result.error);
    return res.status(401).json(ERR_INVALID_TOKEN);
  } else {
    res.status(200).json(result);
  }
});

app.post('/v1/admin/quiz', (req: Request, res: Response) => {
  const { token, name, description } = req.body as {
    token: string;
    name: string;
    description: string;
  };

  const result = adminQuizCreate(token, name, description);

  console.log(result);

  if (result.error) {
    res.status(result.statusCode).json({ error: result.error });
  } else {
    res.status(200).json(result);
  }
});

app.delete('/v1/admin/quiz/:quizId', (req: Request, res: Response) => {
  const quizId = parseInt(req.params.quizId);
  const token = req.query.token as string;

  if (!token) {
    return res.status(401).json(ERR_INVALID_TOKEN);
  }

  const authUserId = decodeToken(token);

  const result = adminQuizRemove(authUserId, quizId);

  if ('error' in result) {
    if (result.error === 'Invalid token') {
      return res.status(401).json({ ERR_INVALID_TOKEN });

    // change
    } else if (result.error === 'AuthUserId is not a valid user' || result.error === 'Quiz ID does not refer to a valid quiz' || result.error === 'User does not own this quiz') {
      return res.status(403).json({ ERR_INVALID_USER_AUTHORISATION });
    }
  } else {
    return res.status(200).json(result);
  }
});

app.get('/v1/admin/quiz/:quizid', (req: Request, res: Response) => {
  const quizId = parseInt(req.params.quizid);
  const token = req.query.token;

  console.log(token);

  if (!token) {
    return res.status(401).json(ERR_INVALID_TOKEN);
  }

  const result = adminQuizInfo(token, quizId);

  if ('error' in result) {
    if (result.error === 'Invalid token') {
      return res.status(401).json(ERR_INVALID_TOKEN);
      // change
    } else if (result.error === 'AuthUserId is not a valid user' || result.error === 'Quiz ID does not refer to a valid quiz' || result.error === 'User does not own this quiz') {
      return res.status(403).json(ERR_INVALID_USER_AUTHORISATION);
    }
  } else {
    return res.status(200).json(result);
  }
});

app.put('/v1/admin/quiz/:quizid/name', (req: Request, res: Response) => {
  const { name, token } = req.body;
  const { quizid } = parseInt(req.params.quizId);

  const authUserId = decodeToken(token);

  // check.

  res.json(adminQuizNameUpdate(token, name));
  if (!authUserId) {
    return res.status(401).json(ERR_INVALID_TOKEN);
  }
  const result = adminQuizNameUpdate(authUserId, quizid, name);
  if ('error' in result) {
    if (result.error === 'AuthUserId is not a valid user' || result.error === 'Quiz ID' +
            'does not refer to a valid quiz or a quiz that this user owns') {
      return res.status(403).json(ERR_INVALID_USER_AUTHORISATION);
    } else if (result.error === ERR_INVALID_NAME ||
            result.error === ERR_NAME_LESS ||
            result.error === ERR_NAME_MORE ||
            result.error === ERR_NAME_IS_USED) {
      res.status(400).json(result.error);
    }
  } else {
    res.json(result);
  }
});

app.put('/v1/admin/quiz/:quizid/description', (req: Request, res: Response) => {
  const quizId = parseInt(req.params.quizid, 10);
  const { token, description } = req.body;
  console.log(`quizId: ${quizId}`);
  const authUserId = decodeToken(token);
  console.log(`userID: ${authUserId}`);
  const result = adminQuizDescriptionUpdate(authUserId, quizId, description);

  if (!authUserId) {
    return res.status(401).json(ERR_INVALID_TOKEN);
  }

  // error 403 should be before error 400

  if (result.error) {
    if (result === 'Description is more than 100 characters') {
      return res.status(400).json(result.error);
    } else {
      return res.status(403).json(ERR_INVALID_USER_AUTHORISATION);
    }
  } else {
    return res.json(result);
  }
});

app.delete('/v1/clear', (req: Request, res: Response) => {
  res.json(clear());
});

// ITERATION 2 //

app.put('/v1/admin/user/details', (req: Request, res: Response) => {
  const { token, email, nameFirst, nameLast } = req.body as {
        token: string,
        email: string,
        nameFirst: string,
        nameLast: string
    };
  const authUserId = decodeToken(token);
  res.json(adminUserDetailsUpdate(token, email, nameFirst, nameLast));
  if (!authUserId) {
    return res.status(401).json({ ERR_INVALID_TOKEN });
  }
  const result = adminUserDetailsUpdate(token, email, nameFirst, nameLast);
  if ('error' in result) {
    if (result.error === ERR_EMAIL_USED_AUDU ||
        result.error === ERR_EMAIL_VALIDATOR_AUDU ||
        result.error === ERR_NAMEFIRST_INVALID_AUDU ||
        result.error === ERR_NAMEFIRST_LESS_AUDU ||
        result.error === ERR_NAMEFIRST_MORE_AUDU ||
        result.error === ERR_NAMELAST_INVALID_AUDU ||
        result.error === ERR_NAMELAST_LESS_AUDU ||
        result.error === ERR_NAMELAST_MORE_AUDU) {
      res.status(400).json(result.error);
    }
  } else {
    res.json(result);
  }
});

app.delete('/v1/admin/quiz/trash/empty', (req: Request, res: Response) => {
  const token = req.query.token as string;
  const quizIdsString = (req.query.quizIds as string[]);
  if (!quizIdsString) {
    return res.status(400).json({ error: 'empty ids!'} );
  }

  if (!token) {
    return res.status(401).json({ error: 'empty token!'} );
  }

  const quizIds = quizIdsString.map(quizId => parseInt(quizId));

  // convert token to authUserId
  res.json(adminQuizRemove(token, quizId));

  // error should be in order 401, 403 , 400

  if (!quizId) {
    return res.status(400).json({ error: 'One or more of the Quiz IDs is not currently in the trash' });
  }
  try {
    const quizIdsArray = JSON.parse(quizId);
    const result = deleteQuizzes({ token, quizId: quizIdsArray });
    return res.status(200).json(result);
  } catch (error: any) {
    if (error.message.includes('400')) {
      return res.status(400).json({ error: 'One or more of the Quiz IDs is not currently in the trash' });
    } else if (error.message.includes('401')) {
      return res.status(401).json({ error: 'Token is empty or invalid' });
    } else if (error.message.includes('403')) {
      return res.status(403).json({ error: 'Valid token is provided, but one or more of the Quiz IDs refers to a quiz that this current user does not own' });
    }
  }

  return res.json({});
});

app.post('/v1/admin/quiz/:quizId/question', (req: Request, res: Response) => {
  const { quizId } = parseInt(req.params.quizId);
  const { token, questionBody } = req.body as {
    token: string;
    questionBody: {
      question: string;
      duration: number;
      points: number;
      answers: { answer: string; correct: boolean }[];
    };
  };

  if (!token) {
    return res.status(401).json(ERR_INVALID_TOKEN);
  }

  const authUserId = decodeToken(token);
  const result = adminQuizCreateQuestion(authUserId, quizId, questionBody);

  if ('error' in result) {
    if (result.error === 'Invalid token') {
      return res.status(401).json({ ERR_INVALID_TOKEN });
    } else if (result.error === 'AuthUserId is not a valid user' || result.error === 'Quiz ID does not refer to a valid quiz' || result.error === 'User does not own this quiz') {
      return res.status(403).json({ ERR_INVALID_USER_AUTHORISATION });
    } else if (
      result.error === ERR_LESS_QUESTION ||
      result.error === ERR_MORE_QUESTION ||
      result.error === ERR_LESS_ANS ||
      result.error === ERR_MORE_ANS ||
      result.error === ERR_NOT_POS_DURATON ||
      result.error === ERR_SUM_DUR_MORE ||
      result.error === ERR_LESS_POINT ||
      result.error === ERR_MORE_POINT ||
      result.error === ERR_LESS_CHAR_ANS ||
      result.error === ERR_MORE_CHAR_ANS ||
      result.error === ERR_ANS_DUPLICATE ||
      result.error === ERR_NO_CORRECT_ANS
    ) {
      return res.status(400).json(result.error);
    }
  } else {
    return res.status(200).json(result);
  }
});

app.post('/v1/admin/quiz/:quizid/transfer', (req: Request, res: Response) => {
  const quizid = req.params.quizid;
  const { token, email } = req.body;

  // error should be 401, 403 nd then 400

  if (!decodeToken(token)) {
    return res.status(401).json({ ERR_INVALID_TOKEN });
  }
  if (!isRealUser(userEmail)) {
    return res.status(400).json({ ERR_USEREMAIL_INVALID });
  }
  if (isCurrentLoggedInUser(userEmail)) {
    return res.status(400).json({ ERR_USEREMAIL_CURRENT_LOGGED });
  }
  if (!isQuizOwner(token, quizid)) {
    return req.status(403).json({ ERR_USER_NOT_EXIST });
  }
  if (isQuizNameAlreadyUsed(userEmail, quizid)) {
    return res.status(400).json({ ERR_QUIZID_USED_QUIZ_NAME });
  }

  return res.status(200).json({});
});

app.post('/v1/admin/auth/logout', (req: Request, res: Response) => {
  const { token } = req.body;

  // repeated. name line 460 as authUserId. not good bc we will get marked down for code quality
  const authUserId = decodeToken(token);
  const result = adminAuthLogout(authUserId);

  if (result.error) {
    return res.status(401).json(result.error);
  } else {
    return res.json(result);
  }
});

app.put('/v1/admin/quiz/:quizid/question/:questionid', (req: Request, res: Response) => {
  const { quizid, questionid } = req.params;
  const { token, questionBody } = req.body;

  const authUserId = decodeToken(token);
  const result = adminQuizQuestionUpdate(authUserId, quizid, questionid, questionBody);

  if (result.error) {
    if (result === ERR_INVALID_TOKEN) {
      return res.status(401).json(ERR_INVALID_TOKEN);
    } else {
      return res.status(403).json(ERR_INVALID_USER_AUTHORISATION);
    }
  } else {
    res.status(200).json(result);
  }
});

app.delete('/v1/admin/quiz/:quizid/question/:questionid', (req: Request, res: Response) => {
  const { quizid, questionid } = req.params;
  const { token } = req.query;

  const authuserId = decodeToken(token);
  const result = adminQuizQuestionDelete(authUserId, quizid, questionid);

  if (result.error) {
    if (result === ERR_INVALID_TOKEN) {
      return res.status(401).json(result);
    } else {
      return res.status(403).json(result);
    }
  } else {
    res.status(200).json(result);
  }
});

// ur parameters should be, req: Request, res: Response

app.post('/v1/admin/quiz/:quizid/restore', (req, res) => {
  const { quizId, quizName } = req.params;
  const { token } = req.body;
  // const authUserId = decodeToken(token);
  // if (!authUserId) {
  //   return res.status(401).json(ERR_INVALID_TOKEN);
  // }
  // const result = adminQuizRestore(authUserId, quizId, quizName);
  const result = adminQuizRestore(token, quizId);

  if ('error' in result) {
    return res.status(result.statusCode).json({ error: result.error });
  }

  return res.json(result);

  // if ('error' in result) {
  //   if (result.error === 'AuthUserId is not a valid user' ||
  //       result.error === 'Quiz ID' +
  //       'does not refer to a valid quiz or a quiz that this user owns') {
  //     return res.status(403).json(ERR_INVALID_USER_AUTHORISATION);
  //   } else if (result.error === ERR_QUIZ_IS_USED || result.error === ERR_QUIZ_NOT_IN_TRASH) {
  //     res.status(400).json(result.error);
  //   }
  // } else {
  //   res.status(200).json(result);
  // }
});

// your param is wrong. should be. req: Request, res: Response
app.post('/v1/admin/quiz/:quizid/question/:questionid/duplicate', (req, res) => {
  const { quizId, questionId } = req.params;
  const { token } = req.body;
  const authUserId = decodeToken(token);
  if (!authUserId) {
    return res.status(401).json({ ERR_INVALID_TOKEN });
  }
  const result = adminQuizQuestionDuplicate(quizId, questionId);
  if ('error' in result) {
    if (result.error === 'AuthUserId is not a valid user' ||
        result.error === 'Quiz ID' +
        'does not refer to a valid quiz or a quiz that this user owns') {
      return res.status(403).json(ERR_INVALID_USER_AUTHORISATION);
    } else if (result.error === ERR_INVALID_QID) {
      res.status(400).json(result.error);
    }
  } else {
    res.status(200).json(result);
  }
});

export default app;

function isRealUser(userEmail: string): boolean {
  const data = getData();
  return data.users.some((user: User) => user.email === userEmail);
}

function isQuizOwner(token: string, quizid: string): boolean {
  const quizDatabase = getData();
  const user = decodeToken(token);

  if (!user) {
    return false;
  }

  const userQuizzes = quizDatabase.quizzes.filter((quiz: Quiz) => quiz.quizId === parseInt(quizid));

  if (!userQuizzes) {
    return false;
  }

  return userQuizzes.some((quiz: Quiz) => quiz.quizId === parseInt(quizid));
}

function isQuizNameAlreadyUsed(userEmail: string, quizid: string): boolean {
  const quizDatabase = getData();
  const userQuizzes = quizDatabase.quizzes.filter((quiz: Quiz) => quiz.quizId === parseInt(quizid));

  if (!userQuizzes) {
    return false;
  }

  const quiz = userQuizzes.find((q: Quiz) => q.quizId === parseInt(quizid));
  if (!quiz) {
    return false;
  }

  return userQuizzes.some((q: Quiz) => q.name === quiz.name && q.quizId !== parseInt(quizid));
}

// why is there implementation function here?

function transferQuizOwnership(quizid: string, userEmail: string): void {
  const quizDatabase = getData();
  const quiz = quizDatabase.quizzes.find((quiz: Quiz) => quiz.quizId === parseInt(quizid));

  if (quiz) {
    quizDatabase.quizzes = quizDatabase.quizzes.filter((quiz: Quiz) => quiz.quizId !== parseInt(quizid));
    quizDatabase.quizzes.push({ ...quiz, ownerEmail: userEmail });
  }

  setData(quizDatabase);
}

app.put('/v1/admin/quiz/:quizid/question/:questionid/move', (req: Request, res: Response) => {
  const { quizid, questionid } = req.params;
  const { token, newPosition } = req.body as {
    token: string;
    newPosition: number;
  };

  if (!token) {
    return res.status(401).json(ERR_INVALID_TOKEN);
  }

  const result = adminQuizMoveQuestion(quizid, questionid, token, newPosition);

  if ('error' in result) {
    if (result.error === 'Invalid token') {
      return res.status(401).json(ERR_INVALID_TOKEN);
    }

    if (result.error === 'AuthUserId is not a valid user' || result.error === 'Quiz ID does not refer to a valid quiz' || result.error === 'User does not own this quiz') {
      return res.status(403).json(ERR_INVALID_USER_AUTHORISATION);
    }

    if (result.error === 'Question Id does not refer to a valid question within this quiz') {
      return res.status(400).json(ERR_ID_IVALID);
    }

    if (result.error === 'NewPosition is less than 0') {
      return res.status(400).json(ERR_NP_NEG);
    }

    if (result.error === 'NewPosition is greater than n-1 where n is the number of questions') {
      return res.status(400).json(ERR_NP_MORE_N);
    }

    if (result.error === 'NewPosition is the position of the current question') {
      return res.status(400).json(ERR_NEWOLDPOS_SAME);
    }

    return res.status(400).json({ error: result.error });
  } else {
    return res.status(200).json(result);
  }
});

app.put('/v1/admin/user/password', (req: Request, res: Response) => {
  const { token, oldPassword, newPassword } = req.body as {
    token: string,
    oldPassword: string,
    newPassword: string
  };
  
  const authUserId = decodeToken(token);
  console.log(`userid: ${authUserId}`);
  
  if (!authUserId) {
    return res.status(401).json({ ERR_INVALID_TOKEN });
  }

  const result = adminUserPasswordUpdate(authUserId, oldPassword, newPassword);
  console.log(`result: ${result}`);
  if (result.error) {
    if (result.error === ERR_OLD_PASSWORD_INCORRECT ||
        result.error === ERR_OLD_PASSWORD_MATCH ||
        result.error === ERR_NEW_PASSWORD_USED ||
        result.error === ERR_NEW_PASSWORD_SHORT ||
        result.error === ERR_NEW_PASSWORD_LET ||
        result.error === ERR_NEW_PASSWORD_NUM) {
          return res.status(400).json(result.error);
    } 
  }else {
    res.json(result);
  }
});

app.get('/v1/admin/quiz/trash', (req: Request, res: Response) => {
  const { token } = req.body as string;
  const authUserId = decodeToken(token);

  if (!authUserId) {
    return res.status(401).json({ ERR_INVALID_TOKEN });
  }

  const result = adminGetQuizTrash(authUserId);

  if (result.error) {
    if (result.error === ERR_NOT_OWNED_QUIZ) {
      return res.status(403).json(result.error);
    }
  }

  return res.status(200).json(result);
});

// ====================================================================
//  ================= WORK IS DONE ABOVE THIS LINE ===================
// ====================================================================

app.use((req: Request, res: Response) => {
  const error = `
    404 Not found - This could be because:
      0. You have defined routes below (not above) this middleware in server.ts
      1. You have not implemented the route ${req.method} ${req.path}
      2. There is a typo in either your test or server, e.g. /posts/list in one
         and, incorrectly, /post/list in the other
      3. You are using ts-node (instead of ts-node-dev) to start your server and
         have forgotten to manually restart to load the new changes
      4. You've forgotten a leading slash (/), e.g. you have posts/list instead
         of /posts/list in your server.ts or test file
  `;
  res.status(404).json({ error });
});

// start server
const server = app.listen(PORT, HOST, () => {
  // DO NOT CHANGE THIS LINE
  console.log(`⚡️ Server started on port ${PORT} at ${HOST}`);
});

// For coverage, handle Ctrl+C gracefully
process.on('SIGINT', () => {
  server.close(() => console.log('Shutting down server gracefully.'));
});
