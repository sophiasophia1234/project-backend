import { User, Quiz } from './datastore';

/**
 * Finds a user using the user ID that was inputted.
 *
 * @param {User[]} users - An array of users.
 * @param {number} authUserId - The ID of the user to find.
 *
 * @returns {User | null} - The user object if found, otherwise null.
 */
export function findUserById(users: User[], authUserId: number): User | null {
  for (let i = 0; i < users.length; i++) {
    if (users[i].authUserId === authUserId) {
      return users[i];
    }
  }
  return null;
}

/**
 * Finds a quiz using quiz ID in the quizzes array from the array of users.
 *
 * @param {Quiz[]} quizzes - An array of quizzes.
 * @param {number} quizId - The ID of the quiz to find.
 *
 * @returns {Quiz | null} - The quiz object if found, otherwise null.
 */
export function findQuizById(quizzes: Quiz[], quizId: number): Quiz | null {
  for (let i = 0; i < quizzes.length; i++) {
    if (quizzes[i].quizId === quizId) {
      return quizzes[i];
    }
  }
  return null;
}

/**
 * Helper function to check if a quiz is null.
 *
 * @param {Quiz[]} quizzes - An array of quizzes.
 * @param {number} quizId - The ID of the quiz to check.
 *
 * @returns {boolean} - Returns true if the quiz is null, otherwise false.
 */
export function isQuizNull(quizzes: Quiz[], quizId: number): boolean {
  const quiz = findQuizById(quizzes, quizId);
  return quiz === null;
}
