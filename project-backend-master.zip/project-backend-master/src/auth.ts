import { getData, setData, User } from './dataStore';
import validator from 'validator';
import { findUserById } from './helperFunctions';

/**
 * Registers a new admin user with the provided email, password,
 * first name, and last name.
 *
 * @param {string} email - The email address of the admin user.
 * @param {string} password - The password for the admin user.
 * @param {string} nameFirst - The first name of the admin user.
 * @param {string} nameLast - The last name of the admin user.
 *
 * @returns {{ authUserId: number }} - Returns { authUserId: number } if
 * registration is successful.
 * @returns {string} token -  used to verify a user's identity.
 * @returns {{ error: string }} - Returns an error object if an issue is found.
 */

function adminAuthRegister(email: string, password: string, nameFirst: string, nameLast: string) {
  const data = getData();

  for (const user of data.users) {
    if (user.email === email) {
      return { error: 'Email already used' };
    }
  }

  if (!validator.isEmail(email)) {
    return { error: 'Email is not validated' };
  }
  if (!validator.matches(nameFirst, /^[-' a-zA-Z]+$/)) {
    return { error: 'First name contains invalid character' };
  }
  if (nameFirst.length < 2) {
    return { error: 'First Name is too short' };
  }
  if (nameFirst.length > 20) {
    return { error: 'First Name is too long' };
  }
  if (!validator.matches(nameLast, /^[-' a-zA-Z]+$/)) {
    return { error: 'Last Name has invalid characters' };
  }
  if (nameLast.length < 2) {
    return { error: 'Last Name is too short' };
  }
  if (nameLast.length > 20) {
    return { error: 'Last Name is too long' };
  }

  if (password.length < 8) {
    return { error: 'Password is too short' };
  }

  if (!containsLetter(password)) {
    return { error: 'Password does not contain at least one letter' };
  }

  if (!containsNumber(password)) {
    return { error: 'Password does not contain at least one number' };
  }

  data.users.push({
    authUserId: data.users.length,
    email: email,
    password: password,
    nameFirst: nameFirst,
    nameLast: nameLast,
    succesfulLogins: 1,
    failedLogins: 0,
    quizOwn: [],
    passwordLog: []
  });

  console.log(data.counter);
  const generateToken = createStringGenerator('secretToken', (data.counter)++);

  data.sessions.push({
    sessionId: generateToken, // tanya sophia
    authUserId: data.users.length - 1, // tanya yaran
    active: true
  });

  setData(data);

  return { token: generateToken };
}

/**
  * Authenticates an admin user based on their email and password and count
  * the total of succesful and failed logins.
  *
  * @param {string} email - The email address of the admin user
  *                         attempting to log in.
  * @param {string} password - The password provided by
  *                            the admin user.
  *
  * @returns {{ authUserId: number }} - Returns { authUserId: number }
  *                                     if login is successful.
  * @returns {{ error: string }} - Returns an error object
  *                                if an issue is found.
*/

function adminAuthLogin(email: string, password: string) {
  const data = getData();

  for (const user of data.users) {
    if (user.email === email) {
      if (user.password === password) {
        user.succesfulLogins++;
        user.failedLogins = 0;
        const generateToken = createStringGenerator('secretToken', ++(data.counter));
        setData(data);
        return {
          token: generateToken,
        };
      } else {
        user.failedLogins++;
        setData(data);
        return { error: 'Wrong password' };
      }
    }
  }
  return { error: 'Email does not exist' };
}

/**
 * Given details relating to a password change, update
 * the password of a logged in user.
 *
 * @param {number} authUserId - The ID of the user to update the password.
 * @param {string} oldPassword - The current password of the user.
 * @param {string} newPassword - The new password set by the user.
 *
 * @returns {{ error: string }} - Returns an error object if an issue is found.
 */

function adminUserPasswordUpdate(authUserId: number, oldPassword: string, newPassword: string) {
  const data = getData();

  if (newPassword.length < 8) {
    return { error: 'New password is too short' };
  }
  if (!containsLetter(newPassword)) {
    return { error: 'New password does not contain at least one letter' };
  }

  if (!containsNumber(newPassword)) {
    return { error: 'New password does not contain at least one number' };
  }
  if (oldPassword === newPassword) {
    return { error: 'Old Password and New Password match exactly' };
  }

  const user = data.users.find(user => user.id === authUserId);
  if (!user || user.password !== oldPassword) {
    return { error: 'Old password is incorrect' };
  }
  if (user.passwordLog.includes(newPassword)) {
    return { error: 'New Password has already been used before' };
  }

  user.password = newPassword;
  user.passwordLog.push(newPassword);
  setData(data);

  return {};
}

/**
 * Updates the details of an admin user.
 *
 * @param {number} authUserId - The ID of the authenticated user
 *                              requesting the update.
 * @param {string} email - The new email address for the user.
 * @param {string} nameFirst - The new first name for the user.
 * @param {string} nameLast - The new last name for the user.
 *
 * @returns {{ error: string }} - Returns an error object if an issue is found.
 * @returns {{}} - Returns an empty object if there are no issue found.
 */
function adminUserDetailsUpdate(authUserId: number, email: string, nameFirst: string, nameLast: string) {
  const data = getData();

  for (const user of data.users) {
    if (user.email === email && user.id !== authUserId) {
      return { error: 'Email already used' };
    }
  }

  if (!validator.isEmail(email)) {
    return { error: 'Invalid email' };
  }
  if (!validator.matches(nameFirst, /^[-' a-zA-Z]+$/)) {
    return { error: 'First name contains special character' };
  }
  if (nameFirst.length < 2) {
    return { error: 'First Name is too short' };
  }
  if (nameFirst.length > 20) {
    return { error: 'First Name is too long' };
  }
  if (!validator.matches(nameLast, /^[-' a-zA-Z]+$/)) {
    return { error: 'Last name contains special characters' };
  }
  if (nameLast.length < 2) {
    return { error: 'Last Name is too short' };
  }
  if (nameLast.length > 20) {
    return { error: 'Last Name is too long' };
  }

  const user = data.users.find(user => user.id === authUserId);
  if (user) {
    user.email = email;
    user.nameFirst = nameFirst;
    user.nameLast = nameLast;
    setData(data);
  } else {
    return { error: 'AuthUserId is not a valid user' };
  }

  return {};
}

/**
 * Retrieves details of an admin user based on the provided
 * authentication user ID.
 *
 * @param {number} authUserId - The ID of the authentication user.
 *
 * @returns {User = {
 *       id: number;
 *       email: string;
 *       password: string;
 *       nameFirst: string;
 *       nameLast: string;
 *       succesfulLogins: number;
 *       failedLogins: number;
 *       quizOwn: Quiz[];
 *       passwordLog: string[];
 *   };
* }
 * - Returns if login is successful.
 * @returns {{ error: string }} - Returns an error object if an issue is found.
*/

function adminUserDetails(authUserId: number) {
  const data = getData();

  const user = findUserById(data.users, authUserId);
  console.log('find id result');
  
  console.log(user);
  if (!user) {
    return { error: 'AuthUserId is not a valid user' };
  }

  return {
    user:
      {
        authUserId: user.authUserId,
        name: user.nameFirst + ' ' + user.nameLast,
        email: user.email,
        numSuccessfulLogins: user.succesfulLogins,
        numFailedPasswordsSinceLastLogin: user.failedLogins,
      }
  };
}

function adminAuthLogout(authUserId: number) {
  const data = getData();

  // Find the index of the session with the given authUserId
  const sessionIndex = data.sessions.findIndex(session => session.authUserId === authUserId);

  if (sessionIndex !== -1) {
    // Remove the session from the array
    data.sessions.splice(sessionIndex, 1);
    setData(data);
    return {};
  }

  return { error: 'AuthUserId is not a valid user' };
}

/**
* Checks if the password contains any alphabetic letters.
*
* @param {string} password - The password string to be checked.
*
* @returns {boolean} - Returns true if the password contains at least
                       one alphabetic letter.
* @returns {boolean} - Returns false if the password does not
                       contain any alphabetic letters.
*/
function containsLetter(password: string): boolean {
  for (const character of password) {
    if (validator.isAlpha(character)) {
      return true;
    }
  }
  return false;
}
/**
  * Checks if the password contains any numeric digits.
  *
  * @param {string} password - The password string to be checked.
  *
  * @returns {boolean} - Returns true if the password contains
  *                      at least one numeric digit.
  * @returns {boolean} - Returns false if the password does not
  *                      contain any numeric digits.
*/
function containsNumber(password: string): boolean {
  for (const character of password) {
    if (validator.isNumeric(character)) {
      return true;
    }
  }
  return false;
}

// Find the owner of this session
function decodeToken(token) {
  const data = getData();
  for (const userId of data.sessions) {
    if (userId.sessionId === token) {
      return userId.authUserId;
    }
  }

  return null;
}

function createStringGenerator(baseString: string, counter: number) {
  return `${baseString}${counter}`;
}

export {
  containsLetter,
  containsNumber,
  adminAuthRegister,
  adminAuthLogin,
  adminUserPasswordUpdate,
  adminUserDetailsUpdate,
  adminUserDetails,
  decodeToken,
  adminAuthLogout
};
