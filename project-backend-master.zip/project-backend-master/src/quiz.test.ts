import {
  adminQuizList,
  adminQuizCreate,
  adminQuizRemove,
  adminQuizInfo,
  adminQuizNameUpdate,
  adminQuizDescriptionUpdate,
  adminQuizQuestionDuplicate,
  adminQuizRestore,
  adminQuizQuestionCreate,
  adminQuizQuestionMove,
  adminQuizQuestionDelete,
  adminQuizQuestionUpdate,
  adminGetQuizTrash

} from './quiz';

import {
  adminAuthRegister,
  adminAuthLogin,
} from './auth';
import { getData, setData } from './dataStore';
import { clear } from './other';

describe('adminQuizList', () => {
  beforeEach(() => {
    setData({
      users: [{ authUserId: 1 }],
      quizzes: [{ name: 'food', authUserId: 1, id: 1 }],
    });
  });

  test('returns error if user does not exist', () => {
    expect(adminQuizList('99')).toEqual({ error: 'AuthUserId does not exist' });
    expect(adminQuizList('100')).toEqual({ error: 'AuthUserId does not exist' });
    expect(adminQuizList('101')).toEqual({ error: 'AuthUserId does not exist' });
  });

  test('successful', () => {
    expect(adminQuizList(1)).toEqual({
      quizzes: [
        {
          quizId: 1,
          name: 'food',
        },
      ],
    });
  });
});

describe('adminQuizCreate', () => {
  beforeEach(() => {
    setData({
      users: [{ authUserId: 1 }],
      quizzes: [{ name: 'food', authUserId: 1, id: 1 }]
    });
  });

  test('return error if user does not exist', () => {
    expect(adminQuizCreate(999, 'Countries', 'Quiz about diffrent flags of countries')).toEqual({ error: 'AuthUserId is not a valid user' });
  });

  test('returns error if quiz name contains invalid characters', () => {
    expect(adminQuizCreate(1, 'Foo&&d', 'Quiz about food from different ethnicities')).toEqual({ error: 'Name contains invalid characters' });
  });

  test('returns error if quiz name already exists for user', () => {
    expect(adminQuizCreate(1, 'food', 'Quiz about food from different ethnicities')).toEqual({ error: 'Name is already used by the current logged in user for another quiz' });
  });

  test('returns error if quiz name is too long or too short', () => {
    expect(adminQuizCreate(1, 'fo', 'Quiz about food from different ethnicities')).toEqual({ error: 'Name is either less than 3 characters long or more than 30 characters long' });
  });

  test('returns error if description is too long', () => {
    expect(adminQuizCreate(1, 'Countries', 'a'.repeat(101))).toEqual({ error: 'Description is more than 100 characters in length' });
  });

  test('successful', () => {
    expect(adminQuizCreate(1, 'Countries', 'Quiz about diffrent flags of countries')).toEqual({
      quizId: 2,
    });
  });
});

describe('adminQuizRemove test', () => {
  beforeEach(() => {
    setData({
      users: [
        {
          authUserId: 1,
          email: 'yaran@example.com',
          password: 'password',
          nameFirst: 'Yaran',
          nameLast: 'Smith',
          numSuccesfulLogins: 0,
          numFailedPasswordsSinceLastLogin: 0,
          quizOwn: [
            { quizId: 1, name: 'Countries', description: 'Quiz about different flags of countries', timeCreated: '31-05-2024', timeLastEdited: '1-06-2024', questions: [] },
            { quizId: 2, name: 'Food', description: 'Quiz about food from different ethnicities', timeCreated: '1-06-2024', timeLastEdited: '2-06-2024', questions: [] }
          ],
          passwordLog: []
        },
        {
          authUserId: 2,
          email: 'alghi@example.com',
          password: 'password',
          nameFirst: 'Alghi',
          nameLast: 'Jones',
          numSuccesfulLogins: 0,
          numFailedPasswordsSinceLastLogin: 0,
          quizOwn: [
            { quizId: 3, name: 'Colours', description: 'Quiz about different colours', timeCreated: '2-06-2024', timeLastEdited: '3-06-2024', questions: [] }
          ],
          passwordLog: []
        }
      ],
      quizzes: [
        { quizId: 1, name: 'Countries', description: 'Quiz about different flags of countries', timeCreated: '31-05-2024', timeLastEdited: '1-06-2024', questions: [] },
        { quizId: 2, name: 'Food', description: 'Quiz about food from different ethnicities', timeCreated: '1-06-2024', timeLastEdited: '2-06-2024', questions: [] },
        { quizId: 3, name: 'Colours', description: 'Quiz about different colours', timeCreated: '2-06-2024', timeLastEdited: '3-06-2024', questions: [] }
      ],
      quizTrash: [],
      sessions: []
    });
  });

  test('AuthUserId is not a valid user', () => {
    expect(adminQuizRemove('3', '1')).toEqual({ error: 'AuthUserId is not a valid user' });
  });

  test('Quiz ID does not refer to a valid quiz', () => {
    expect(adminQuizRemove('1', '4')).toStrictEqual({ error: 'Quiz ID does not refer to a valid quiz' });
  });

  test('Quiz ID does not refer to a quiz that this user owns', () => {
    expect(adminQuizRemove('1', '3')).toStrictEqual({ error: 'Quiz ID does not refer to a quiz that this user owns' });
  });

  test('should remove the quiz if user is valid and owns the quiz', () => {
    const returnData = adminQuizRemove('1', '1');
    const data = getData();
    const quizzes = data.quizzes;
    const users = data.users;
    let quizIdFound = false;
    let userOwnsQuiz = false;

    for (let i = 0; i < quizzes.length; i++) {
      if (quizzes[i].quizId === 1) {
        quizIdFound = true;
        break;
      }
    }

    for (let j = 0; j < users.length; j++) {
      if (users[j].authUserId === 1 && users[j].quizOwn.some(quiz => quiz.quizId === 1)) {
        userOwnsQuiz = true;
        break;
      }
    }

    expect(returnData).toEqual({});
    expect(quizIdFound).toBe(false);
    expect(userOwnsQuiz).toBe(false);
  });
});

describe('adminQuizInfo', () => {
  beforeEach(() => {
    setData({
      users: [
        {
          authUserId: 1,
          email: 'yaran@example.com',
          password: 'password',
          nameFirst: 'Yaran',
          nameLast: 'Smith',
          numSuccesfulLogins: 0,
          numFailedPasswordsSinceLastLogin: 0,
          quizOwn: [
            { quizId: 1, name: 'Countries', description: 'Quiz about different flags of countries', timeCreated: '31-05-2024', timeLastEdited: '1-06-2024', questions: [] },
            { quizId: 2, name: 'Food', description: 'Quiz about food from different ethnicities', timeCreated: '1-06-2024', timeLastEdited: '2-06-2024', questions: [] }
          ],
          passwordLog: []
        },
        {
          authUserId: 2,
          email: 'alghi@example.com',
          password: 'password',
          nameFirst: 'Alghi',
          nameLast: 'Jones',
          numSuccesfulLogins: 0,
          numFailedPasswordsSinceLastLogin: 0,
          quizOwn: [
            { quizId: 3, name: 'Colours', description: 'Quiz about different colours', timeCreated: '2-06-2024', timeLastEdited: '3-06-2024', questions: [] }
          ],
          passwordLog: []
        }
      ],
      quizzes: [
        { quizId: 1, name: 'Countries', description: 'Quiz about different flags of countries', timeCreated: '31-05-2024', timeLastEdited: '1-06-2024', questions: [] },
        { quizId: 2, name: 'Food', description: 'Quiz about food from different ethnicities', timeCreated: '1-06-2024', timeLastEdited: '2-06-2024', questions: [] },
        { quizId: 3, name: 'Colours', description: 'Quiz about different colours', timeCreated: '2-06-2024', timeLastEdited: '3-06-2024', questions: [] }
      ],
      quizTrash: [],
      sessions: []
    });
  });

  test('AuthUserId is not a valid user', () => {
    expect(adminQuizInfo('3', '1')).toEqual({ error: 'AuthUserId is not a valid user' });
  });

  test('Quiz ID does not refer to a valid quiz', () => {
    expect(adminQuizInfo('1', '4')).toStrictEqual({ error: 'Quiz ID does not refer to a valid quiz' });
  });

  test('Quiz ID does not refer to a quiz that this user owns', () => {
    expect(adminQuizInfo('1', '3')).toStrictEqual({ error: 'Quiz ID does not refer to a quiz that this user owns' });
  });

  test('Return quiz info if user is valid and owns the quiz', () => {
    expect(adminQuizInfo('1', '1')).toStrictEqual({
      quizId: 1,
      name: 'Countries',
      timeCreated: '31-05-2024',
      timeLastEdited: '1-06-2024',
      description: 'Quiz about different flags of countries',
      questions: []
    });
  });
});

describe('adminQuizNameUpdate', () => {
  beforeEach(() => {
    setData({
      users: [
        { authUserId: 1, name: 'Yaran', quizzes: [1, 2] },
        { authUserId: 2, name: 'Alghi', quizzes: [3] },
      ],
      quizzes: [
        { quizId: 1, name: 'Countries', timeCreated: '31-05-2024', timeLastEdited: '1-06-2024', description: 'Quiz about diffrent flags of countries' },
        { quizId: 2, name: 'Food', timeCreated: '1-06-2024', timeLastEdited: '2-06-2024', description: 'Quiz about food from different ethnicities' },
        { quizId: 3, name: 'Colours', timeCreated: '2-06-2024', timeLastEdited: '3-06-2024', description: 'Quiz about different colours' },
      ],
    });
  });

  test('invalid user ID checker', () => {
    const result = adminQuizNameUpdate(3, 1, 'New Quiz');
    expect(result).toEqual({ error: 'AuthUserId is not a valid user' });
  });

  test('invalid quiz ID checker', () => {
    const result = adminQuizNameUpdate(1, 99, 'New Quiz');
    expect(result).toEqual({ error: 'QUIZ ID is not valid' });
  });

  test('check quiz ownership', () => {
    const result = adminQuizNameUpdate(1, 3, 'New Quiz');
    expect(result).toEqual({ error: 'This quiz is owned by another user' });
  });

  test('invalid quiz name checker', () => {
    const result = adminQuizNameUpdate(1, 1, 'Invalid@Name!');
    expect(result).toEqual({ error: 'Name contains invalid characters' });
  });

  test('check wether name is too short', () => {
    const result = adminQuizNameUpdate(1, 1, 'Q');
    expect(result).toEqual({ error: 'Name is less than 3' });
  });

  test('check wether name is too long', () => {
    const result = adminQuizNameUpdate(1, 1, 'quizzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz 5');
    expect(result).toEqual({ error: 'Name is more than 30' });
  });

  test('name usage checker', () => {
    const result = adminQuizNameUpdate(1, 1, 'Food');
    expect(result).toEqual({ error: 'Name is already used by the current logged in user for another quiz' });
  });

  test('update quiz name if successful', () => {
    const result = adminQuizNameUpdate(2, 3, 'New Quiz');
    expect(result).toEqual({});
  });
});

describe('adminQuizDescriptionUpdate', () => {
  // beforeEach(() => {
  //   setData({
  //     users: [
  //       { authUserId: 1, name: 'Yaran', quizzes: [1, 2] },
  //       { authUserId: 2, name: 'Alghi', quizzes: [3] },
  //     ],
  //     quizzes: [
  //       { quizId: 1, name: 'Countries', timeCreated: '31-05-2024', timeLastEdited: '1-06-2024', description: 'Quiz about diffrent flags of countries' },
  //       { quizId: 2, name: 'Food', timeCreated: '1-06-2024', timeLastEdited: '2-06-2024', description: 'Quiz about food from different ethnicities' },
  //       { quizId: 3, name: 'Colours', timeCreated: '2-06-2024', timeLastEdited: '3-06-2024', description: 'Quiz about different colours' },
  //     ],
  //   });
  // });

  test('AuthUserId is not a valid user', () => {
    expect(adminQuizDescriptionUpdate(3, 1, 'Quiz about diffrent flags of countries in the world')).toEqual({ error: 'AuthUserId is not a valid user' });
  });

  test('Quiz ID does not refer to a valid quiz', () => {
    expect(adminQuizDescriptionUpdate(1, 4, 'Quiz about diffrent flags of countries in the world')).toStrictEqual({ error: 'Quiz ID does not refer to a valid quiz' });
  });

  test('Quiz ID does not refer to a quiz that this user owns', () => {
    expect(adminQuizDescriptionUpdate(1, 3, 'Quiz about diffrent flags of countries in the world')).toStrictEqual({ error: 'Quiz ID does not refer to a quiz that this user owns' });
  });

  test('Description is too long', () => {
    expect(adminQuizDescriptionUpdate(1, 1, 'a'.repeat(101))).toEqual({ error: 'Description is more than 100 characters' });
  });
});

describe('adminQuizRestore tests', () => {
  beforeEach(() => {
    // const register1 = adminAuthRegister(
    //   'sophia@gmail.com',
    //   '1234abcd',
    //   'Sophia',
    //   'Maghirang'
    // );

    // const register2 = adminAuthRegister(
    //   'sophia@gmail.com',
    //   '1234abcd',
    //   'Sophia',
    //   'Maghirang'
    // );
    // adminAuthLogin(
    //   'sophia@gmail.com',
    //   '1234abcd'
    // );

    // adminAuthLogin(
    //   'sophia@gmail.com',
    //   '1234abcd'
    // );

    // adminQuizCreate(authUserId1,
    //   'Countries',
    //   'Quiz about diffrent flags of countries'
    // );

    // adminQuizCreate(authUserId2,
    //   'Foods',
    //   'Quiz about diffrent foods'
    // );
    clear();
  });

  test('Restored quiz name is already used', () => {
    const register1: RegisterResponse = adminAuthRegister(
      'sophia@gmail.com',
      '1234abcdefgh',
      'Sophia',
      'Maghirang'
    );

    const register2: RegisterResponse = adminAuthRegister(
      'Alghi@gmail.com',
      '1234abcde',
      'Alghi',
      'Shaf'
    );
    adminAuthLogin(
      'sophia@gmail.com',
      '1234abcdefgh'
    );

    adminAuthLogin(
      'Alghi@gmail.com',
      '1234abcde'
    );

    // const authRegister1 = JSON.parse(register1.error);
    // const authUserId1 = authRegister1.authUserId;
    // const authRegister2 = JSON.parse(register2);
    // const authUserId2 = authRegister2.authUserId;
    const authUserId1 = register1.authUserId;
    const authUserId2 = register2.authUserId;

    const quizId1 = adminQuizCreate(authUserId1,
      'Countries',
      'Quiz about diffrent flags of countries'
    );

    adminQuizCreate(authUserId2,
      'Foods',
      'Quiz about diffrent foods'
    );

    const restoredQuiz = adminQuizRestore(authUserId1, quizId1.quizId, 'Foods');
    expect(restoredQuiz).toStrictEqual({
      error: 'Quiz name of the restored quiz is' +
      'already used by another active quiz'
    });
  });

  test('Quiz ID refers to a quiz that is not currently in the trash', () => {
    const register1 = adminAuthRegister(
      'sophia@gmail.com',
      '1234abcd',
      'Sophia',
      'Maghirang'
    );

    const register2 = adminAuthRegister(
      'sophia2@gmail.com',
      '1234abcde',
      'Sophia2',
      'Maghirang2'
    );
    adminAuthLogin(
      'sophia@gmail.com',
      '1234abcd'
    );

    adminAuthLogin(
      'sophia2@gmail.com',
      '1234abcde'
    );
    // const authRegister1 = JSON.parse(register1.body as string);
    // const authUserId1 = authRegister1.authUserId;
    // const authRegister2 = JSON.parse(register2.body as string);
    // const authUserId2 = authRegister2.authUserId;
    const authUserId1 = register1.authUserId.toString();
    const authUserId2 = register2.authUserId.toString();

    adminQuizCreate(authUserId1,
      'Countries',
      'Quiz about diffrent flags of countries'
    );

    const quizId2 = adminQuizCreate(authUserId2,
      'Foods',
      'Quiz about diffrent foods'
    );
    const restoredQuiz = adminQuizRestore(authUserId1, quizId2.quizId, 'Foods');
    expect(restoredQuiz).toStrictEqual({
      error: 'Quiz ID refers to a quiz that' +
      'is not currently in the trash'
    });
  });
  test('Quiz succesfully restored', () => {
    const register1 = adminAuthRegister(
      'sophia@gmail.com',
      '1234abcd',
      'Sophia',
      'Maghirang'
    );

    const register2 = adminAuthRegister(
      'sophia2@gmail.com',
      '1234abcde',
      'Sophia2',
      'Maghirang2'
    );
    adminAuthLogin(
      'sophia@gmail.com',
      '1234abcd'
    );

    adminAuthLogin(
      'sophia2@gmail.com',
      '1234abcde'
    );
    // const authRegister1 = JSON.parse(register1.body as string);
    // const authUserId1 = authRegister1.authUserId;
    // const authRegister2 = JSON.parse(register2.body as string);
    // const authUserId2 = authRegister2.authUserId;
    const authUserId1 = register1.authUserId.toString();
    const authUserId2 = register2.authUserId.toString();

    const quizId1 = adminQuizCreate(authUserId1,
      'Countries',
      'Quiz about diffrent flags of countries'
    );

    adminQuizCreate(authUserId2,
      'Foods',
      'Quiz about diffrent foods'
    );
    const restoredQuiz = adminQuizRestore(authUserId1, quizId1.quizId, 'Countries');
    expect(restoredQuiz).toStrictEqual({});
  });
});

describe('adminQuizQuestionDuplicate tests', () => {
  beforeEach(() => {
    // const register1 = adminAuthRegister(
    //   'sophia@gmail.com',
    //   '1234abcd',
    //   'Sophia',
    //   'Maghirang'
    // );

    // const register2 = adminAuthRegister(
    //   'sophia@gmail.com',
    //   '1234abcd',
    //   'Sophia',
    //   'Maghirang'
    // );

    // const login1 = adminAuthLogin(
    //   'sophia@gmail.com',
    //   '1234abcd'
    // );

    // const login2 = adminAuthLogin(
    //   'sophia@gmail.com',
    //   '1234abcd'
    // );

    // const authRegister1 = JSON.parse(register1.body as string);
    // const authUserId1 = authRegister1.authUserId;
    // const authRegister2 = JSON.parse(register2.body as string);
    // const authUserId2 = authRegister2.authUserId;

    // const createQuiz1 = adminQuizCreate(authUserId1,
    //   'Countries',
    //   'Quiz about diffrent flags of countries'
    // );

    // const createQuiz2 = adminQuizCreate(authUserId2,
    //   'Foods',
    //   'Quiz about diffrent foods'
    // );

    // const quiz1 = JSON.parse(createQuiz1.body as string);
    // const quizId1 = quiz1.quizId;
    // const quizName1 = quiz1.quizName;
    // const quiz2 = JSON.parse(createQuiz2.body as string);
    // const quizId2 = quiz1.quizId;
    // const quizName2 = quiz2.quizName;

    // const questionBody1 = {
    //   question: 'What is 1 + 1?',
    //   duration: 4,
    //   points: 5,
    //   answers: [
    //     {
    //       answer: '2',
    //       correct: true
    //     },
    //     {
    //       answer: '4',
    //       correct: false
    //     },
    //     {
    //       answer: '3',
    //       correct: false
    //     }
    //   ]
    // };

    // const questionBody2 = {
    //   question: 'What is 2 + 1?',
    //   duration: 4,
    //   points: 5,
    //   answers: [
    //     {
    //       answer: '3',
    //       correct: true
    //     },
    //     {
    //       answer: '4',
    //       correct: false
    //     },
    //     {
    //       answer: '2',
    //       correct: false
    //     }
    //   ]
    // };

    // const questionId1 = adminQuizCreate(authUserId1, quizId1, questionBody1);
    // const questionId2 = adminQuizCreate(authUserId1, quizId1, questionBody2);
  });

  afterEach(() => {
    clear();
  });

  test('Question Id does not refer to a valid question within this quiz', () => {
    const register1 = adminAuthRegister(
      'sophia@gmail.com',
      '1234abcd',
      'Sophia',
      'Maghirang'
    );

    const register2 = adminAuthRegister(
      'sophia@gmail.com',
      '1234abcd',
      'Sophia',
      'Maghirang'
    );

    adminAuthLogin(
      'sophia@gmail.com',
      '1234abcd'
    );

    adminAuthLogin(
      'sophia@gmail.com',
      '1234abcd'
    );

    // const authRegister1 = JSON.parse(register1.body as string);
    // const authUserId1 = authRegister1.authUserId;
    // const authRegister2 = JSON.parse(register2.body as string);
    // const authUserId2 = authRegister2.authUserId;
    const authUserId1 = register1.authUserId.toString();
    const authUserId2 = register2.authUserId.toString();

    const createQuiz1 = adminQuizCreate(authUserId1,
      'Countries',
      'Quiz about diffrent flags of countries'
    );

    const createQuiz2 = adminQuizCreate(authUserId2,
      'Foods',
      'Quiz about diffrent foods'
    );

    // const quiz1 = JSON.parse(createQuiz1.body as string);
    // const quizId1 = quiz1.quizId;
    // const quiz2 = JSON.parse(createQuiz2.body as string);
    // const quizId2 = quiz2.quizId;
    const quizId1 = createQuiz1.quizId;
    const quizId2 = createQuiz2.quizId;

    const questionBody1 = {
      question: 'What is 1 + 1?',
      duration: 4,
      points: 5,
      answers: [
        {
          answer: '2',
          correct: true
        },
        {
          answer: '4',
          correct: false
        },
        {
          answer: '3',
          correct: false
        }
      ]
    };

    const questionBody2 = {
      question: 'What is 2 + 1?',
      duration: 4,
      points: 5,
      answers: [
        {
          answer: '3',
          correct: true
        },
        {
          answer: '4',
          correct: false
        },
        {
          answer: '2',
          correct: false
        }
      ]
    };
    const numAuthUserId1 = parseInt(authUserId1);
    adminQuizQuestionCreate(authUserId1, quizId1.toString(), questionBody1.toString());
    const questionId2 = adminQuizQuestionCreate(authUserId2, quizId2.toString(), questionBody2.toString());
    const duplicatedQuiz = adminQuizQuestionDuplicate(numAuthUserId1, quizId1, questionId2);
    expect(duplicatedQuiz).toStrictEqual({
      error: 'Question Id does not refer to a' +
        'valid question within this quiz'
    });
  });

  test('Quiz successfully duplicated', () => {
    const register1 = adminAuthRegister(
      'sophia@gmail.com',
      '1234abcd',
      'Sophia',
      'Maghirang'
    );

    const register2 = adminAuthRegister(
      'sophia@gmail.com',
      '1234abcd',
      'Sophia',
      'Maghirang'
    );

    adminAuthLogin(
      'sophia@gmail.com',
      '1234abcd'
    );

    adminAuthLogin(
      'sophia@gmail.com',
      '1234abcd'
    );

    // const authRegister1 = JSON.parse(register1.body as string);
    // const authUserId1 = authRegister1.authUserId;
    // const authRegister2 = JSON.parse(register2.body as string);
    // const authUserId2 = authRegister2.authUserId;
    const authUserId1 = register1.authUserId.toString();
    const authUserId2 = register2.authUserId.toString();

    const createQuiz1 = adminQuizCreate(authUserId1,
      'Countries',
      'Quiz about diffrent flags of countries'
    );

    const createQuiz2 = adminQuizCreate(authUserId2,
      'Foods',
      'Quiz about diffrent foods'
    );

    // const quiz1 = JSON.parse(createQuiz1.body as string);
    // const quizId1 = quiz1.quizId;
    // const quiz2 = JSON.parse(createQuiz2.body as string);
    // const quizId2 = quiz2.quizId;
    const quizId1 = createQuiz1.quizId;
    const quizId2 = createQuiz2.quizId;

    const questionBody1 = {
      question: 'What is 1 + 1?',
      duration: 4,
      points: 5,
      answers: [
        {
          answer: '2',
          correct: true
        },
        {
          answer: '4',
          correct: false
        },
        {
          answer: '3',
          correct: false
        }
      ]
    };

    const questionBody2 = {
      question: 'What is 2 + 1?',
      duration: 4,
      points: 5,
      answers: [
        {
          answer: '3',
          correct: true
        },
        {
          answer: '4',
          correct: false
        },
        {
          answer: '2',
          correct: false
        }
      ]
    };

    const questionId1 = adminQuizCreate(authUserId1, quizId1, questionBody1);
    adminQuizQuestionCreate(authUserId2, quizId2.toString(), questionBody2);
    const duplicatedQuiz = adminQuizQuestionDuplicate(quizId1, questionId1);
    expect(duplicatedQuiz).toStrictEqual({ duplicatedQuiz });
  });
});

describe('adminQuizQuestionCreate', () => {
  let register: { authUserId: number };
  let quiz: { quizId: number };

  beforeEach(() => {
    register = adminAuthRegister('sop@gmail.com', 'testing123', 'Sophia', 'Maghirang');
    quiz = adminQuizCreate(register.authUserId, 'Quiz1', 'Description of quiz1');
  });

  test('should create a quiz question successfully', () => {
    const authUserId = register.authUserId;
    const quizId = quiz.quizId;
    const questionBody = {
      question: 'Who is the Monarch of England?',
      duration: 4,
      points: 5,
      answers: [
        { description: 'Prince Charles', correct: true },
        { description: 'Prince William', correct: false },
      ],
    };

    const result = adminQuizQuestionCreate(authUserId, quizId, questionBody);
    expect(result).toEqual({ questionId: expect.any(Number) });
  });

  test('should fail due to invalid user', () => {
    const invalidAuthUserId = 999; // Invalid user ID
    const quizId = quiz.quizId;
    const questionBody = {
      question: 'Who is the Monarch of England?',
      duration: 4,
      points: 5,
      answers: [
        { description: 'Prince Charles', correct: true },
        { description: 'Prince William', correct: false },
      ],
    };

    const result = adminQuizQuestionCreate(invalidAuthUserId, quizId, questionBody);
    expect(result).toEqual({ error: 'Invalid authUserId' });
  });

  test('should fail due to question length less than 5 characters', () => {
    const authUserId = register.authUserId;
    const quizId = quiz.quizId;
    const questionBody = {
      question: 'Who?',
      duration: 4,
      points: 5,
      answers: [
        { description: 'Prince Charles', correct: true },
        { description: 'Prince William', correct: false },
      ],
    };

    const result = adminQuizQuestionCreate(authUserId, quizId, questionBody);
    expect(result).toEqual({ error: 'Question string is less than 5 characters in length' });
  });

  test('should fail due to question length greater than 50 characters', () => {
    const authUserId = register.authUserId;
    const quizId = quiz.quizId;
    const questionBody = {
      question: 'Who is the Monarch of England and what is the capital of the country?',
      duration: 4,
      points: 5,
      answers: [
        { description: 'Prince Charles', correct: true },
        { description: 'Prince William', correct: false },
      ],
    };

    const result = adminQuizQuestionCreate(authUserId, quizId, questionBody);
    expect(result).toEqual({ error: 'Question string is greater than 50 characters in length' });
  });

  test('should fail due to less than 2 answers', () => {
    const authUserId = register.authUserId;
    const quizId = quiz.quizId;
    const questionBody = {
      question: 'Who is the Monarch of England?',
      duration: 4,
      points: 5,
      answers: [
        { description: 'Prince Charles', correct: true },
      ],
    };

    const result = adminQuizQuestionCreate(authUserId, quizId, questionBody);
    expect(result).toEqual({ error: 'The question has less than 2 answers' });
  });

  test('should fail due to more than 6 answers', () => {
    const authUserId = register.authUserId;
    const quizId = quiz.quizId;
    const questionBody = {
      question: 'Who is the Monarch of England?',
      duration: 4,
      points: 5,
      answers: [
        { description: 'Prince Charles', correct: true },
        { description: 'Prince William', correct: false },
        { description: 'Queen Elizabeth', correct: false },
        { description: 'Prince Harry', correct: false },
        { description: 'Prince Philip', correct: false },
        { description: 'Princess Diana', correct: false },
        { description: 'Prince George', correct: false },
      ],
    };

    const result = adminQuizQuestionCreate(authUserId, quizId, questionBody);
    expect(result).toEqual({ error: 'The question has more than 6 answers' });
  });

  test('should fail due to negative question duration', () => {
    const authUserId = register.authUserId;
    const quizId = quiz.quizId;
    const questionBody = {
      question: 'Who is the Monarch of England?',
      duration: -1,
      points: 5,
      answers: [
        { description: 'Prince Charles', correct: true },
        { description: 'Prince William', correct: false },
      ],
    };

    const result = adminQuizQuestionCreate(authUserId, quizId, questionBody);
    expect(result).toEqual({ error: 'The question duration is not a positive number' });
  });

  test('should fail due to excess sum of question duration', () => {
    const authUserId = register.authUserId;
    const quizId = quiz.quizId;
    const questionBody = {
      question: 'Who is the Monarch of England?',
      duration: 181,
      points: 5,
      answers: [
        { description: 'Prince Charles', correct: true },
        { description: 'Prince William', correct: false },
      ],
    };

    const result = adminQuizQuestionCreate(authUserId, quizId, questionBody);
    expect(result).toEqual({ error: 'The sum of the question durations in the quiz exceeds 3 minutes' });
  });

  test('should fail due to points less than 1', () => {
    const authUserId = register.authUserId;
    const quizId = quiz.quizId;
    const questionBody = {
      question: 'Who is the Monarch of England?',
      duration: 4,
      points: 0,
      answers: [
        { description: 'Prince Charles', correct: true },
        { description: 'Prince William', correct: false },
      ],
    };

    const result = adminQuizQuestionCreate(authUserId, quizId, questionBody);
    expect(result).toEqual({ error: 'The points awarded for the question are less than 1' });
  });

  test('should fail due to points more than 10', () => {
    const authUserId = register.authUserId;
    const quizId = quiz.quizId;
    const questionBody = {
      question: 'Who is the Monarch of England?',
      duration: 4,
      points: 11,
      answers: [
        { description: 'Prince Charles', correct: true },
        { description: 'Prince William', correct: false },
      ],
    };

    const result = adminQuizQuestionCreate(authUserId, quizId, questionBody);
    expect(result).toEqual({ error: 'The points awarded for the question are greater than 10' });
  });

  test('should fail due to answer string length less than 1 character', () => {
    const authUserId = register.authUserId;
    const quizId = quiz.quizId;
    const questionBody = {
      question: 'Who is the Monarch of England?',
      duration: 4,
      points: 5,
      answers: [
        { description: '', correct: true },
        { description: 'Prince William', correct: false },
      ],
    };

    const result = adminQuizQuestionCreate(authUserId, quizId, questionBody);
    expect(result).toEqual({ error: 'Answer string length invalid' });
  });

  test('should fail due to answer string length greater than 30 characters', () => {
    const authUserId = register.authUserId;
    const quizId = quiz.quizId;
    const questionBody = {
      question: 'Who is the Monarch of England?',
      duration: 4,
      points: 5,
      answers: [
        { description: 'Prince Charles, Prince of Wales and Duke of Cornwall', correct: true },
        { description: 'Prince William', correct: false },
      ],
    };

    const result = adminQuizQuestionCreate(authUserId, quizId, questionBody);
    expect(result).toEqual({ error: 'The length of any answer is longer than 30 characters long' });
  });

  test('should fail due to no correct answers', () => {
    const authUserId = register.authUserId;
    const quizId = quiz.quizId;
    const questionBody = {
      question: 'Who is the Monarch of England?',
      duration: 4,
      points: 5,
      answers: [
        { description: 'Prince Charles', correct: false },
        { description: 'Prince William', correct: false },
      ],
    };

    const result = adminQuizQuestionCreate(authUserId, quizId, questionBody);
    expect(result).toEqual({ error: 'There are no correct answers' });
  });
});

describe('adminQuizQuestionMove', () => {
  let authUserId: number;
  let quizId: number;
  let questionId1: number;

  beforeEach(() => {
    const register = adminAuthRegister('sop@gmail.com', 'testing123', 'Sophia', 'Maghirang');
    authUserId = register.authUserId;
    const quiz = adminQuizCreate(authUserId.toString(), 'Quiz1', 'Description of quiz1');
    quizId = quiz.quizId;

    const questionBody1 = {
      question: 'Who is the Monarch of England?',
      duration: 4,
      points: 5,
      answers: [
        { description: 'Prince Charles', correct: true },
        { description: 'Prince William', correct: false },
      ]
    };
    const question1 = adminQuizQuestionCreate(authUserId.toString(), quizId.toString(), questionBody1);
    questionId1 = question1.questionId;
  });

  test('should return error if quiz ID is invalid', () => {
    const result = adminQuizQuestionMove(authUserId.toString(), '10', questionId1.toString(), 1);
    expect(result).toEqual({ error: 'Quiz ID is invalid' });
  });

  test('should return error if question ID is invalid', () => {
    const result = adminQuizQuestionMove(authUserId.toString(), quizId.toString(), '999', 1); // Using an invalid questionId
    expect(result).toEqual({ error: 'Question Id does not refer to a valid question in this quiz.' });
  });

  test('should return error if new position is less than 0', () => {
    const result = adminQuizQuestionMove(authUserId.toString(), quizId.toString(), questionId1.toString(), -1);
    expect(result).toEqual({ error: 'NewPosition is less than 0' });
  });

  test('should return error if new position is greater than n-1 where n is the number of questions', () => {
    const result = adminQuizQuestionMove(authUserId.toString(), quizId.toString(), questionId1.toString(), 10);
    expect(result).toEqual({ error: 'NewPosition is greater than n-1 where n is the number of questions' });
  });

  test('should return error if new position is the same as the current position', () => {
    const result = adminQuizQuestionMove(authUserId.toString(), quizId.toString(), questionId1.toString(), 0); // Assuming current position is 0
    expect(result).toEqual({ error: 'NewPosition is the position of the current question' });
  });

  test('should return error if user does not own the quiz', () => {
    const anotherAuthUserId = 2;
    const result = adminQuizQuestionMove(anotherAuthUserId.toString(), quizId.toString(), questionId1.toString(), 1);
    expect(result).toEqual({ error: 'User does not own this quiz' });
  });

  test('should move question to new position successfully', () => {
    const result = adminQuizQuestionMove(authUserId.toString(), quizId.toString(), questionId1.toString(), 1);
    expect(result).toEqual({});
    const quiz = getData().quizzes.find(q => q.quizId === quizId);
    expect(quiz.questions[1].questionId).toBe(questionId1);
  });
});

describe('adminQuizQuestionUpdate', () => {
  let register: { authUserId: number, token: string };
  let createQuiz: { quizId: number };
  let createQuestion: { questionId: number };

  beforeEach(() => {
    register = adminAuthRegister('sop@gmail.com', 'testing123', 'Sophia', 'Maghirang') as { authUserId: number, token: string };
    createQuiz = adminQuizCreate(register.authUserId, 'Quiz1', 'Description of quiz1') as { quizId: number };
    const questionBody = {
      question: 'Who is the Monarch of England?',
      duration: 4,
      points: 5,
      answers: [
        { description: 'Prince Charles', correct: true },
        { description: 'Prince William', correct: false },
      ],
    };
    createQuestion = adminQuizQuestionCreate(register.authUserId, createQuiz.quizId, questionBody) as { questionId: number };
  });

  test('successfully update question', () => {
    const newQuestion = 'Who is the current Monarch of England?';
    const newDuration = 5;
    const newPoints = 6;
    const newAnswers = [
      { description: 'King Charles', correct: true },
      { description: 'Prince William', correct: false },
    ];

    const updateResult = adminQuizQuestionUpdate(register.authUserId, createQuiz.quizId, createQuestion.questionId, newQuestion, newDuration, newPoints, newAnswers);
    expect(updateResult).toEqual({});
  });

  test('authuserId is not valid', () => {
    const newQuestion = 'Who is the current Monarch of England?';
    const newDuration = 5;
    const newPoints = 6;
    const newAnswers = [
      { description: 'King Charles', correct: true },
      { description: 'Prince William', correct: false },
    ];
    const updateResult = adminQuizQuestionUpdate(99, createQuiz.quizId, createQuestion.questionId, newQuestion, newDuration, newPoints, newAnswers);
    expect(updateResult).toStrictEqual({ error: 'AuthUserId is not a valid user' });
  });

  test('quiz ID does not belong to this user', () => {
    const newQuestion = 'Who is the current Monarch of England?';
    const newDuration = 5;
    const newPoints = 6;
    const newAnswers = [
      { description: 'King Charles', correct: true },
      { description: 'Prince William', correct: false },
    ];
    const anotherRegister = adminAuthRegister('faren@gmail.com', '123testing', 'Faren', 'Lesmana') as { authUserId: number, token: string };
    const anotherQuiz = adminQuizCreate(anotherRegister.authUserId, 'Quiz2', 'Description of quiz2') as { quizId: number };
    const updateResult = adminQuizQuestionUpdate(register.authUserId, anotherQuiz.quizId, createQuestion.questionId, newQuestion, newDuration, newPoints, newAnswers);
    expect(updateResult).toStrictEqual({ error: 'Quiz ID does not refer to a quiz that this user owns' });
  });

  test('question string is less than 5 characters in length or greater than 50 characters in length', () => {
    const newQuestion = 'King';
    const newDuration = 5;
    const newPoints = 6;
    const newAnswers = [
      { description: 'King Charles', correct: true },
      { description: 'Prince William', correct: false },
    ];
    const updateResult = adminQuizQuestionUpdate(register.authUserId, createQuiz.quizId, createQuestion.questionId, newQuestion, newDuration, newPoints, newAnswers);
    expect(updateResult).toStrictEqual({ error: 'Question string is less than 5 characters in length or greater than 50 characters in length' });
  });

  test('the question has more than 6 answers or less than 2 answers', () => {
    const newQuestion = 'Who is the current Monarch of England?';
    const newDuration = 5;
    const newPoints = 6;
    const newAnswers = [{ description: 'King Charles', correct: true }];
    const updateResult = adminQuizQuestionUpdate(register.authUserId, createQuiz.quizId, createQuestion.questionId, newQuestion, newDuration, newPoints, newAnswers);
    expect(updateResult).toStrictEqual({ error: 'The question has more than 6 answers or less than 2 answers' });
  });

  test('the question duration is not a positive number', () => {
    const newQuestion = 'Who is the current Monarch of England?';
    const newDuration = 0;
    const newPoints = 6;
    const newAnswers = [
      { description: 'King Charles', correct: true },
      { description: 'Prince William', correct: false },
    ];
    const updateResult = adminQuizQuestionUpdate(register.authUserId, createQuiz.quizId, createQuestion.questionId, newQuestion, newDuration, newPoints, newAnswers);
    expect(updateResult).toStrictEqual({ error: 'The question duration is not a positive number' });
  });

  test('the sum of the question durations in the quiz exceeds 3 minutes', () => {
    const newQuestion = 'Who is the current Monarch of England?';
    const newDuration = 181;
    const newPoints = 6;
    const newAnswers = [
      { description: 'King Charles', correct: true },
      { description: 'Prince William', correct: false },
    ];
    const updateResult = adminQuizQuestionUpdate(register.authUserId, createQuiz.quizId, createQuestion.questionId, newQuestion, newDuration, newPoints, newAnswers);
    expect(updateResult).toStrictEqual({ error: 'If this question were to be updated, the sum of the question durations in the quiz exceeds 3 minutes' });
  });

  test('the points awarded for the question are less than 1 or greater than 10', () => {
    const newQuestion = 'Who is the current Monarch of England?';
    const newDuration = 5;
    const newPoints = 11;
    const newAnswers = [
      { description: 'King Charles', correct: true },
      { description: 'Prince William', correct: false },
    ];
    const updateResult = adminQuizQuestionUpdate(register.authUserId, createQuiz.quizId, createQuestion.questionId, newQuestion, newDuration, newPoints, newAnswers);
    expect(updateResult).toStrictEqual({ error: 'The points awarded for the question are less than 1 or greater than 10' });
  });

  test('the length of any answer is shorter than 1 character long, or longer than 30 characters long', () => {
    const newQuestion = 'Who is the current Monarch of England?';
    const newDuration = 5;
    const newPoints = 6;
    const newAnswers = [
      { description: '', correct: true },
      { description: 'Prince William', correct: false },
    ];
    const updateResult = adminQuizQuestionUpdate(register.authUserId, createQuiz.quizId, createQuestion.questionId, newQuestion, newDuration, newPoints, newAnswers);
    expect(updateResult).toStrictEqual({ error: 'The length of any answer is shorter than 1 character long, or longer than 30 characters long' });
  });

  test('any answer strings are duplicates of one another (within the same question)', () => {
    const newQuestion = 'Who is the current Monarch of England?';
    const newDuration = 5;
    const newPoints = 6;
    const newAnswers = [
      { description: 'King Charles', correct: true },
      { description: 'King Charles', correct: false },
    ];
    const updateResult = adminQuizQuestionUpdate(register.authUserId, createQuiz.quizId, createQuestion.questionId, newQuestion, newDuration, newPoints, newAnswers);
    expect(updateResult).toStrictEqual({ error: 'Any answer strings are duplicates of one another (within the same question)' });
  });

  test('there are no correct answers', () => {
    const newQuestion = 'Who is the current Monarch of England?';
    const newDuration = 5;
    const newPoints = 6;
    const newAnswers = [
      { description: 'King Charles', correct: false },
      { description: 'Prince William', correct: false },
    ];
    const updateResult = adminQuizQuestionUpdate(register.authUserId, createQuiz.quizId, createQuestion.questionId, newQuestion, newDuration, newPoints, newAnswers);
    expect(updateResult).toStrictEqual({ error: 'There are no correct answers' });
  });

  test('question ID does not refer to a valid question in this quiz', () => {
    const newQuestion = 'Who is the current Monarch of England?';
    const newDuration = 5;
    const newPoints = 6;
    const newAnswers = [
      { description: 'King Charles', correct: true },
      { description: 'Prince William', correct: false },
    ];
    const invalidQuestionId = -1;
    const updateResult = adminQuizQuestionUpdate(register.authUserId, createQuiz.quizId, invalidQuestionId, newQuestion, newDuration, newPoints, newAnswers);
    expect(updateResult).toStrictEqual({ error: 'Question ID does not refer to a valid question in this quiz' });
  });
});

describe('adminQuizQuestionDelete', () => {
  let register: number;
  let createQuiz: number;
  let createQuestion: number;

  beforeEach(() => {
    register = adminAuthRegister('sop@gmail.com', 'testing123', 'Sophia', 'Maghirang');
    createQuiz = adminQuizCreate(register.authUserId, 'Quiz1', 'Description of quiz1');
    const questionBody = {
      question: 'Who is the Monarch of England?',
      duration: 4,
      points: 5,
      answers: [
        { description: 'Prince Charles', correct: true },
        { description: 'Prince William', correct: false },
      ],
    };
    createQuestion = adminQuizQuestionCreate(register.authUserId, createQuiz.quizId, questionBody);
  });

  test('successfully delete question', () => {
    const deleteResult = adminQuizQuestionDelete(register.authUserId, createQuiz.quizId, createQuestion.questionId);
    expect(deleteResult).toEqual({});
  });

  test('authuserId is not valid', () => {
    const deleteResult = adminQuizQuestionDelete(99, createQuiz.quizId, createQuestion.questionId);
    expect(deleteResult).toStrictEqual({ error: 'AuthUserId is not a valid user' });
  });

  test('quiz ID not belongs to this user', () => {
    const deleteResult = adminQuizQuestionDelete(register.authUserId, 99, createQuestion.questionId);
    expect(deleteResult).toStrictEqual({ error: 'Quiz ID does not refer to a quiz that this user owns' });
  });

  test('Question ID does not refer to a valid question in this quiz', () => {
    const deleteResult = adminQuizQuestionDelete(register.authUserId, createQuiz.quizId, -1);
    expect(deleteResult).toStrictEqual({ error: 'Question ID does not refer to a valid question in this quiz' });
  });
});

describe('adminGetQuizTrash', () => {
  let register: any;
  let register2: any;
  let quiz: any;

  beforeEach(() => {
    register = adminAuthRegister('sop@gmail.com', 'testing123', 'Sophia', 'Maghirang');
    register2 = adminAuthRegister('faren@gmail.com', 'testing123', 'Faren', 'Raisya');
    quiz = adminQuizCreate(register.authUserId, 'Quiz1', 'Description of quiz1');
    adminQuizRemove(register.authUserId, quiz.quizId); // Removed the assignment to quizTrash
  });

  test('should return quizzes in the trash for a valid authUserId', () => {
    const result = adminGetQuizTrash(register.authUserId);
    expect(result).toEqual({
      quizzes: [
        { quizId: quiz.quizId, name: 'Quiz1' },
      ],
    });
  });

  test('should return error for invalid authUserId', () => {
    const result = adminGetQuizTrash(999);
    expect(result).toEqual({ error: 'Invalid authUserId' });
  });

  test('should return error if user is not an owner of any quiz in the trash', () => {
    const result = adminGetQuizTrash(register2.authUserId);
    expect(result).toEqual({ error: 'Valid authUserId is provided, but user is not an owner of this quiz' });
  });
});
