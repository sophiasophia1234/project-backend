
// error 401
const ERR_INVALID_TOKEN = 'AuthUserId is not a valid user';

// error 403
const ERR_INVALID_USER_AUTHORISATION = { error: 'User is not authorized to perform this action' };

// error 400 for adminQuizNameUpdate and others
const ERR_INVALID_NAME = { error: 'Name contains invalid characters' };
const ERR_NAME_LESS = { error: 'Name is less than 3' };
const ERR_NAME_MORE = { error: 'Name is more than 30' };
const ERR_NAME_IS_USED = {
  error: 'Name is already used by' +
    'the current logged in user'
};

// error 400 for adminAuthLogin
const ERR_INVALID_EMAIL = 'Email does not exist';
const ERR_INVALID_PASSWORD = 'Wrong password';

// error 400 for AQDU
const ERR_INVALID_DESCRIPTION = { error: 'Description is more than 100 characters' };

// error 400 for adminUserDetailsUpdate
const ERR_EMAIL_USED_AUDU = { error: 'Email already used' };
const ERR_EMAIL_VALIDATOR_AUDU = { error: 'Invalid email' };
const ERR_NAMEFIRST_INVALID_AUDU = { error: 'First name contains special character' };
const ERR_NAMEFIRST_LESS_AUDU = { error: 'First Name is too short' };
const ERR_NAMEFIRST_MORE_AUDU = { error: 'First Name is too long' };
const ERR_NAMELAST_INVALID_AUDU = { error: 'Last name contains special charactersr' };
const ERR_NAMELAST_LESS_AUDU = { error: 'Last Name is too short' };
const ERR_NAMELAST_MORE_AUDU = { error: 'Last Name is too long' };

// error 400 for adminQuizCreateQuestion

const ERR_LESS_QUESTION = { error: 'Question string is less than 5 characters in length' };
const ERR_MORE_QUESTION = { error: 'Question string is greater than 50 characters in length' };
const ERR_LESS_ANS = { error: 'The question has less than 2 answers' };
const ERR_MORE_ANS = { error: 'he question has more than 6 answers' };
const ERR_NOT_POS_DURATON = { error: 'The question duration is not a positive number' };
const ERR_SUM_DUR_MORE = { error: 'The sum of the question durations in the quiz exceeds 3 minutes' };
const ERR_LESS_POINT = { error: 'The points awarded for the question are less than 1' };
const ERR_MORE_POINT = { error: 'The points awarded for the question are greater than 10' };
const ERR_LESS_CHAR_ANS = { error: 'The length of any answer is shorter than 1 character long' };
const ERR_MORE_CHAR_ANS = { error: 'The length of any answer is longer than 30 characters long' };
const ERR_ANS_DUPLICATE = { error: 'Any answer strings are duplicates of one another (within the same question)' };
const ERR_NO_CORRECT_ANS = { error: 'There are no correct answers' };

// error 400 for adminQuizMoveQuestion
const ERR_ID_IVALID = { error: 'Question Id does not refer to a valid question within this quiz.' };
const ERR_NP_NEG = { error: 'NewPosition is less than 0' };
const ERR_NP_MORE_N = { error: 'NewPosition is greater than n-1 where n is the number of questions' };
const ERR_NEWOLDPOS_SAME = { error: 'NewPosition is the position of the current question' };
const ERR_NOT_OWNED_QUIZ = { error: 'User does not own the quiz' };

// error 400 for adminQuizQuestionDuplicate
const ERR_INVALID_QID = { error: 'Question is not valid' };

// error 400 for adminQuizQuestionRestore
const ERR_QUIZ_IS_USED = {
  error: 'Quiz name of the' +
    'restored quiz is already used'
};
const ERR_QUIZ_NOT_IN_TRASH = { error: 'Quiz is currently not in trash' };

// error 400 for adminUserPassUpdate
const ERR_OLD_PASSWORD_INCORRECT = { error: 'Old password is incorrect' };
const ERR_OLD_PASSWORD_MATCH = { error: 'Old Password and New Password match exactly' };
const ERR_NEW_PASSWORD_USED = { error: 'New Password has already been used before' };
const ERR_NEW_PASSWORD_SHORT = { error: 'New password is too short' };
const ERR_NEW_PASSWORD_NUM = { error: 'New password does not contain at least one number' };
const ERR_NEW_PASSWORD_LET = { error: 'New password does not contain at least one letter' };

export {
  ERR_INVALID_TOKEN,
  ERR_INVALID_USER_AUTHORISATION,
  ERR_INVALID_NAME,
  ERR_NAME_LESS,
  ERR_NAME_MORE,
  ERR_NAME_IS_USED,
  ERR_EMAIL_USED_AUDU,
  ERR_EMAIL_VALIDATOR_AUDU,
  ERR_NAMEFIRST_INVALID_AUDU,
  ERR_NAMEFIRST_LESS_AUDU,
  ERR_NAMEFIRST_MORE_AUDU,
  ERR_NAMELAST_INVALID_AUDU,
  ERR_NAMELAST_LESS_AUDU,
  ERR_NAMELAST_MORE_AUDU,
  ERR_LESS_QUESTION,
  ERR_MORE_QUESTION,
  ERR_LESS_ANS,
  ERR_MORE_ANS,
  ERR_NOT_POS_DURATON,
  ERR_SUM_DUR_MORE,
  ERR_LESS_POINT,
  ERR_MORE_POINT,
  ERR_LESS_CHAR_ANS,
  ERR_ANS_DUPLICATE,
  ERR_NO_CORRECT_ANS,
  ERR_ID_IVALID,
  ERR_NP_NEG,
  ERR_NP_MORE_N,
  ERR_MORE_CHAR_ANS,
  ERR_NEWOLDPOS_SAME,
  ERR_INVALID_QID,
  ERR_QUIZ_IS_USED,
  ERR_QUIZ_NOT_IN_TRASH,
  ERR_OLD_PASSWORD_INCORRECT,
  ERR_OLD_PASSWORD_MATCH,
  ERR_NEW_PASSWORD_USED,
  ERR_NEW_PASSWORD_SHORT,
  ERR_NEW_PASSWORD_LET,
  ERR_NEW_PASSWORD_NUM,
  ERR_NOT_OWNED_QUIZ,
  ERR_INVALID_EMAIL,
  ERR_INVALID_PASSWORD,
  ERR_INVALID_DESCRIPTION
};
