import { getData, setData, User, Quiz, Answer, TooKah, Question } from './dataStore';
import {
  decodeToken
} from './auth';
import {
  ERR_INVALID_TOKEN,
  ERR_USER_NOT_AUTHORIZED
} from './error';
import{
  isValidToken,
  isValidQuiz,
  isQuizOwner,
  hasQuizWithSameName
} from './errorCheckingHelpers'
/**
 * A list of quizzes that the admin owns
 *
 * @param { string } token
 * The unique identifier for the user whose quizzes are to be listed.
 *
 * @returns {quizzes: {quizId: number, name: string}}
 * Returns if login is successful.
 * @returns {{ error: string }} - Returns an error object if an issue is found.
 */
function adminQuizList(token: string) {
  const data = getData();

  console.log(token);
  console.log(data.sessions);

  const user = data.sessions.find(session => session.sessionId === token);

  if (!user) {
    return { error: 'AuthUserId does not exist' };
  } else {
    const authUserId = user.authUserId;
    const quizzes = data.quizzes.filter(quiz => quiz.authUserId === authUserId);
    console.log(quizzes);
    return {
      quizzes: quizzes.map(quiz => {
        return {
          quizId: quiz.quizId,
          name: quiz.name
        };
      })
    };
  }
}

/**
 * Creates a new quiz for a user identified by authUserId if the user exists,
 * the name is valid and not already used, and the description is of
 * acceptable length.
 *
 * @param {number} authUserId - The unique identifier of the user creating the
 * quiz.
 * @param {string} name - The name of the quiz; must be 3-30 characters long
 * and contain only alphanumeric characters and spaces.
 * @param {string} description - A brief description of the quiz; must not
 * exceed 100 characters in length.
 *
 * @returns {{ quizId: number }} - An object containing the quizId of the newly
 * created quiz.
 * @returns {{ error: string }} - Returns an error object if an issue is found.
 */
const adminQuizCreate = (token: string, name: string, description: string) => {
  const data = getData();

  const session = data.sessions.find(session => session.sessionId === token);

  if (!session) {
    return { error: 'AuthUserId is not a valid user', statusCode: 401 };
  }

  const checkName = /^[a-zA-Z0-9 ]+$/.test(name);
  if (checkName === false) {
    return { error: 'Name contains invalid characters', statusCode: 400 };
  }
  if (name.length < 3 || name.length > 30) {
    return {
      error: 'Name is either less than 3 characters long or more than 30' +
            ' characters long',
      statusCode: 400
    };
  }

  const quizName = data.quizzes.find(quiz =>
    quiz.name === name && quiz.authUserId === session.authUserId
  );

  if (quizName) {
    return {
      error: 'Name is already used by the current logged in user for' +
            ' another quiz',
      statusCode: 400
    };
  }
  if (description.length > 100) {
    return {
      error: 'Description is more than 100 characters in length',
      statusCode: 400
    };
  }

  const time = Date.now();

  data.quizzes.push({
    authUserId: session.authUserId,
    quizId: data.quizzes.length,
    name,
    timeCreated: time,
    timeLastEdited: time,
    description,
    numQuestions: 0,
    questions: [],
    duration: 0
  });
  setData(data);
  return { quizId: data.quizzes.length - 1 };
};

/**
 * Given a particular quiz, permanently remove the quiz.
 *
 * @param {number} authUserId - The ID of the user attempting to remove the quiz.
 * @param {number} quizId - The ID of the quiz to be removed.
 *
 * @returns {{}} - An empty object if the removal of the quiz is successful.
 * @returns {{error: string}} - Returns an error object if an issue is found.
 */
function adminQuizRemove(authUserId: number, quizId: number) {
  const data = getData();
  const user = findUserById(data.users, authUserId);
  const quiz = findQuizById(data.quizzes, quizId);

  if (!user) {
    return { error: 'AuthUserId is not a valid user' };
  }
  if (!quiz) {
    return { error: 'Quiz ID does not refer to a valid quiz' };
  }
  if (isQuizNull(data.quizzes, quizId)) {
    return { error: 'Quiz ID refers to a null quiz' };
  }
  if (!user.quizOwn.some(q => q.quizId === quizId)) {
    return { error: 'Quiz ID does not refer to a quiz that this user owns' };
  }

  data.quizTrash.push(quiz);
  data.quizzes[quizId].timeLastEdited = Date.now() / 1000;
  data.quizzes[quizId] = null;
  setData(data);

  return {};
}

/**
 * Get all of the relevant information about the current quiz.
 *
 * @param {number} authUserId - The ID of the user attempting to remove the quiz.
 * @param {number} quizId - The ID of the quiz to be removed.
 *
 * @returns {{ quizId: number, name: string, timeCreated: number, timeLastEdited: number, description: string }}
 * An object containing quiz information if the operation is successful.
 * @returns {{error: string}} - Returns an error object if an issue is found.
 */
function adminQuizInfo(authUserId: number, quizId: number) {
  const data = getData();
  const user = findUserById(data.users, authUserId);
  const quiz = findQuizById(data.quizzes, quizId);

  if (isQuizNull(data.quizzes, quizId)) {
    return { error: 'Quiz is in trash' };
  }

  if (!user) {
    return { error: 'AuthUserId is not a valid user' };
  }

  if (!quiz) {
    return { error: 'Quiz ID does not refer to a valid quiz' };
  }
  if (!user.quizOwn.some(q => q.quizId === quizId)) {
    return { error: 'Quiz ID does not refer to a quiz that this user owns' };
  }

  return {
    quizId: quiz.quizId,
    name: quiz.name,
    timeCreated: quiz.timeCreated,
    timeLastEdited: quiz.timeLastEdited,
    description: quiz.description,
    numQuestions: quiz.questions.length,
    questions: quiz.questions.map((question: Question) => ({
      questionId: question.questionId,
      question: question.question,
      duration: question.duration,
      points: question.points,
      answers: question.answers.map((answer: Answer) => ({
        answerId: answer.answerId,
        answer: answer.answer,
        colour: answer.colour,
        correct: answer.correct
      }))
    })),
    duration: quiz.duration
  };
}

/**
 * Updates the name of a quiz.
 *
 * @param {number} authUserId - The ID of the authenticated user requesting
 * the update.
 * @param {number} quizId - The ID of the quiz to be updated.
 * @param {string} name - The new name for the quiz.
 *
 * @returns {{}} - Returns an empty object if there are no errors.
 * @returns {{ error: string }} - Returns an error object if an issue is found.
 */

function adminQuizNameUpdate(authUserId: number, quizId: number, name: string) {
  const data = getData();
  const { users, quizzes } = data;

  const validity = isQuizIdValid(quizzes, quizId);
  if (validity === null) {
    return { error: 'QUIZ ID is not valid' };
  }

  let quizzesCheck = false;
  let usersCheck = false;
  for (let i = 0; i < users.length; i++) {
    if (authUserId === users[i].authUserId) {
      usersCheck = true;
      for (let j = 0; j < users[i].quizzes.length; j++) {
        if (quizId === users[i].quizzes[j]) {
          quizzesCheck = true;
        }
      }
    }
  }

  if (usersCheck === true && quizzesCheck === false) {
    return { error: 'This quiz is owned by another user' };
  }

  if (name.length < 3) {
    return { error: 'Name is less than 3' };
  } else if (name.length > 30) {
    return { error: 'Name is more than 30' };
  }

  let user: User | null = null;
  for (let i = 0; i < users.length; i++) {
    if (users[i].authUserId === authUserId) {
      user = users[i];
      break;
    }
  }

  if (user === null) {
    return { error: 'AuthUserId is not a valid user' };
  }

  let quiz = null;
  for (let i = 0; i < quizzes.length; i++) {
    if (quizzes[i].authUserId !== quizId &&
            quizzes[i].ownerId !== authUserId) {
      quiz = quizzes[i];
      break;
    }
  }

  if (quiz === null) {
    return {
      error: 'Quiz ID does not refer to a valid quiz or a quiz that this' +
            ' user owns'
    };
  }
  if (!/^[a-zA-Z0-9 ]+$/.test(name)) {
    return { error: 'Name contains invalid characters' };
  }

  let nameUsed = false;
  for (let i = 0; i < quizzes.length; i++) {
    if (quizzes[i].name === name) {
      nameUsed = true;
      break;
    }
  }

  if (nameUsed) {
    return {
      error: 'Name is already used by the current logged in user for' +
            ' another quiz'
    };
  }

  for (let i = 0; i < quizzes.length; i++) {
    if (quizId === quizzes[i].quizId) {
      quizzes[i].name = name;
      const today = new Date();
      const day = today.getDate();
      const month = today.getMonth();
      const year = today.getFullYear();
      const formattedDate = `${day}-${month}-${year}`;
      quizzes[i].timeLastEdited = formattedDate;
    }
  }

  return {};
}

/**
 * Update the description of the selected quiz and update the last edited time.
 *
 * @param {number} authUserId - The ID of the authentication user.
 * @param {number} quizId - The ID of the quiz.
 * @param {string} description - The new description.
 *
 * @returns {{}} - Returns empty object if succesful.
 * @returns {{ error: string }} - Returns an error object if an issue is found.
 */

function adminQuizDescriptionUpdate(authUserId: number, quizId: number, description: string) {
  const data = getData();
  let foundQuizId = false; let foundUserId = false; let userChecks = false;

  if (description.length > 100) {
    return { error: 'Description is more than 100 characters' };
  }

  for (const quiz of data.quizzes) {
    if (quiz.quizId === quizId) {
      foundQuizId = true;
    }
  }

  if (foundQuizId === false) {
    return { error: 'Quiz ID does not refer to a valid quiz' };
  }

  for (const user of data.users) {
    if (authUserId === user.authUserId) {
      foundUserId = true;
      for (const userQuizId of user.quizzes) {
        if (quizId === userQuizId) {
          userChecks = true;
          break;
        }
      }
      break;
    }
  }

  if (foundUserId === false) {
    return { error: 'AuthUserId is not a valid user' };
  }
  if (foundUserId === true && userChecks === false) {
    return { error: 'Quiz ID does not refer to a quiz that this user owns' };
  }

  for (const quiz of data.quizzes) {
    if (quiz.quizId === quizId) {
      quiz.description = description;
      const today = new Date();
      const day = today.getDate();
      const month = today.getMonth();
      const year = today.getFullYear();
      const formattedDate = `${day}-${month}-${year}`;
      quiz.timeLastEdited = formattedDate;

      return {};
    }
  }
}

/**
 * Permanently remove all quizzes from the trash.
 *
 * @param {number} authUserId - The ID of the user attempting to empty the trash.
 * @param {string} token - The token of the user to be validated.
 *
 * @returns {{}} - An empty object if the removal of quizzes is successful.
 * @returns {{error: string}} - Returns an error object if an issue is found.
 */
function adminQuizTrashEmpty(token: string, quizIds: number[]) {
  const data = getData();

  // prameter shoukd be authUserId and quizId
  // cannot use token
  // missing error "one or more of the quizIDs is not currently in the trash"

  if (!isValidToken(token)) return { error: 'Token is empty or invalid', statusCode: 401 };

  if (quizIds.length < 1) return { error: 'One or more of the Quiz IDs is not currently in the trash', statusCode: 400};

  if (!isQuizOwner) return { error: 'Valid token is provided, but one or more of the Quiz IDs refers to a quiz that this current user does not own', statusCode: 403};

  const session = data.sessions.find(session => session.sessionId === token);

  for (const quizId of quizIds) {
    const trashQuiz = data.quizTrash.find(quiztrash => quiztrash.quizId === quizId);
    if (!trashQuiz) {
      return { error: 'Quiz is not in the trashhhhhhhh!!!!!!', statusCode: 400 };
    }
    else if (session.authUserId !== trashQuiz.authUserId) {
      return { error: 'Quiz is not belong to this user!!!', statusCode: 403 };
    }
  }

  for(let i = 0; i < quizIds.length; i ++){
    data.quizTrash = data.quizTrash.filter(quiz => quiz.quizId !== quizIds[i]);
  }
  
  setData(data);

  return {};
}

function transferQuizOwnership(token: string, quizId: number, email: string) {
  const data = getData();

  // missing all the errors from error 400. should have 3 more errors.

  const newOwner = data.users.find(user => user.email === email);

  if (!newOwner) {
    return { error: 'userEmail is not a real user', statusCode: 400};
  }

  if (data.sessions.find(curUser => curUser.token === token)) {
    return { error: 'userEmail is the current logged in user', statusCode: 400 };
  }
  
  if (!isValidToken(token)) {
    return { error: 'Token is empty or invalid', statusCode: 401 };
  }

  if (hasQuizWithSameName(data.sessions.find(session => session.authUserId === newOwner.authUserId).sessionId, transferedQuiz.name)) {
    return { error: 'Quiz ID refers to a quiz that has a name that is already used by the target user', statusCode: 400 };
  }
  
  if (!isQuizOwner(token, quizId)) {
    return { error: 'Valid token is provided, but user is not an owner of this quiz', statusCode: 403 };
  }

  transferedQuiz.authUserId = newOwner.authUserId;
  console.log(transferedQuiz);
  console.log(newOwner);
  transferedQuiz.timeLastEdited = Date.now() / 1000;

  setData(data);

  return {};
}

/**
 * Removes quiz.
 *
 * @param {Quiz[]} quizzes - An array of quizes.
 * @param {number} quizId - The ID of the quiz to remove.
 */
function removeQuizById(quizzes: Quiz[], quizId: number): void {
  for (let i = 0; i < quizzes.length; i++) {
    if (quizzes[i].quizId === quizId) {
      quizzes.splice(i, 1);
      return;
    }
  }
}
/**
 * Checks if a quiz ID is valid within the given list of quizzes.
 *
 * @param {Quiz[]} quizzes - The list of quiz objects to search.
 * @param {number} quizId - The ID of the quiz to find.
 *
 * @returns {Quiz | null} - Returns the quiz object if found,
 * otherwise returns null.
 */
function isQuizIdValid(quizzes: Quiz[], quizId: number): Quiz | null {
  let i = 0;
  while (i < quizzes.length) {
    if (quizzes[i].quizId === quizId) {
      return quizzes[i];
    }
    i++;
  }
  return null;
}

function adminQuizRestore (authuserId: number, quizId: number, quizName: string) {
  const data = getData();
  const decoded = decodeToken(token);
  if (decoded.error) {
    return { error: 'Invalid token' };
  }
  // const authUserId = decoded.authUserId;

  // do not use token. error is invalid authUserId
  // missing invalid quizId

  for (const quiz of data.quizzes) {
    if (quizName === quiz.quizName) {
      return {
        error: 'Quiz name of the restored quiz is' +
            'already used by another active quiz'
      };
    }
  }

  for (const quiz of data.quizzes) {
    if (quizId === quiz.quizId) {
      return {
        error: 'Quiz ID refers to a quiz that' +
            'is not currently in the trash'
      };
    }
  }

  const restoredQuiz = data.quizTrash.splice(quizId, quizName);
  data.quizzes.timeLastEdited = new Date().toISOString();

  data.quizzes.push(restoredQuiz);
  setData(data);

  return {};
}

function adminQuizQuestionDuplicate(authUserId: number, quizId: number, questionId: number) {
  const data = getData();

  // const userAuthId = data.filter(data => data.authUserId === authUserId);
  // if (userAuthId.length === 0) {
  //   return { error: 'Invalid authUserId' };
  // }

  const user = findUserById(data.users, authUserId);
  if (!user) {
    return { error: 'Invalid authUserId' };
  }
  // missing test case. invalid quizId

  // wrong error.
  const quiz = data.quizzes.find(quiz => quiz.quizId === quizId);
  if (!quiz) {
    return { error: 'Quiz ID refers to a quiz that is not currently in the trash' };
  }

  const question = quiz.questions.find(question => question.questionId === questionId);
  if (!question) {
    return { error: 'Question Id does not refer to a valid question within this quiz' };
  }

  const newQuestionId = Math.floor(1000 + Math.random() * 9000);
  const newQuestion = { ...question, questionId: newQuestionId };

  const questionIndex = quiz.questions.findIndex(q => q.questionId === questionId);
  quiz.questions.splice(questionIndex + 1, 0, newQuestion);

  quiz.timeLastEdited = new Date().toISOString();
  setData(data);

  return { newQuestionId };
}

function adminQuizQuestionCreate(authUserId, quizId, questionBody) {
  const data = getData();

  const user = findUserById(data.users, authUserId);
  if (!user) {
    return { error: 'Invalid authUserId' };
  }

  const quiz = findQuizById(data.quizzes, quizId);
  if (!quiz) {
    return { error: 'Invalid quizId' };
  }

  if (!user.quizOwn.find(quiz => quiz.quizId === quizId)) {
    return { error: 'User does not own this quiz' };
  }

  const { question, duration, points, answers } = questionBody;

  if (question.length < 5) {
    return { error: 'Question string is less than 5 characters in length' };
  }

  if (question.length > 50) {
    return { error: 'Question string is greater than 50 characters in length' };
  }

  if (answers.length < 2) {
    return { error: 'The question has less than 2 answers' };
  }

  if (answers.length > 6) {
    return { error: 'The question has more than 6 answers' };
  }

  if (duration <= 0) {
    return { error: 'The question duration is not a positive number' };
  }

  const totalDuration = quiz.questions.reduce((acc, curr) => acc + curr.duration, duration);
  if (totalDuration > 180) {
    return { error: 'The sum of the question durations in the quiz exceeds 3 minutes' };
  }

  if (points < 1) {
    return { error: 'The points awarded for the question are less than 1' };
  }

  if (points > 10) {
    return { error: 'The points awarded for the question are greater than 10' };
  }

  for (const answer of answers) {
    if (answer.description.length < 1 || answer.description.length > 30) {
      return { error: 'Answer string length invalid' };
    }
  }

  const answerDescriptions = answers.map(answer => answer.description);
  const hasDuplicates = new Set(answerDescriptions).size !== answerDescriptions.length;
  if (hasDuplicates) {
    return { error: 'Any answer strings are duplicates of one another (within the same question)' };
  }

  const hasCorrectAnswer = answers.some(answer => answer.correct);
  if (!hasCorrectAnswer) {
    return { error: 'There are no correct answers' };
  }

  const questionId = quiz.questions.length ? quiz.questions[quiz.questions.length - 1].questionId + 1 : 1;

  const newQuestion = {
    questionId,
    question,
    duration,
    points,
    answers,
    correct: false,
    newPosition: quiz.questions.length + 1,
  };

  quiz.questions.push(newQuestion);
  quiz.timeLastEdited = new Date().toISOString();

  setData(data);

  return { questionId };
}

function adminQuizQuestionMove(authUserId, quizId, questionId, newPosition) {
  const data = getData();

  const user = findUserById(data.users, authUserId);
  if (!user) {
    return { error: 'Invalid authUserId' };
  }

  const quiz = findQuizById(data.quizzes, quizId);
  if (!quiz) {
    return { error: 'Invalid quizId' };
  }

  let userOwnsQuiz = false;
  for (let i = 0; i < data.users.length; i++) {
    if (data.users[i].authUserId === authUserId) {
      if (data.users[i].quizOwn.find(q => q.quizId === quizId)) {
        userOwnsQuiz = true;
        break;
      }
    }
  }
  if (!userOwnsQuiz) {
    return { error: 'User does not own this quiz' };
  }

  const questionIndex = quiz.questions.findIndex(q => q.questionId === questionId);
  if (questionIndex === -1) {
    return { error: 'Question Id does not refer to a valid question in this quiz.' };
  }

  if (newPosition < 0) {
    return { error: 'NewPostestion is less than 0' };
  }
  if (newPosition >= quiz.questions.length) {
    return { error: 'NewPosition is greater than n-1 where n is the number of questions' };
  }
  if (newPosition === questionIndex) {
    return { error: 'NewPosition is the position of the current question' };
  }

  const [movedQuestion] = quiz.questions.splice(questionIndex, 1);
  quiz.questions.splice(newPosition, 0, movedQuestion);
  quiz.timeLastEdited = new Date().toISOString();

  setData(data);

  return {};
}

function adminQuizQuestionUpdate(authUserId: number, quizId: number, questionId: number, newQuestion: string, duration: number, points: number, answers: Answer[]) {
  const data = getData();

  const user = findUserById(data.users, authUserId);
  if (!user) {
    return { error: 'AuthUserId is not a valid user' };
  }

  const quiz = findQuizById(data.quizzes, quizId);
  if (!quiz) {
    return { error: 'Quiz ID does not refer to a valid quiz' };
  }
  if (!user.quizzes.includes(quizId)) {
    return { error: 'Quiz ID does not refer to a quiz that this user owns' };
  }

  if (newQuestion.length < 5 || newQuestion.length > 50) {
    return { error: 'Question string is less than 5 characters in length or greater than 50 characters in length' };
  }

  if (answers.length < 2 || answers.length > 6) {
    return { error: 'The question has more than 6 answers or less than 2 answers' };
  }

  if (duration <= 0) {
    return { error: 'The question duration is not a positive number' };
  }

  for (const quiz of data.quizzes) {
    if (quiz.quizId === quizId) {
      const totalDuration = quiz.questions.reduce((acc, q) => acc + q.duration, 0) + duration;
      if (totalDuration > 180) {
        return { error: 'If this question were to be updated, the sum of the question durations in the quiz exceeds 3 minutes' };
      }
      break;
    }
  }

  if (points < 1 || points > 10) {
    return { error: 'The points awarded for the question are less than 1 or greater than 10' };
  }

  const answerDescriptions = new Set();
  for (const answer of answers) {
    if (answer.description.length < 1 || answer.description.length > 30) {
      return { error: 'The length of any answer is shorter than 1 character long, or longer than 30 characters long' };
    }
    if (answerDescriptions.has(answer.description)) {
      return { error: 'Any answer strings are duplicates of one another (within the same question)' };
    }
    answerDescriptions.add(answer.description);
  }

  if (!answers.some(answer => answer.correct)) {
    return { error: 'There are no correct answers' };
  }

  for (const quiz of data.quizzes) {
    if (quiz.quizId === quizId) {
      for (const question of quiz.questions) {
        if (question.questionId === questionId) {
          question.question = newQuestion;
          question.duration = duration;
          question.points = points;
          question.answers = answers;
          const today = new Date();
          const day = today.getDate();
          const month = today.getMonth();
          const year = today.getFullYear();
          const formattedDate = `${day}-${month}-${year}`; // supposed to be number
          quiz.timeLastEdited = formattedDate;
          setData(data);
          return {};
        }
      }
      return { error: 'Question ID does not refer to a valid question in this quiz' };
    }
  }
}

function adminQuizQuestionDelete(authUserId: number, quizId: number, questionId: number) {
  const data = getData();

  const user = findUserById(data.users, authUserId);
  if (!user) {
    return { error: 'AuthUserId is not a valid user' };
  }

  const quiz = findQuizById(data.quizzes, quizId);
  if (!quiz) {
    return { error: 'Quiz ID does not refer to a valid quiz' };
  }
  if (!user.quizzes.includes(quizId)) {
    return { error: 'Quiz ID does not refer to a quiz that this user owns' };
  }

  for (const quiz of data.quizzes) {
    if (quiz.quizId === quizId) {
      for (const [index, question] of quiz.questions.entries()) {
        if (question.questionId === questionId) {
          quiz.questions.splice(index, 1);
          setData(data);
          return {};
        }
      }
      return { error: 'Question ID does not refer to a valid question in this quiz' };
    }
  }
}

type QuizTrashResponse = {
  quizzes: { quizId: number, name: string }[]
} | { error: string };

function adminGetQuizTrash(authUserId: number) {
  const data: TooKah = getData();

  const user = findUserById(data.users, authUserId);
  if (!user) {
    return { error: 'Invalid authUserId' };
  }

  const userOwnedQuizIds = data.users.find(user => user.authUserId === authUserId)?.quizOwn.map(quiz => quiz.quizId) || [];
  const quizzesInTrash = data.quizTrash.filter((quiz: Quiz) => userOwnedQuizIds.includes(quiz.quizId)).map((quiz: Quiz) => ({
    quizId: quiz.quizId,
    name: quiz.name,
  }));

  if (quizzesInTrash.length === 0) {
    return { error: 'Valid token is provided, but user is not an owner of this quiz' };
  }

  return { quizzes: quizzesInTrash };
}

export {
  adminQuizCreate,
  adminQuizList,
  adminQuizRemove,
  adminQuizInfo,
  adminQuizNameUpdate,
  adminQuizDescriptionUpdate,
  findUserById,
  findQuizById,
  removeQuizById,
  transferQuizOwnership,
  adminQuizTrashEmpty,
  adminQuizQuestionDuplicate,
  adminQuizRestore,
  adminQuizQuestionCreate,
  adminQuizQuestionMove,
  adminQuizQuestionDelete,
  adminQuizQuestionUpdate,
  adminGetQuizTrash
};
