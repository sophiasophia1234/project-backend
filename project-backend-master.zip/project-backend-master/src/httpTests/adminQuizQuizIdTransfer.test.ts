import request from 'sync-request';
import config from '../config.json';
import { getHTTPauthRegister, getHTTPQuizCreate, postHTTPQuizTransfer, getHTTPQuizList, deleteHTTPClear } from './httpHelpers'
import { ERR_INVALID_TOKEN } from '../error';
const port = config.port;
const url = config.url;

// 400 for adminQuizQuizIdTransfer
const ERR_USEREMAIL_INVALID = { error: 'userEmail is not a real user' };
const ERR_USEREMAIL_CURRENT_LOGGED = { error: 'userEmail is the current logged in user' };
const ERR_QUIZID_USED_QUIZ_NAME = { error: 'Quiz ID refers to a quiz that has a name that is already used by the target user' };

// 403 for adminQuizQuizIdTransfer
const ERR_USER_NOT_EXIST = { error: 'Valid token is provided, but user is not an owner of this quiz' };

describe('POST/v1/admin/quiz/{quizId}/tranfer', () => {
  let userToken: string, quizId: number;
  beforeEach(() => {
    deleteHTTPClear();
    const register = getHTTPauthRegister('yaran@gmail.com', '1234abcd!@$', 'Yaran', 'Zhang');
    const user = JSON.parse(register.body as string);
    email = user.email;
    password = user.password;

    const login = getHTTPLogin(email, password);
    const loginResponse = JSON.parse(login.body as string);
    token = loginResponse.token;
  });

  test('should return 400 if userEmail is not a real user', () => {
    const res = request(
      'POST',
      `${url}:${port}/v1/admin/quiz/${quizId}/transfer`,
      {
        json: {
          token: userToken,
          email: 'yggffdgsjfhf',
        },
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
  });

  test('should return 400 if email is the current logged in user', () => {
    const res = request(
      'POST',
            `${url}:${port}/v1/admin/quiz/${quizId}/transfer`,
            {
              json: {
                token: userToken,
                email: 'yaran@gmail.com',
              },
            }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
  });

  test('should return 400 if quiz ID refers to a quiz that has a name that is already used by the target user', () => {
    const res = request(
      'POST',
            `${url}:${port}/v1/admin/quiz/${quizId}/transfer`,
            {
              json: {
                token: userToken,
                email: 'yaran@gmail.com',
              },
            }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
  });

  test('should return 401 if token is invalid', () => {
    const res = request(
      'POST',
            `${url}:${port}/v1/admin/quiz/${quizId}/transfer`,
            {
              json: {
                token: 'invalidtoken',
                email: 'yaran@gmail.com',
              },
            }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(401);
  });

  test('should return 400 if target have the quiz with same name', () => {
    const token1 = JSON.parse(getHTTPauthRegister('naray@gmail.com', '1234abcd!@$', 'Naray', 'Zhang').body as string).token;
    postHTTPQuizTransfer(userToken, quizId, 'naray@gmail.com');

    const res = request(
      'POST',
            `${url}:${port}/v1/admin/quiz/${quizId}/transfer`,
            {
              json: {
                token: token1,
                email: 'yaran@gmail.com',
              },
            }
    );
    const bodyObj = JSON.parse(res.body as string);
    console.log(bodyObj);
    expect(res.statusCode).toBe(400);
  });

  test('should return 200 if transfer quiz ownership successfully', () => {
    const token1 = JSON.parse(getHTTPauthRegister('naray@gmail.com', '1234abcd!@$', 'Naray', 'Zhang').body as string).token;
    postHTTPQuizTransfer(userToken, quizId, 'naray@gmail.com');

    expect(JSON.parse(getHTTPQuizList(token1).body as string)).toStrictEqual({
      quizzes: [
        {
          quizId: 0,
          name: 'Quiz1'
        }
      ]
    });
  });
});
