import request from 'sync-request';
import config from '../config.json';
import { getHTTPauthRegister, deleteHTTPClear} from './httpHelpers';
import {
  ERR_INVALID_TOKEN,
  ERR_INVALID_USER_AUTHORISATION,
  ERR_ID_IVALID,
  ERR_NP_NEG,
  ERR_NP_MORE_N,
  ERR_NEWOLDPOS_SAME,
  ERR_NOT_OWNED_QUIZ,
} from '../error';

const port = config.port;
const url = config.url;

describe('PUT /v1/admin/quiz/:quizid/question/:questionid/move', () => {
  let token: string;
  let quizId: string;
  let questionId: string;

  beforeEach(() => {
    deleteHTTPClear();
    const register = getHTTPauthRegister('yaran@gmail.com', '1234abcd!@$', 'Yaran', 'Zhang');
    const user = JSON.parse(register.body as string);
    console.log(user.token);
    token = user.token;

    quizId = JSON.parse(getHTTPQuizCreate(token, 'Quiz1', 'description of quiz1').body as string).quizId;

    const addQuestion = request(
      'POST',
            `${url}:${port}/v1/admin/quiz/${quizId}/question`,
            {
              json: {
                token: token,
                questionBody: {
                  question: 'Who is the Monarch of England?',
                  duration: 4,
                  points: 5,
                  answers: [
                    {
                      answer: 'Prince Charles',
                      correct: true
                    }
                  ]
                }
              }
            }
    );

    const question = JSON.parse(addQuestion.body as string);
    questionId = question.questionId;
  });

  test('Test 401 if token is missing', () => {
    const res = request(
      'PUT',
            `${url}:${port}/v1/admin/quiz/${quizId}/question/${questionId}/move`,
            {
              json: {
                newPosition: 1
              },
              timeout: 100
            }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(401);
    expect(bodyObj).toEqual(ERR_INVALID_TOKEN);
  });

  test('Test 403 if user is not authorized', () => {
    const res = request(
      'PUT',
            `${url}:${port}/v1/admin/quiz/${quizId}/question/${questionId}/move`,
            {
              json: {
                token: 'invalidtoken',
                newPosition: 1
              },
              timeout: 100
            }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(403);
    expect(bodyObj).toEqual(ERR_INVALID_USER_AUTHORISATION);
  });

  test('Test 200 if request is valid', () => {
    const res = request(
      'PUT',
            `${url}:${port}/v1/admin/quiz/${quizId}/question/${questionId}/move`,
            {
              json: {
                token: token,
                newPosition: 1
              },
              timeout: 100
            }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(200);
    expect(bodyObj).toEqual({});
  });

  test('Test 400 if quiz ID is invalid', () => {
    const res = request(
      'PUT',
            `${url}:${port}/v1/admin/quiz/invalidQuizId/question/${questionId}/move`,
            {
              json: {
                token: token,
                newPosition: 1
              },
              timeout: 100
            }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_ID_IVALID);
  });

  test('Test 400 if question ID is invalid', () => {
    const res = request(
      'PUT',
            `${url}:${port}/v1/admin/quiz/${quizId}/question/invalidQuestionId/move`,
            {
              json: {
                token: token,
                newPosition: 1
              },
              timeout: 100
            }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_ID_IVALID);
  });

  test('Test 400 if new position is less than 0', () => {
    const res = request(
      'PUT',
            `${url}:${port}/v1/admin/quiz/${quizId}/question/${questionId}/move`,
            {
              json: {
                token: token,
                newPosition: -1
              },
              timeout: 100
            }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_NP_NEG);
  });

  test('Test 400 if new position is greater than n-1 where n is the number of questions', () => {
    const res = request(
      'PUT',
            `${url}:${port}/v1/admin/quiz/${quizId}/question/${questionId}/move`,
            {
              json: {
                token: token,
                newPosition: 10
              },
              timeout: 100
            }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_NP_MORE_N);
  });

  test('Test 400 if new position is the same as the current position', () => {
    const res = request(
      'PUT',
            `${url}:${port}/v1/admin/quiz/${quizId}/question/${questionId}/move`,
            {
              json: {
                token: token,
                newPosition: 0 // Assuming current position is 0
              },
              timeout: 100
            }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_NEWOLDPOS_SAME);
  });

  test('Test 403 if user does not own the quiz', () => {
    const registerAnotherUser = request(
      'POST',
            `${url}:${port}/v1/admin/auth/register`,
            {
              json: {
                email: 'another@gmail.com',
                password: 'testing123',
                firstName: 'Another',
                lastName: 'User'
              }
            }
    );

    const anotherRegister = JSON.parse(registerAnotherUser.body as string);
    const anotherToken = anotherRegister.token;

    const res = request(
      'PUT',
            `${url}:${port}/v1/admin/quiz/${quizId}/question/${questionId}/move`,
            {
              json: {
                token: anotherToken,
                newPosition: 1
              },
              timeout: 100
            }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(403);
    expect(bodyObj).toEqual(ERR_NOT_OWNED_QUIZ);
  });
});
