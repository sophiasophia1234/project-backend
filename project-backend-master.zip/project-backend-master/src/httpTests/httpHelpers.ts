import request from 'sync-request';
import { port, url } from '../config.json';

const getHTTPauthRegister = (email: string, password: string, nameFirst: string, nameLast: string) => {
  return request(
    'POST',
            `${url}:${port}/v1/admin/auth/register`,
            {
              json: {
                email,
                password,
                nameFirst,
                nameLast
              }
            }
  );
};

const getHTTPQuizCreate = (token: string, name: string, description: string) => {
  return request(
    'POST',
            `${url}:${port}/v1/admin/quiz`,
            {
              json: {
                token,
                name,
                description,
              }
            }
  );
};

const getHTTPQuizInfo = (quizId: number, token: string) => {
  return request(
    'GET',
            `${url}:${port}/v1/admin/quiz/${quizId}`,
            {
              qs: { token }
            }
  );
};

const getHTTPLogin = (email: string, password: string) => {
  return request(
    'POST',
          `${url}:${port}/v1/admin/auth/login`,
          {
            json: {
              email,
              password,
            }
          }
  );
};

const getHTTPLogout = (token: string) => {
  return request(
    'POST',
        `${url}:${port}/v1/admin/auth/logout`,
        {
          json: {
            token,
          }
        }
  );
};

const getHTTPUserDetails = (token: string) => {
  return request(
    'GET',
      `${url}:${port}/v1/admin/user/details`,
      {
        qs: {
          token,
        }
      }
  );
};

const getHTTPQuizDescriptionUpdate = (token: string, quizId: number, description: string) => {
  return request(
    'PUT',
      `${url}:${port}/v1/admin/quiz/${quizId}/description`,
      {
        json: {
          token,
          description
        }
      }
  );
};

export const deleteHTTPClear = () => {
  return request(
    'DELETE',
    `${url}:${port}/v1/clear`
  );
};

export const deleteHTTPRemove = (token: string, quizId: number) => {
  return request(
    'DELETE',
    `${url}:${port}/v1/admin/quiz/${quizId}`,
    {
      qs: {
        token: token
      },
    }
  );
}

const deleteHTTPTrashEmpty = (token: string, quizIds: number[]) => {
  return request(
    'DELETE',
    `${url}:${port}/v1/admin/quiz/trash/empty`,
    {
      qs: {
        token,
        quizIds
      }
    }
  );
};

const postHTTPQuizRestore = (token: string, quizId: number) => {
  return request(
    'POST',
    `${url}:${port}/v1/admin/quiz/${quizId}/restore`,
    {
      json: { token }
    }
  )
};

const postHTTPQuizTransfer = (token: string, quizId: number, email: string) => {
  return request(
    'POST',
    `${url}:${port}/v1/admin/quiz/${quizId}/transfer`,
    {
      json: {
        token,
        email
      }
    }
  );
};

const getHTTPQuizList = (token: string) => {
  return request(
    'GET',
    `${url}:${port}/v1/admin/quiz/list`,
    {
      qs: { token }
    }
  )
}

export {
  getHTTPauthRegister,
  getHTTPQuizCreate,
  getHTTPQuizInfo,
  getHTTPLogin,
  getHTTPLogout,
  getHTTPUserDetails,
  getHTTPQuizDescriptionUpdate
};
