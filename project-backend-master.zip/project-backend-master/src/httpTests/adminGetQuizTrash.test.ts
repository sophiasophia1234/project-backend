import request from 'sync-request';
import config from '../config.json';
import { ERR_INVALID_TOKEN } from '../error';
import { getHTTPauthRegister, getHTTPQuizCreate, deleteHTTPClear} from './httpHelpers';

const port = config.port;
const url = config.url;

describe('GET /v1/admin/quiz/trash', () => {
  let token: string;
  let quizId: number;

  beforeEach(() => {
    deleteHTTPClear();
    const register = getHTTPauthRegister('yaran@gmail.com', '1234abcd!@$', 'Yaran', 'Zhang');
    const user = JSON.parse(register.body as string);
    console.log(user.token);
    token = user.token;

    quizId = JSON.parse(getHTTPQuizCreate(token, 'Quiz1', 'description of quiz1').body as string).quizId;
  });

  test('Test 200 if request is valid', () => {
    const res = request(
      'GET',
      `${url}:${port}/v1/admin/quiz/trash`,
      {
        qs: {
          token: token
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(200);
    expect(bodyObj).toHaveProperty('quizzes');
    expect(Array.isArray(bodyObj.quizzes)).toBe(true);
    if (bodyObj.quizzes.length > 0) {
      expect(bodyObj.quizzes[0]).toHaveProperty('quizId');
      expect(bodyObj.quizzes[0]).toHaveProperty('name');
    }
  });

  test('Test 401 if token is missing', () => {
    const res = request(
      'GET',
      `${url}:${port}/v1/admin/quiz/trash`,
      {
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(401);
    expect(bodyObj).toEqual(ERR_INVALID_TOKEN);
  });

  test('Test 401 if user is not authorized', () => {
    const res = request(
      'GET',
      `${url}:${port}/v1/admin/quiz/trash`,
      {
        qs: {
          token: 'invalidtoken'
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(401);
    expect(bodyObj).toEqual(ERR_INVALID_TOKEN);
  });
});
