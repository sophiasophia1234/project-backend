import request from 'sync-request';
import config from '../config.json';
import {
  ERR_EMAIL_USED_AUDU,
  ERR_EMAIL_VALIDATOR_AUDU,
  ERR_NAMEFIRST_INVALID_AUDU,
  ERR_NAMEFIRST_LESS_AUDU,
  ERR_NAMEFIRST_MORE_AUDU,
  ERR_NAMELAST_INVALID_AUDU,
  ERR_NAMELAST_LESS_AUDU,
  ERR_NAMELAST_MORE_AUDU,
  ERR_INVALID_TOKEN
} from '../error';

const port = config.port;
const url = config.url;

describe('GET /v1/admin/user/details', () => {
  let token: string;

  beforeEach(() => {
    const registerUser = request(
      'POST',
      `${url}:${port}/v1/admin/auth/register`,
      {
        json: {
          email: 'sop@gmail.com',
          password: 'testing123',
          firstName: 'Sophia',
          lastName: 'Maghirang'
        }
      }
    );

    const register = JSON.parse(registerUser.body as string);
    token = register.token;
    console.log(1);
  });

  test('Test 401 if token is missing', () => {
    const res = request(
      'PUT',
      `${url}:${port}/v1/admin/user/details/`,
      {
        json: {
          email: 'newSop@gmail.com',
          firstName: 'Sophia',
          lastName: 'Maghirang'
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(401);
    expect(bodyObj).toEqual(ERR_INVALID_TOKEN);
  });

  test.only('Test 200 if request is valid', () => {
    console.log('!!!!!!!!!!!!!!!');
    const res = request(
      'PUT',
      `${url}:${port}/v1/admin/user/details`,
      {
        json: {
          token: token,
          email: 'newSop@gmail.com',
          firstName: 'newFirstName',
          lastName: 'newLastName'
        },
        timeout: 100
      }
    );
    // const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(200);
    expect(res.body.toString()).toEqual('{}');
  });

  test('Test 400 if Email is currently used by another user', () => {
    const res = request(
      'PUT',
      `${url}:${port}/v1/admin/user/details`,
      {
        json: {
          token: token,
          email: 'Sop@gmail.com',
          firstName: 'newFirstName',
          lastName: 'newLastName'
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_EMAIL_USED_AUDU);
  });

  test('Test 400 if Email is not valid', () => {
    const res = request(
      'PUT',
      `${url}:${port}/v1/admin/user/details`,
      {
        json: {
          token: token,
          email: 'invalidEmail',
          firstName: 'newFirstName',
          lastName: 'newLastName'
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_EMAIL_VALIDATOR_AUDU);
  });

  test('Test 400 if NameFirst contains invalid characters', () => {
    const res = request(
      'PUT',
      `${url}:${port}/v1/admin/user/details`,
      {
        json: {
          token: token,
          email: 'newSop@gmail.com',
          firstName: '!#@%%#^',
          lastName: 'newLastName'
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_NAMEFIRST_INVALID_AUDU);
  });

  test('Test 400 if NameFirst is less than 2 characters', () => {
    const res = request(
      'PUT',
      `${url}:${port}/v1/admin/user/details`,
      {
        json: {
          token: token,
          email: 'newSop@gmail.com',
          firstName: 'S',
          lastName: 'newLastName'
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_NAMEFIRST_LESS_AUDU);
  });

  test('Test 400 if NameFirst is more than 20 characters', () => {
    const res = request(
      'PUT',
      `${url}:${port}/v1/admin/user/details`,
      {
        json: {
          token: token,
          email: 'newSop@gmail.com',
          firstName: 'newFirstNameistoolooooooooooooooooooooooong',
          lastName: 'newLastName'
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_NAMEFIRST_MORE_AUDU);
  });

  test('Test 400 if NameLast contains invalid characters', () => {
    const res = request(
      'PUT',
      `${url}:${port}/v1/admin/user/details`,
      {
        json: {
          token: token,
          email: 'newSop@gmail.com',
          firstName: 'newFirstName',
          lastName: '!@#$%'
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_NAMELAST_INVALID_AUDU);
  });

  test('Test 400 if NameLast is less than 2 characters', () => {
    const res = request(
      'PUT',
      `${url}:${port}/v1/admin/user/details`,
      {
        json: {
          token: token,
          email: 'newSop@gmail.com',
          firstName: 'newFirstName',
          lastName: 'n'
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_NAMELAST_LESS_AUDU);
  });

  test('Test 400 if NameLast is more than 20 characters', () => {
    const res = request(
      'PUT',
      `${url}:${port}/v1/admin/user/details`,
      {
        json: {
          token: token,
          email: 'newSop@gmail.com',
          firstName: 'newFirstName',
          lastName: 'newLastNameistoolooooooooooooooooooooooong'
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_NAMELAST_MORE_AUDU);
  });
});
