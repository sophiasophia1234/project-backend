import request from 'sync-request';
import config from '../config.json';
import { getHTTPauthRegister, deleteHTTPClear } from './httpHelpers';

const port = config.port;
const url = config.url;

const ERR_EMAIL_DEEN_USED = { error: 'Email already used' };
const ERR_EMAIL_VALIDATOR = { error: 'Email is not validated' };
const ERR_FIRSTNAME_CHARACTER = { error: 'First name contains invalid character' };
const ERR_LASTNAME_CHARACTER = { error: 'Last name contains invalid character' };
const ERR_FIRSTNAME_LENGTH_SHORT = { error: 'First Name is too short' };
const ERR_FIRSTNAME_LENGTH_LONG = { error: 'First Name is too long' };
const ERR_LASTNAME_LENGTH_SHORT = { error: 'Last Name is too short' };
const ERR_LASTNAME_LENGTH_LONG = { error: 'Last Name is too long' };
const ERR_PASSWORD_LENGTH = { error: 'Password is too short' };
const ERR_PASSWORD_CHARACTER = { error: 'Password does not contain at least one letter' };

describe('POST /v1/admin/auth/register', () => {
  beforeEach(() => {
    deleteHTTPClear();
  });

  test('return 400 if the email has been used', () => {
    expect(getHTTPauthRegister('yaran@gmail.com', 'Aahi23124', 'Yaran', 'Zhang').statusCode).toEqual(200);
    expect(getHTTPauthRegister('yaran@gmail.com', 'Aahi23124', 'Yaran', 'Zhang').statusCode).toEqual(400);
  });

  test('return 400 if the email is not validated', () => {
    expect(getHTTPauthRegister('yaran@', 'Aahi23124', 'Yaran', 'Zhang').statusCode).toEqual(400);
  });
  test('return 400 if the firstname contain invalid character', () => {
    expect(getHTTPauthRegister('yaran@gmail.com', 'Aahi23124', 'Ya%r^an', 'Zhang').statusCode).toEqual(400);
  });
  test('return 400 if the lastname contain invalid character', () => {
    expect(getHTTPauthRegister('yaran@gmail.com', 'Aahi23124', 'Yaran', 'Z%h&ang').statusCode).toEqual(400);
  });
  test('return 400 if the firstname is too long', () => {
    expect(getHTTPauthRegister('yaran@gmail.com', 'Aahi23124', 'a'.repeat(30), 'Zhang').statusCode).toEqual(400);
  });
  test('return 400 if the firstname is too short', () => {
    expect(getHTTPauthRegister('yaran@gmail.com', 'Aahi23124', 'a', 'Zhang').statusCode).toEqual(400);
  });
  test('return 400 if the lastname is too long', () => {
    expect(getHTTPauthRegister('yaran@gmail.com', 'Aahi23124', 'Yaran', 'a'.repeat(30)).statusCode).toEqual(400);
  });
  test('return 400 if the lastname is too short', () => {
    expect(getHTTPauthRegister('yaran@gmail.com', 'Aahi23124', 'Yaran', 'a').statusCode).toEqual(400);
  });
  test('return 400 if the password is too short', () => {
    expect(getHTTPauthRegister('yaran@gmail.com', 'A', 'Yaran', 'Zhang').statusCode).toEqual(400);
  });
  test('return 400 if the password does not contain at least one letter', () => {
    expect(getHTTPauthRegister('yaran@gmail.com', '1234567890', 'Yaran', 'Zhang').statusCode).toEqual(400);
  });
});
