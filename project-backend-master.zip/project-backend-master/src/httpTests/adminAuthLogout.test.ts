import request from 'sync-request-curl';
import config from '../config.json';
import { ERR_INVALID_TOKEN } from '../error';
import { getHTTPauthRegister, deleteHTTPClear, getHTTPLogin, getHTTPLogout } from './httpHelpers';

const port = config.port;
const url = config.url;

describe('POST /v1/admin/auth/logout', () => {
  let userToken: string;

  beforeEach(() => {
    deleteHTTPClear();
    const register = getHTTPauthRegister('faren@gmail.com', 'testing123', 'Faren', 'Lesmana');
    const user = JSON.parse(register.body as string);
    console.log(user.token);
    userToken = user.token;
  });

  test('Test 401 if token is invalid', () => {
    const res = getHTTPLogout('invalidtoken');
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(401);
    expect(bodyObj).toEqual(ERR_INVALID_TOKEN);
  });

  test('Test 401 if token is empty', () => {
    const res = getHTTPLogout('');
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(401);
    expect(bodyObj).toEqual(ERR_INVALID_TOKEN);
  });

  test('Test 200 if request is valid', () => {
    const res = getHTTPLogout('secretToken0');
    expect(res.statusCode).toBe(200);
    const bodyObj = JSON.parse(res.body as string);
    expect(bodyObj).toEqual({});
  });
});
