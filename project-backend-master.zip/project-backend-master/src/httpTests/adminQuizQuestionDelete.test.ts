import request from 'sync-request-curl';
import config from '../config.json';
import { ERR_INVALID_TOKEN, ERR_INVALID_USER_AUTHORISATION } from '../error';

const port = config.port;
const url = config.url;

describe('DELETE /v1/admin/quiz/:quizid/question/:questionid', () => {
  let userToken: string, quizId: number, questionId: number, anotherUserToken: string;

  beforeEach(() => {
    // Register and login a user
    const register = request(
      'POST',
      `${url}:${port}/v1/admin/auth/register`,
      {
        json: {
          email: 'sop@gmail.com',
          password: 'testing123',
          firstName: 'Sophia',
          lastName: 'Maghirang'
        }
      }
    );
    const user = JSON.parse(register.body as string);
    userToken = user.token;

    // Create a quiz by the user
    const createQuiz = request(
      'POST',
      `${url}:${port}/v1/admin/quiz/create`,
      {
        json: {
          token: userToken,
          name: 'Quiz1',
          description: 'description of quiz 1',
        }
      }
    );
    const createdQuiz = JSON.parse(createQuiz.body as string);
    quizId = createdQuiz.quizId;

    // Create a question for the quiz
    const createQuestion = request(
      'POST',
      `${url}:${port}/v1/admin/quiz/${quizId}/question`,
      {
        json: {
          token: userToken,
          questionBody: {
            Question: 'Who is the Monarch of England?',
            duration: 4,
            points: 5,
            answers: [
              { answer: 'Prince Charles', correct: true },
              { answer: 'Queen Elizabeth', correct: false },
            ],
          }
        }
      }
    );
    const createdQuestion = JSON.parse(createQuestion.body as string);
    questionId = createdQuestion.questionId;

    // Register and login another user
    const anotherRegister = request(
      'POST',
      `${url}:${port}/v1/admin/auth/register`,
      {
        json: {
          email: 'faren@gmail.com',
          password: 'password123',
          firstName: 'Faren',
          lastName: 'Lesmana'
        }
      }
    );
    const anotherUser = JSON.parse(anotherRegister.body as string);
    anotherUserToken = anotherUser.token;
  });

  test('Test 400 if question ID is invalid', () => {
    const res = request(
      'DELETE',
      `${url}:${port}/v1/admin/quiz/${quizId}/question/${questionId}`, // Invalid questionId
      {
        qs: {
          token: userToken
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual({ error: 'error' });
  });

  test('Test 401 if token is invalid', () => {
    const res = request(
      'DELETE',
      `${url}:${port}/v1/admin/quiz/${quizId}/question/${questionId}`,
      {
        qs: {
          token: 'invalidtoken'
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(401);
    expect(bodyObj).toEqual(ERR_INVALID_TOKEN); // add the error message in error.ts
  });

  test('Test 401 if token is empty', () => {
    const res = request(
      'DELETE',
      `${url}:${port}/v1/admin/quiz/${quizId}/question/${questionId}`,
      {
        qs: {
          token: ''
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(401);
    expect(bodyObj).toEqual(ERR_INVALID_TOKEN); // add the error message in error.ts
  });

  test('Test 403 if user is not the owner of the quiz', () => {
    const res = request(
      'DELETE',
      `${url}:${port}/v1/admin/quiz/${quizId}/question/${questionId}`,
      {
        qs: {
          token: anotherUserToken
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(403);
    expect(bodyObj).toEqual(ERR_INVALID_USER_AUTHORISATION); // add the error message in error.ts
  });

  test('Test 200 if request is valid', () => {
    const res = request(
      'DELETE',
      `${url}:${port}/v1/admin/quiz/${quizId}/question/${questionId}`,
      {
        qs: {
          token: userToken
        },
        timeout: 100
      }
    );
    expect(res.statusCode).toBe(200);
    const bodyObj = JSON.parse(res.body as string);
    expect(bodyObj).toEqual({});
  });
});
