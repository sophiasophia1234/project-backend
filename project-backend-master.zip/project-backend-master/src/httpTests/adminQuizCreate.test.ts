import request from 'sync-request';
import { port, url } from '../config.json';
import {
  getHTTPauthRegister, getHTTPQuizCreate,
  getHTTPQuizInfo, deleteHTTPClear
} from './httpHelpers';

import { Quiz } from '../dataStore';

// error 400 for authminQuizCreate
const ERR_INVALID_NAME_CHARACTER = { error: 'Name contains invalid characters.' };
const ERR_INVALID_NAME_LENGTH = { error: 'Name is either less than 3 characters long or more than 30 characters long' };
const ERR_NAME_BEEN_USED = { error: 'Name is already used by the current logged in user for another quiz' };
const ERR_INVALID_DESCRIPTION = { error: 'Description is more than 100 characters in length' };

describe('POST /v1/admin/quiz', () => {
  let userToken: string, quizId: number, description: string, info: Quiz;
  beforeEach(() => {
    deleteHTTPClear();
    const register = getHTTPauthRegister('yaran@gmail.com', '1234abcd!@$', 'Yaran', 'Zhang');
    const user = JSON.parse(register.body as string);
    console.log(user.token);
    userToken = user.token;

    quizId = JSON.parse(getHTTPQuizCreate(userToken, 'Quiz1', 'description of quiz1').body as string).quizId;
    console.log(quizId);
    const getInfo = getHTTPQuizInfo(quizId, userToken);
    info = JSON.parse(getInfo.body as string);
  });

  test('return 400 if name contains invalid character', () => {
    expect(getHTTPQuizCreate(userToken, 'Qui*z2', 'description of quiz1').statusCode).toEqual(400);
  });
  test('return 400 if name is too long', () => {
    expect(getHTTPQuizCreate(userToken, 'a'.repeat(50), 'description of quiz1').statusCode).toEqual(400);
  });
  test('return 400 if name is too short', () => {
    expect(getHTTPQuizCreate(userToken, 'a', 'description of quiz1').statusCode).toEqual(400);
  });
  test('return 400 if name is already exist', () => {
    expect(getHTTPQuizCreate(userToken, 'Quiz1', 'description of quiz1').statusCode).toEqual(400);
  });
  test('return 400 if description is too long', () => {
    expect(getHTTPQuizCreate(userToken, 'Quiz2', 'a'.repeat(101)).statusCode).toEqual(400);
  });
  test('return 200 if request is valid', () => {
    expect(info).toStrictEqual({
      quizId: 0,
      name: 'Quiz1',
      timeCreated: expect.any(Number),
      timeLastEdited: expect.any(Number),
      description: 'description of quiz1',
      numQuestions: 0,
      questions: [],
      duration: 0
    });
  });
});
