import request from 'sync-request';
import config from './config.json';
import { ERR_INVALID_TOKEN, ERR_INVALID_USER_AUTHORISATION } from '../error';

const port = config.port;
const url = config.url;

describe('DELETE /v1/admin/quiz/:quizId', () => {
  let token: string;
  let quizId: number;

  beforeEach(() => {
    const registerUser = request(
      'POST',
      `${url}:${port}/v1/admin/auth/register`,
      {
        json: {
          email: 'sop@gmail.com',
          password: 'testing123',
          firstName: 'Sophia',
          lastName: 'Maghirang'
        }
      }
    );

    const register = JSON.parse(registerUser.body as string);
    token = register.token;

    const createQuiz = request(
      'POST',
      `${url}:${port}/v1/admin/quiz/create`,
      {
        json: {
          token: token,
          name: 'Quiz1',
          description: 'description of quiz 1',
        }
      }
    );

    const quiz = JSON.parse(createQuiz.body as string);
    quizId = quiz.quizId;
  });

  test('Test 401 if token is missing', () => {
    const res = request(
      'DELETE',
      `${url}:${port}/v1/admin/quiz/${quizId}`,
      {
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(401);
    expect(bodyObj).toEqual(ERR_INVALID_TOKEN);
  });

  test('Test 403 if user is not authorized', () => {
    const res = request(
      'DELETE',
      `${url}:${port}/v1/admin/quiz/${quizId}`,
      {
        qs: {
          token: 'invalidtoken'
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(403);
    expect(bodyObj).toEqual(ERR_INVALID_USER_AUTHORISATION);
  });

  test('Test 200 if request is valid', () => {
    const res = request(
      'DELETE',
      `${url}:${port}/v1/admin/quiz/${quizId}`,
      {
        qs: {
          token: token
        },
        timeout: 100
      }
    );
    expect(res.statusCode).toBe(200);
    expect(res.body.toString()).toEqual('{}');
  });
});
