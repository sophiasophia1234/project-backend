
import request from 'sync-request';
import config from '../config.json';
import { getHTTPauthRegister, deleteHTTPClear} from './httpHelpers';
import {
  ERR_INVALID_TOKEN,
  ERR_INVALID_USER_AUTHORISATION,
  ERR_NOT_POS_DURATON,
  ERR_SUM_DUR_MORE,
  ERR_LESS_POINT,
  ERR_MORE_POINT,
  ERR_LESS_CHAR_ANS,
  ERR_MORE_CHAR_ANS,
  ERR_ANS_DUPLICATE,
  ERR_NO_CORRECT_ANS,
  ERR_MORE_QUESTION,
  ERR_MORE_ANS,
  ERR_LESS_ANS
} from '../error';

const port = config.port;
const url = config.url;

describe('POST /v1/admin/quiz/:quizId/question', () => {
  let token: string;
  let quizId: number;

  beforeEach(() => {
    deleteHTTPClear();
    const register = getHTTPauthRegister('yaran@gmail.com', '1234abcd!@$', 'Yaran', 'Zhang');
    const user = JSON.parse(register.body as string);
    console.log(user.token);
    token = user.token;

    quizId = JSON.parse(getHTTPQuizCreate(token, 'Quiz1', 'description of quiz1').body as string).quizId;
  });

  test('Test 401 if token is missing', () => {
    const res = request(
      'POST',
      `${url}:${port}/v1/admin/quiz/${quizId}/question`,
      {
        json: {
          questionBody: {
            question: 'Who is the Monarch of England?',
            duration: 4,
            points: 5,
            answers: [
              {
                answer: 'Prince Charles',
                correct: true
              }
            ]
          }
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(401);
    expect(bodyObj).toEqual(ERR_INVALID_TOKEN);
  });

  test('Test 403 if user is not authorized', () => {
    const res = request(
      'POST',
      `${url}:${port}/v1/admin/quiz/${quizId}/question`,
      {
        json: {
          token: 'invalidtoken',
          questionBody: {
            question: 'Who is the Monarch of England?',
            duration: 4,
            points: 5,
            answers: [
              {
                answer: 'Prince Charles',
                correct: true
              }
            ]
          }
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(403);
    expect(bodyObj).toEqual(ERR_INVALID_USER_AUTHORISATION);
  });

  test('Test 200 if request is valid', () => {
    const res = request(
      'POST',
      `${url}:${port}/v1/admin/quiz/${quizId}/question`,
      {
        json: {
          token: token,
          questionBody: {
            question: 'Who is the Monarch of England?',
            duration: 4,
            points: 5,
            answers: [
              {
                answer: 'Prince Charles',
                correct: true
              }
            ]
          }
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(200);
    expect(bodyObj).toEqual({});
  });

  test('Test 400 if question string length is less than 5 characters', () => {
    const res = request(
      'POST',
      `${url}:${port}/v1/admin/quiz/${quizId}/question`,
      {
        json: {
          token: token,
          questionBody: {
            question: 'Q?',
            duration: 4,
            points: 5,
            answers: [
              { answer: 'Option 1', correct: true },
              { answer: 'Option 2', correct: false }
            ]
          }
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_INVALID_TOKEN);
  });

  test('Test 400 if question string length is greater than 50 characters', () => {
    const longQuestion = 'This is a very long question that exceeds the fifty character limit allowed for questions in the quiz.';
    const res = request(
      'POST',
      `${url}:${port}/v1/admin/quiz/${quizId}/question`,
      {
        json: {
          token: token,
          questionBody: {
            question: longQuestion,
            duration: 4,
            points: 5,
            answers: [
              { answer: 'Option 1', correct: true },
              { answer: 'Option 2', correct: false }
            ]
          }
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_MORE_QUESTION);
  });

  test('Test 400 if question has more than 6 answers', () => {
    const res = request(
      'POST',
      `${url}:${port}/v1/admin/quiz/${quizId}/question`,
      {
        json: {
          token: token,
          questionBody: {
            question: 'How many continents are there in the world?',
            duration: 4,
            points: 5,
            answers: [
              { answer: 'Five', correct: false },
              { answer: 'Six', correct: false },
              { answer: 'Seven', correct: false },
              { answer: 'Eight', correct: false },
              { answer: 'Nine', correct: false },
              { answer: 'Ten', correct: false },
              { answer: 'Eleven', correct: false },
              { answer: 'Twelve', correct: false } // More than 6 answers
            ]
          }
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_MORE_ANS);
  });

  test('Test 400 if question has less than 2 answers', () => {
    const res = request(
      'POST',
      `${url}:${port}/v1/admin/quiz/${quizId}/question`,
      {
        json: {
          token: token,
          questionBody: {
            question: 'Who is the current President of the United States?',
            duration: 4,
            points: 5,
            answers: [
              { answer: 'Joe Biden', correct: true } // Less than 2 answers
            ]
          }
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_LESS_ANS);
  });

  test('Test 400 if question duration is not a positive number', () => {
    const res = request(
      'POST',
      `${url}:${port}/v1/admin/quiz/${quizId}/question`,
      {
        json: {
          token: token,
          questionBody: {
            question: 'What is the capital of France?',
            duration: -1,
            points: 5,
            answers: [
              { answer: 'Paris', correct: true }
            ]
          }
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_NOT_POS_DURATON);
  });

  test('Test 400 if sum of question durations in the quiz exceeds 3 minutes', () => {
    const res = request(
      'POST',
      `${url}:${port}/v1/admin/quiz/${quizId}/question`,
      {
        json: {
          token: token,
          questionBody: {
            question: 'Question 1',
            duration: 180,
            points: 5,
            answers: [
              { answer: 'Option 1', correct: true },
              { answer: 'Option 2', correct: false }
            ]
          }
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_SUM_DUR_MORE);
  });

  test('Test 400 if points awarded for the question are less than 1', () => {
    const res = request(
      'POST',
      `${url}:${port}/v1/admin/quiz/${quizId}/question`,
      {
        json: {
          token: token,
          questionBody: {
            question: 'What is 2 + 2?',
            duration: 4,
            points: 0,
            answers: [
              { answer: '4', correct: true }
            ]
          }
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_LESS_POINT);
  });

  test('Test 400 if points awarded for the question are greater than 10', () => {
    const res = request(
      'POST',
      `${url}:${port}/v1/admin/quiz/${quizId}/question`,
      {
        json: {
          token: token,
          questionBody: {
            question: 'What is 2 + 2?',
            duration: 4,
            points: 15,
            answers: [
              { answer: '4', correct: true }
            ]
          }
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_MORE_POINT);
  });

  test('Test 400 if length of any answer is shorter than 1 character', () => {
    const res = request(
      'POST',
      `${url}:${port}/v1/admin/quiz/${quizId}/question`,
      {
        json: {
          token: token,
          questionBody: {
            question: 'What is 2 + 2?',
            duration: 4,
            points: 5,
            answers: [
              { answer: '', correct: true } // Answer length is 0
            ]
          }
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_LESS_CHAR_ANS);
  });

  test('Test 400 if length of any answer is longer than 30 characters', () => {
    const longAnswer = 'This is a very long answer that exceeds the thirty character limit allowed for answers.';
    const res = request(
      'POST',
      `${url}:${port}/v1/admin/quiz/${quizId}/question`,
      {
        json: {
          token: token,
          questionBody: {
            question: 'What is 2 + 2?',
            duration: 4,
            points: 5,
            answers: [
              { answer: longAnswer, correct: true }
            ]
          }
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_MORE_CHAR_ANS);
  });

  test('Test 400 if any answer strings are duplicates', () => {
    const res = request(
      'POST',
      `${url}:${port}/v1/admin/quiz/${quizId}/question`,
      {
        json: {
          token: token,
          questionBody: {
            question: 'What is 2 + 2?',
            duration: 4,
            points: 5,
            answers: [
              { answer: 'Four', correct: true },
              { answer: 'Four', correct: false } // Duplicate answer string
            ]
          }
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_ANS_DUPLICATE);
  });

  test('Test 400 if there are no correct answers provided', () => {
    const res = request(
      'POST',
      `${url}:${port}/v1/admin/quiz/${quizId}/question`,
      {
        json: {
          token: token,
          questionBody: {
            question: 'What is 2 + 2?',
            duration: 4,
            points: 5,
            answers: [
              { answer: '4', correct: false },
              { answer: '3', correct: false }
            ]
          }
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_NO_CORRECT_ANS);
  });
});
