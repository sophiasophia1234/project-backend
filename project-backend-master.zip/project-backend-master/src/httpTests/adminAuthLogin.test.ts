import request from 'sync-request-curl';
import config from '../config.json';
import { ERR_INVALID_EMAIL, ERR_INVALID_PASSWORD } from '../error';
import { getHTTPauthRegister, deleteHTTPClear, getHTTPLogin } from './httpHelpers';

const port = config.port;
const url = config.url;

describe('POST /v1/admin/auth/login', () => {
  beforeEach(() => {
    deleteHTTPClear();
    const register = getHTTPauthRegister('faren@gmail.com', 'testing123', 'Faren', 'Lesmana');
  });

  test('Test 400 if email address does not exist', () => {
    const result = getHTTPLogin('frn@gmail.com', 'testing123');
    const user = JSON.parse(result.body as string);
    expect(result.statusCode).toBe(400);
    expect(user).toEqual(ERR_INVALID_EMAIL); // add the error message in error.ts
  });

  test('Test 400 if password is incorrect for the given email', () => {
    const result = getHTTPLogin('faren@gmail.com', '123testing');
    const user = JSON.parse(result.body as string);
    expect(result.statusCode).toBe(400);
    expect(user).toEqual(ERR_INVALID_PASSWORD); // add the error message in error.ts
  });

  test('Test 200 if request is valid', () => {
    const result = getHTTPLogin('faren@gmail.com', 'testing123');
    const user = JSON.parse(result.body as string);
    expect(result.statusCode).toBe(200);
    expect(user).toEqual('secretToken2');
  });
});
