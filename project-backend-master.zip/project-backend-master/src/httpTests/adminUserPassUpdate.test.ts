import request from 'sync-request';
import config from '../config.json';
import { getHTTPauthRegister, deleteHTTPClear} from './httpHelpers';
import {
  ERR_OLD_PASSWORD_INCORRECT,
  ERR_OLD_PASSWORD_MATCH,
  ERR_NEW_PASSWORD_USED,
  ERR_NEW_PASSWORD_SHORT,
  ERR_NEW_PASSWORD_LET,
  ERR_NEW_PASSWORD_NUM,
  ERR_INVALID_TOKEN
} from '../error';

const port = config.port;
const url = config.url;

describe('PUT /v1/admin/user/password', () => {
  let token: string;

  beforeEach(() => {
    deleteHTTPClear();
    const register = getHTTPauthRegister('faren@gmail.com', 'oldPassword123', 'Faren', 'Lesmana');
    const user = JSON.parse(register.body as string);
    console.log(user.token);
    token = user.token;
  });

  test('should return error if old password is not correct', () => {
    const res = request(
      'PUT',
      `${url}:${port}/v1/admin/user/password`,
      {
        json: {
          token: token,
          oldPassword: 'wrongOldPassword',
          newPassword: 'newPassword123'
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_OLD_PASSWORD_INCORRECT);
  });

  test('should return error if old password and new password match', () => {
    const res = request(
      'PUT',
      `${url}:${port}/v1/admin/user/password`,
      {
        json: {
          token: token,
          oldPassword: 'oldPassword123',
          newPassword: 'oldPassword123'
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_OLD_PASSWORD_MATCH);
  });

  test('should return error if new password has already been used before by this user', () => {
    const res1 = request(
      'PUT',
      `${url}:${port}/v1/admin/user/password`,
      {
        json: {
          token: token,
          oldPassword: 'oldPassword123',
          newPassword: 'newPassword123'
        },
        timeout: 100
      }
    );
    expect(res1.statusCode).toBe(200);

    const res2 = request(
      'PUT',
      `${url}:${port}/v1/admin/user/password`,
      {
        json: {
          token: token,
          oldPassword: 'newPassword123',
          newPassword: 'oldPassword123'
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res2.body as string);
    expect(res2.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_NEW_PASSWORD_USED);
  });

  test('should return error if new password is less than 8 characters', () => {
    const res = request(
      'PUT',
      `${url}:${port}/v1/admin/user/password`,
      {
        json: {
          token: token,
          oldPassword: 'oldPassword123',
          newPassword: 'short'
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_NEW_PASSWORD_SHORT);
  });

  test('should return error if new password does not contain at least one number', () => {
    const res = request(
      'PUT',
      `${url}:${port}/v1/admin/user/password`,
      {
        json: {
          token: token,
          oldPassword: 'oldPassword123',
          newPassword: 'password'
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_NEW_PASSWORD_NUM);
  });

  test('should return error if new password does not contain at least one letter', () => {
    const res = request(
      'PUT',
      `${url}:${port}/v1/admin/user/password`,
      {
        json: {
          token: token,
          oldPassword: 'oldPassword123',
          newPassword: '12345678'
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_NEW_PASSWORD_LET);
  });

  test('should update password successfully', () => {
    const res = request(
      'PUT',
      `${url}:${port}/v1/admin/user/password`,
      {
        json: {
          token: token,
          oldPassword: 'oldPassword123',
          newPassword: 'newPassword123'
        },
        timeout: 100
      }
    );
    expect(res.statusCode).toBe(200);
    const bodyObj = JSON.parse(res.body as string);
    expect(bodyObj).toEqual({});
  });

  test('Test 401 if token is missing', () => {
    const res = request(
      'PUT',
      `${url}:${port}/v1/admin/user/password`,
      {
        json: {
          oldPassword: 'oldPassword123',
          newPassword: 'newPassword123'
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(401);
    // expect(bodyObj).toEqual(ERR_INVALID_TOKEN);
  });
});
