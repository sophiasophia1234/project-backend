import request from 'sync-request';
import config from '../config.json';
import {
  ERR_INVALID_TOKEN,
  ERR_INVALID_USER_AUTHORISATION,
  ERR_NAME_IS_USED,
  ERR_INVALID_NAME,
  ERR_NAME_LESS,
  ERR_NAME_MORE
} from '../error';

const port = config.port;
const url = config.url;

describe('GET /v1/admin/quiz/{quizid}/name', () => {
  let token: string; // Define token here
  let quizId: number; // Define quizId here

  beforeEach(() => {
    const registerUser = request(
      'POST',
          `${url}:${port}/v1/admin/auth/register`,
          {
            json: {
              email: 'sop@gmail.com',
              password: 'testing123',
              firstName: 'Sophia',
              lastName: 'Maghirang'
            }
          }
    );

    const register = JSON.parse(registerUser.body as string);
    token = register.token;

    const createQuiz = request(
      'POST',
          `${url}:${port}/v1/admin/quiz`,
          {
            json: {
              token: token,
              name: 'Quiz1',
              description: 'description of quiz 1'
            }
          }
    );

    const quiz = JSON.parse(createQuiz.body as string);
    quizId = quiz.quizId;
  });

  test('Test 401 if token is missing', () => {
    const res = request(
      'PUT',
        `${url}:${port}/v1/admin/quiz/${quizId}/name`,
        {
          json: {
            name: 'New Quiz Name'
          },
          timeout: 100
        }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(401);
    expect(bodyObj).toEqual(ERR_INVALID_TOKEN);
  });

  test('Test 403 if user is not authorized', () => {
    const res = request(
      'PUT',
        `${url}:${port}/v1/admin/quiz/${quizId}/name`,
        {
          json: {
            token: 'invalidtoken',
            name: 'New Quiz Name'
          },
          timeout: 100
        }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(403);
    expect(bodyObj).toEqual(ERR_INVALID_USER_AUTHORISATION);
  });

  test('Test 200 if request is valid', () => {
    const res = request(
      'PUT',
        `${url}:${port}/v1/admin/quiz/${quizId}/name`,
        {
          json: {
            token: token,
            name: 'New Quiz Name'
          },
          timeout: 100
        }
    );
    // const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(200);
    expect(res.body.toString()).toEqual('{}');
  });

  test('Test 400 if Name contains invalid characters', () => {
    const res = request(
      'PUT',
        `${url}:${port}/v1/admin/quiz/${quizId}/question`,
        {
          json: {
            token: token,
            name: 'Quiz!@# invalid!'
          },
          timeout: 100
        }
    );
    const bodyObj = JSON.parse(res.body as string); // Define bodyObj here
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_INVALID_NAME);
  });

  test('Test 400 if Name is less than 3 characters', () => {
    const res = request(
      'PUT',
        `${url}:${port}/v1/admin/quiz/${quizId}/question`,
        {
          json: {
            token: token,
            name: 'Qu'
          },
          timeout: 100
        }
    );
    const bodyObj = JSON.parse(res.body as string); // Define bodyObj here
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_NAME_LESS);
  });

  test('Test 400 if Name is more than 30 characters', () => {
    const res = request(
      'PUT',
        `${url}:${port}/v1/admin/quiz/${quizId}/question`,
        {
          json: {
            token: token,
            name: 'Name is too loooooooooooooooooooooooooooooonoooooooong'
          },
          timeout: 100
        }
    );
    const bodyObj = JSON.parse(res.body as string); // Define bodyObj here
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_NAME_MORE);
  });

  test('Test 400 if Name is already used', () => {
    const res = request(
      'PUT',
        `${url}:${port}/v1/admin/quiz/${quizId}/question`,
        {
          json: {
            token: token,
            name: 'Quiz1'
          },
          timeout: 100
        }
    );
    const bodyObj = JSON.parse(res.body as string); // Define bodyObj here
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_NAME_IS_USED);
  });

  //     test('test 401 if token is empty or invalid', async () => {
  //     const res = request(
  //         'GET',
  //         `${url}:${port}/v1/admin/quiz/{quizid}/name`,
  //                 {
  //                     json: { name: 'New Quiz Name' },
  //                     timeout: 100
  //                 }
  //     );
  //     const bodyObj = JSON.parse(res.body as string);
  //     expect(res.statusCode).toBe(401);
  //     expect(bodyObj).toEqual(ERR_INVALID_TOKEN);
  //     });

  //   test('test 401 if token is empty or invalid', async () => {
  //     const res = request(
  //       'GET',
  //                 `${url}:${port}/v1/admin/quiz/list`,
  //                 {
  //                     json: { name: 'New Quiz Name' },
  //                     timeout: 100
  //                 }
  //     );
  //     const bodyObj = JSON.parse(res.body as string);
  //     expect(res.statusCode).toBe(401);
  //     expect(bodyObj).toEqual(ERR_INVALID_TOKEN);
  //   });

  test('Test 200 if request is valid', () => {
    const res = request(
      'GET',
            `${url}:${port}/v1/admin/quiz/list`,
            {
              json: { name: 'New Quiz Name' },
              timeout: 100
            }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(200);
    expect(bodyObj).toEqual({
      quizzes: [
        {
          quizId: quizId,
          name: 'Quiz1',

        }
      ]
    });
  });
});
