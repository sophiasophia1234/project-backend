import request from 'sync-request-curl';
import config from '../config.json';
import { ERR_INVALID_TOKEN, ERR_INVALID_USER_AUTHORISATION, ERR_LESS_QUESTION, ERR_LESS_ANS, ERR_NOT_POS_DURATON, ERR_SUM_DUR_MORE, ERR_MORE_POINT, ERR_LESS_CHAR_ANS, ERR_ANS_DUPLICATE, ERR_NO_CORRECT_ANS } from '../error';

const port = config.port;
const url = config.url;

describe('PUT /v1/admin/quiz/:quizid/question/:questionid', () => {
  let userToken: string, quizId: number, questionId: number, anotherUserToken: string;

  beforeEach(() => {
    // Register and login a user
    const register = request(
      'POST',
      `${url}:${port}/v1/admin/auth/register`,
      {
        json: {
          email: 'sop@gmail.com',
          password: 'testing123',
          firstName: 'Sophia',
          lastName: 'Maghirang'
        }
      }
    );
    const user = JSON.parse(register.body as string);
    userToken = user.token;

    // Create a quiz by the user
    const createQuiz = request(
      'POST',
      `${url}:${port}/v1/admin/quiz/create`,
      {
        json: {
          token: userToken,
          name: 'Quiz1',
          description: 'description of quiz 1',
        }
      }
    );
    const createdQuiz = JSON.parse(createQuiz.body as string);
    quizId = createdQuiz.quizId;

    // Create a question for the quiz
    const createQuestion = request(
      'POST',
      `${url}:${port}/v1/admin/quiz/${quizId}/question`,
      {
        json: {
          token: userToken,
          questionBody: {
            Question: 'Who is the Monarch of England?',
            duration: 4,
            points: 5,
            answers: [
              { answer: 'Prince Charles', correct: true },
              { answer: 'Queen Elizabeth', correct: false },
            ],
          }
        }
      }
    );
    const createdQuestion = JSON.parse(createQuestion.body as string);
    questionId = createdQuestion.questionId;

    // Register and login another user
    const anotherRegister = request(
      'POST',
      `${url}:${port}/v1/admin/auth/register`,
      {
        json: {
          email: 'faren@gmail.com',
          password: 'password123',
          firstName: 'Faren',
          lastName: 'Lesmana'
        }
      }
    );
    const anotherUser = JSON.parse(anotherRegister.body as string);
    anotherUserToken = anotherUser.token;
  });

  test('Test 400 if question ID is invalid', () => {
    const res = request(
      'PUT',
      `${url}:${port}/v1/admin/quiz/${quizId}/question/9999`, // Invalid questionId
      {
        json: {
          token: userToken,
          questionBody: {
            Question: 'Who is the Monarch of England?',
            duration: 4,
            points: 5,
            answers: [
              { answer: 'Prince Charles', correct: true },
              { answer: 'Queen Elizabeth', correct: false },
            ],
          }
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_INVALID_TOKEN);
  });

  test('Test 400 if question string length is invalid', () => {
    const res = request(
      'PUT',
      `${url}:${port}/v1/admin/quiz/${quizId}/question/${questionId}`,
      {
        json: {
          token: userToken,
          questionBody: {
            Question: 'Who?', // Too short
            duration: 4,
            points: 5,
            answers: [
              { answer: 'Prince Charles', correct: true },
              { answer: 'Queen Elizabeth', correct: false },
            ],
          }
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_LESS_QUESTION);
  });

  test('Test 400 if number of answers is invalid', () => {
    const res = request(
      'PUT',
      `${url}:${port}/v1/admin/quiz/${quizId}/question/${questionId}`,
      {
        json: {
          token: userToken,
          questionBody: {
            Question: 'Who is the Monarch of England?',
            duration: 4,
            points: 5,
            answers: [
              { answer: 'Prince Charles', correct: true },
            ], // Less than 2 answers
          }
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_LESS_ANS);
  });

  test('Test 400 if question duration is not a positive number', () => {
    const res = request(
      'PUT',
      `${url}:${port}/v1/admin/quiz/${quizId}/question/${questionId}`,
      {
        json: {
          token: userToken,
          questionBody: {
            Question: 'Who is the Monarch of England?',
            duration: -1, // Invalid duration
            points: 5,
            answers: [
              { answer: 'Prince Charles', correct: true },
              { answer: 'Queen Elizabeth', correct: false },
            ],
          }
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_NOT_POS_DURATON);
  });

  test('Test 400 if sum of question durations exceeds limit', () => {
    const res = request(
      'PUT',
      `${url}:${port}/v1/admin/quiz/${quizId}/question/${questionId}`,
      {
        json: {
          token: userToken,
          questionBody: {
            Question: 'Who is the Monarch of England?',
            duration: 181, // Additional 4 seconds making total > 3 minutes
            points: 5,
            answers: [
              { answer: 'Prince Charles', correct: true },
              { answer: 'Queen Elizabeth', correct: false },
            ],
          }
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_SUM_DUR_MORE);
  });

  test('Test 400 if points awarded are invalid', () => {
    const res = request(
      'PUT',
      `${url}:${port}/v1/admin/quiz/${quizId}/question/${questionId}`,
      {
        json: {
          token: userToken,
          questionBody: {
            Question: 'Who is the Monarch of England?',
            duration: 4,
            points: 11, // Invalid points (greater than 10)
            answers: [
              { answer: 'Prince Charles', correct: true },
              { answer: 'Queen Elizabeth', correct: false },
            ],
          }
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_MORE_POINT);
  });

  test('Test 400 if length of any answer is invalid', () => {
    const res = request(
      'PUT',
      `${url}:${port}/v1/admin/quiz/${quizId}/question/${questionId}`,
      {
        json: {
          token: userToken,
          questionBody: {
            Question: 'Who is the Monarch of England?',
            duration: 4,
            points: 5,
            answers: [
              { answer: '', correct: true }, // Invalid answer (too short)
              { answer: 'Queen Elizabeth', correct: false },
            ],
          }
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_LESS_CHAR_ANS);
  });

  test('Test 400 if answer strings are duplicates', () => {
    const res = request(
      'PUT',
      `${url}:${port}/v1/admin/quiz/${quizId}/question/${questionId}`,
      {
        json: {
          token: userToken,
          questionBody: {
            Question: 'Who is the Monarch of England?',
            duration: 4,
            points: 5,
            answers: [
              { answer: 'Prince Charles', correct: true },
              { answer: 'Prince Charles', correct: false }, // Duplicate answer
            ],
          }
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_ANS_DUPLICATE);
  });

  test('Test 400 if there are no correct answers', () => {
    const res = request(
      'PUT',
    `${url}:${port}/v1/admin/quiz/${quizId}/question/${questionId}`,
    {
      json: {
        token: userToken,
        questionBody: {
          Question: 'Who is the Monarch of England?',
          duration: 4,
          points: 5,
          answers: [
            { answer: 'Prince Charles', correct: false },
            { answer: 'Queen Elizabeth', correct: false }, // No correct answer
          ],
        }
      },
      timeout: 100
    }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_NO_CORRECT_ANS);
  });

  test('Test 401 if token is invalid', () => {
    const res = request(
      'PUT',
    `${url}:${port}/v1/admin/quiz/${quizId}/question/${questionId}`,
    {
      json: {
        token: 'invalidtoken',
        questionBody: {
          Question: 'Who is the Monarch of England?',
          duration: 4,
          points: 5,
          answers: [
            { answer: 'Prince Charles', correct: true },
            { answer: 'Queen Elizabeth', correct: false },
          ],
        }
      },
      timeout: 100
    }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(401);
    expect(bodyObj).toEqual(ERR_INVALID_TOKEN); // add the error message in error.ts
  });

  test('Test 401 if token is empty', () => {
    const res = request(
      'PUT',
    `${url}:${port}/v1/admin/quiz/${quizId}/question/${questionId}`,
    {
      json: {
        token: '',
        questionBody: {
          Question: 'Who is the Monarch of England?',
          duration: 4,
          points: 5,
          answers: [
            { answer: 'Prince Charles', correct: true },
            { answer: 'Queen Elizabeth', correct: false },
          ],
        }
      },
      timeout: 100
    }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(401);
    expect(bodyObj).toEqual(ERR_INVALID_TOKEN); // add the error message in error.ts
  });

  test('Test 403 if user is not the owner of the quiz', () => {
    const res = request(
      'PUT',
    `${url}:${port}/v1/admin/quiz/${quizId}/question/${questionId}`,
    {
      json: {
        token: anotherUserToken,
        questionBody: {
          Question: 'Who is the Monarch of England?',
          duration: 4,
          points: 5,
          answers: [
            { answer: 'Prince Charles', correct: true },
            { answer: 'Queen Elizabeth', correct: false },
          ],
        }
      },
      timeout: 100
    }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(403);
    expect(bodyObj).toEqual(ERR_INVALID_USER_AUTHORISATION); // add the error message in error.ts
  });

  test('Test 200 if request is valid', () => {
    const res = request(
      'PUT',
    `${url}:${port}/v1/admin/quiz/${quizId}/question/${questionId}`,
    {
      json: {
        token: userToken,
        questionBody: {
          Question: 'Who is the Monarch of England?',
          duration: 5,
          points: 5,
          answers: [
            { answer: 'Prince Charles', correct: true },
            { answer: 'Queen Elizabeth', correct: false },
          ],
        }
      },
      timeout: 100
    }
    );
    expect(res.statusCode).toBe(200);
    const bodyObj = JSON.parse(res.body as string);
    expect(bodyObj).toEqual({});
  });
});
