import request from 'sync-request';
import { ERR_INVALID_TOKEN } from '../error';
import config from '../config.json';

import { getHTTPauthRegister, getHTTPQuizCreate, deleteHTTPClear } from './httpHelpers';

const port = config.port;
const url = config.url;

describe('GET /v1/admin/quiz/list', () => {
  let userToken: string, quizId: number;
  beforeEach(() => {
    deleteHTTPClear();
    const register = getHTTPauthRegister('yaran@gmail.com', '1234abcd!@$', 'Yaran', 'Zhang');
    const user = JSON.parse(register.body as string);
    userToken = user.token;

    const QuizCreate = getHTTPQuizCreate(userToken, 'Quiz1', 'description of quiz1');
    const createdQuiz = JSON.parse(QuizCreate.body as string);
    quizId = createdQuiz.quizId;
  });

  test('Return 401 if token is empty or invalid', async () => {
    const res = request(
      'GET',
                `${url}:${port}/v1/admin/quiz/list`,
                {
                  qs: {
                    token: 'validtoken',
                  },
                  timeout: 100
                }

    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(401);
    expect(bodyObj).toEqual(ERR_INVALID_TOKEN);
  });
  test('Return 200 if request is valid', () => {
    const res = request(
      'GET',

            `${url}:${port}/v1/admin/quiz/list`,
            {
              qs: {
                token: userToken,
              },
              timeout: 100
            }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(200);
    expect(bodyObj).toEqual({
      quizzes: [
        {
          quizId: quizId,
          name: 'Quiz1',

        }
      ]
    });
  });
});
