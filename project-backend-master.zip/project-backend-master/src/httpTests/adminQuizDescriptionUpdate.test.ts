import request from 'sync-request-curl';
import config from '../config.json';
import { ERR_INVALID_TOKEN, ERR_INVALID_DESCRIPTION, ERR_INVALID_USER_AUTHORISATION } from '../error';
import {
  getHTTPauthRegister, getHTTPQuizCreate,
  getHTTPQuizInfo, deleteHTTPClear, getHTTPQuizDescriptionUpdate
} from './httpHelpers';

import { Quiz } from '../dataStore';

const port = config.port;
const url = config.url;

describe('PUT /v1/admin/quiz/:quizid/description', () => {
  let userToken: string, quizDescription: string, QuizID: number, anotherUserToken: string;

  beforeEach(() => {
    deleteHTTPClear();
    const register = getHTTPauthRegister('faren@gmail.com', 'testing123', 'Faren', 'Lesmana');
    const user = JSON.parse(register.body as string);
    console.log(user.token);
    userToken = user.token;

    const createQuiz = getHTTPQuizCreate(userToken, 'Quiz1', 'description of quiz1');
    const quiz = JSON.parse(createQuiz.body as string);
    console.log(quiz.quizId);
    QuizID = quiz.quizId
    console.log("quizID:");
    console.log(QuizID);

    // const register2 = getHTTPauthRegister('yaran@gmail.com', '1234abcd!@$', 'Yaran', 'Zhang');
    // const user2 = JSON.parse(register.body as string);
    // console.log(user2.token);
    // anotherUserToken = user2.token;
  });

  test('Test 400 if description is more than 100 characters', () => {
    const res = getHTTPQuizDescriptionUpdate(userToken, QuizID, 'a'.repeat(101))
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_INVALID_DESCRIPTION); // add the error message in error.ts
  });

  test('Test 401 if token is invalid', () => {
    const res = getHTTPQuizDescriptionUpdate('invalidtoken', QuizID, 'update description for quiz1')
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(401);
    expect(bodyObj).toEqual(ERR_INVALID_TOKEN); // add the error message in error.ts
  });

  test('Test 401 if token is empty', () => {
    const res = getHTTPQuizDescriptionUpdate('', QuizID, 'update description for quiz1')
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(401);
    expect(bodyObj).toEqual(ERR_INVALID_TOKEN); // add the error message in error.ts
  });

  test('Test 403 if user is not the owner of the quiz', () => {
    const res = getHTTPQuizDescriptionUpdate(anotherUserToken, QuizID, 'update description for quiz1')
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(403);
    expect(bodyObj).toEqual(ERR_INVALID_USER_AUTHORISATION);
  });

  test('Test 200 if request is valid', () => {
    const res = getHTTPQuizDescriptionUpdate(userToken, QuizID, 'update description for quiz1')
    expect(res.statusCode).toBe(200);
    const bodyObj = JSON.parse(res.body as string);
    expect(bodyObj).toEqual({});
  });
});
