import request from 'sync-request';
import { port, url } from '../config.json';
import {
  ERR_INVALID_TOKEN,
  ERR_INVALID_USER_AUTHORISATION,
  ERR_INVALID_NAME,
  ERR_NAME_LESS,
  ERR_NAME_IS_USED,
  ERR_NAME_MORE
} from '../error';

describe('POST /v1/admin/quiz/{quizid}/question/{questionid}/duplicate', () => {
  let token: string; // Define token here
  let questionId: number; // Define questionId here
  let quizId: number; // Define quizId here

  beforeEach(() => {
    const registerUser = request(
      'POST',
          `${url}:${port}/v1/admin/auth/register`,
          {
            json: {
              email: 'sop@gmail.com',
              password: 'testing123',
              firstName: 'Sophia',
              lastName: 'Maghirang'
            }
          }
    );

    const register = JSON.parse(registerUser.body as string);
    token = register.session.token;
    const sessionId = register.session.sessionId; // eslint-disable-line @typescript-eslint/no-unused-vars

    const createQuiz = request(
      'POST',
          `${url}:${port}/v1/admin/quiz`,
          {
            json: {
              token: token,
              name: 'Quiz1',
              description: 'description of quiz 1'
            }
          }
    );

    const quiz = JSON.parse(createQuiz.body as string);
    quizId = quiz.quizId;

    const createQuestion = request(
      'POST',
      `${url}:${port}/v1/admin/quiz/${quizId}/question`,
      {
        json: {
          token: token,
          questionBody: {
            question: 'Who is the Monarch of England?',
            duration: 4,
            points: 5,
            answers: [
              {
                answer: 'Prince Charles',
                correct: true
              }
            ]
          }
        }
      }
    );
    const question = JSON.parse(createQuestion.body as string);
    questionId = question.questionId;
  });

  test('Test 401 if token is missing', () => {
    const res = request(
      'POST',
      `${url}:${port}/v1/admin/quiz/{quizid}/question/{questionid}/duplicate`,
      {
        json: {},
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(401);
    expect(bodyObj).toEqual(ERR_INVALID_TOKEN);
  });

  test('Test 403 if user is not authorized', () => {
    const res = request(
      'POST',
      `${url}:${port}/v1/admin/quiz/{quizid}/question/{questionid}/duplicate`,
      {
        json: {
          token: token,
        },
        timeout: 100
      }
    );
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(403);
    expect(bodyObj).toEqual(ERR_INVALID_USER_AUTHORISATION);
  });

  test('Test 200 if request is valid', () => {
    const res = request(
      'PUT',
        `${url}:${port}/v1/admin/quiz/${quizId}/question/${questionId}/duplicate`,
        {
          json: {
            token: token,
            questionBody: {
              question: 'Who is the Monarch of England?',
              duration: 4,
              points: 5,
              answers: [
                {
                  answer: 'Prince Charles',
                  correct: true
                }
              ]
            }
          },
          timeout: 100
        }
    );
    // const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(200);
    expect(res.body.toString()).toEqual('{}');
  });

  test('Test 400 if Question Id is not valid', () => {
    const res = request(
      'PUT',
        `${url}:${port}/v1/admin/quiz/{quizid}/question/{questionid}/duplicate`,
        {
          json: {
            token: token,
            questionBody: {
              question: 'Who is the Monarch of England?',
              duration: 4,
              points: 5,
              answers: [
                {
                  answer: 'Prince Charles',
                  correct: true
                }
              ]
            }
          },
          timeout: 100
        }
    );
    const bodyObj = JSON.parse(res.body as string); // Define bodyObj here
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_INVALID_NAME);
  });

  test('Test 400 if Name is less than 3 characters', () => {
    const res = request(
      'PUT',
        `${url}:${port}/v1/admin/quiz/{quizid}/question/{questionid}/duplicate`,
        {
          json: {
            token: token,
            name: 'Qu'
          },
          timeout: 100
        }
    );
    const bodyObj = JSON.parse(res.body as string); // Define bodyObj here
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_NAME_LESS);
  });

  test('Test 400 if Name is more than 30 characters', () => {
    const res = request(
      'PUT',
        `${url}:${port}/v1/admin/quiz/{quizid}/question/{questionid}/duplicate`,
        {
          json: {
            token: token,
            name: 'Name is too loooooooooooooooooooooooooooooonoooooooong'
          },
          timeout: 100
        }
    );
    const bodyObj = JSON.parse(res.body as string); // Define bodyObj here
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_NAME_MORE);
  });

  test('Test 400 if Name is already used', () => {
    const res = request(
      'PUT',
        `${url}:${port}/v1/admin/quiz/{quizid}/question/{questionid}/duplicate`,
        {
          json: {
            token: token,
            name: 'Quiz1'
          },
          timeout: 100
        }
    );
    const bodyObj = JSON.parse(res.body as string); // Define bodyObj here
    expect(res.statusCode).toBe(400);
    expect(bodyObj).toEqual(ERR_NAME_IS_USED);
  });
});
