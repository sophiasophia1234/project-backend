import request from 'sync-request';
import config from '../config.json';
import { ERR_INVALID_TOKEN } from '../error';
import { getHTTPauthRegister, getHTTPQuizCreate } from './httpHelpers';

jest.mock('./server');

const port = config.port;
const url = config.url;

const ERR_NOT_ENOUGH_QUIZ_IN_TRASH = { error: 'One or more of the Quiz IDs is not currently in the trash' };
const ERR_USER_NOT_AUTHORIZED = { error: 'Valid token is provided, but one or more of the Quiz IDs refers to a quiz that this current user does not own' };

describe('DELETE /v1/admin/quiz/trash/empty', () => {
  let userToken: string, quizId: number;
  beforeEach(() => {
    deleteHTTPClear();
    const register = getHTTPauthRegister('yaran@gmail.com', '1234abcd!@$', 'Yaran', 'Zhang');
    const user = JSON.parse(register.body as string);
    userToken = user.token;


    const QuizCreate = getHTTPQuizCreate(userToken, 'Quiz1', 'description of quiz1');
    // console.log(QuizCreate);
    const createdQuiz = JSON.parse(QuizCreate.body as string);
    quizId = createdQuiz.quizId;

    deleteHTTPRemove(userToken, quizId);
  });

    test('Success empty the trash', () => {
      deleteHTTPTrashEmpty(userToken, [quizId]);
      expect(postHTTPQuizRestore(userToken, quizId).statusCode).toEqual(400);
    });

    test('should return 400 if one or more of the Quiz IDs is not currently in the trash', async () => {
      const res = request(
        'DELETE',
        `${url}:${port}/v1/admin/quiz/trash/empty`,
        {
          qs: {
            token: userToken,
            quizIds: [],
          },
        }
      );
      const bodyObj = JSON.parse(res.body as string);
      expect(res.statusCode).toBe(400);
    });
    test('should return 401 if token is empty or invalid', () => {
      const res = request(
        'DELETE',
            `${url}:${port}/v1/admin/quiz/trash/empty`,
            {
              qs: {
                token: '',
                quizIds: [quizId],
              },
            }
      );

      const bodyObj = JSON.parse(res.body as string);
      expect(res.statusCode).toBe(401);
    });

    test('should return 403 if one or more of the Quiz IDs refers to a quiz that this current user does not own', () => {
      const token1 = JSON.parse(getHTTPauthRegister('naray@gmail.com', '1234abcd!@$', 'Naray', 'Zhang').body as string).token;

      const res = request(
        'DELETE',
            `${url}:${port}/v1/admin/quiz/trash/empty`,
            {
              qs: {
                token: token1,
                quizIds: [0],
              },
            }
      );
      const bodyObj = JSON.parse(res.body as string);
      expect(res.statusCode).toBe(403);
    });
  });
