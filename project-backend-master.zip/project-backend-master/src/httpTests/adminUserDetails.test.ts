import request from 'sync-request-curl';
import config from '../config.json';
import { ERR_INVALID_TOKEN } from '../error';
import { getHTTPauthRegister, deleteHTTPClear, getHTTPLogin, getHTTPUserDetails } from './httpHelpers';
import { User } from '../dataStore'

const port = config.port;
const url = config.url;

describe('GET /v1/admin/user/details', () => {
  let userToken: string;

  beforeEach(() => {
    deleteHTTPClear();
    const register = getHTTPauthRegister('faren@gmail.com', 'testing123', 'Faren', 'Lesmana');
    const user = JSON.parse(register.body as string);
    console.log(user.token);
    userToken = user.token;
  });

  test('Test 401 if token is invalid', () => {
    const res = getHTTPUserDetails('invalidtoken');
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(401);
    expect(bodyObj).toEqual(ERR_INVALID_TOKEN);
  });

  test('Test 401 if token is empty', () => {
    const res = getHTTPUserDetails('');
    const bodyObj = JSON.parse(res.body as string);
    expect(res.statusCode).toBe(401);
    expect(bodyObj).toEqual(ERR_INVALID_TOKEN);
  });

  test('Test 200 if request is valid', () => {
    const res = getHTTPUserDetails(userToken)
    expect(res.statusCode).toBe(200);
    const selectedUser = JSON.parse(res.body as string);
    expect(selectedUser).toStrictEqual({
      user: {
        authUserId: 0,
        name: 'Faren Lesmana',
        email: 'faren@gmail.com',
        numSuccessfulLogins: 1,
        numFailedPasswordsSinceLastLogin: 0
      }
    });
  });
});
