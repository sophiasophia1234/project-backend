declare module 'sync-request' {
    function request(method: string, url: string, options?: any): any;
    export = request;
}
