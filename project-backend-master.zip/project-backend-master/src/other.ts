import { setData } from './dataStore';

function clear() {
  setData({
    users: [],
    quizzes: [],
    quizTrash: [],
    sessions: [],
    counter: 0
  });
}

export { clear };
