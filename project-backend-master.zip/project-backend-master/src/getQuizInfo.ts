import { getData } from './dataStore';

export const adminQuizInfo = (token: string, quizId: number) => {
  if (token === 'I have not been used!') {
    console.log('hahaha');
  }

  console.log(getData().quizzes);

  return getData().quizzes.map(quiz => {
    return {
      quizId: quiz.quizId,
      name: quiz.name,
      timeCreated: quiz.timeCreated,
      timeLastEdited: quiz.timeLastEdited,
      description: quiz.description,
      numQuestions: quiz.numQuestions,
      questions: quiz.questions,
      duration: quiz.duration
    };
  }).find(quiz => quiz.quizId === quizId);
};

export const adminQuizRemove = (token: string, quizId: number) => {
    const data = getData();

    for (let i = 0; i < data.quizzes.length; i++) {
        if (data.quizzes[i].quizId === quizId) {
            data.quizzes[i].timeLastEdited = Date.now() / 1000;
            data.quizTrash.push(data.quizzes[i]);
            data.quizzes[i] = null;
        } 
    }
        
    setData(data);

    return {};
};

export const adminQuizRestore = (token: string, quizId: number) => {
    const data = getData();

    const restoredQuiz = data.quizTrash.find(quiz => quiz.quizId === quizId);

    if (!restoredQuiz) {
        return { error: 'This quiz is not in trash!', statusCode: 400 };
    }

    data.quizzes[quizId] = restoredQuiz;
    data.quizzes[quizId].timeLastEdited = Date.now() / 1000;

    setData(data);

    return {};
};
