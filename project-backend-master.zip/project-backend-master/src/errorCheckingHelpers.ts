import { getData } from './dataStore'

const data = getData();

const isValidToken = (token: string) => {
    return token !== '' && data.sessions.find(session => session.sessionId === token);
};

const isValidQuiz = (quizId: number) => {
    return quizId >= 0 && quizId < data.quizzes.length && data.quizzes[quizId] != null;
};

const isQuizOwner = (token: string, quizId: number) => {
    return data.quizzes[quizId].authUserId == data.sessions.find(session => session.sessionId === token).authUserId;
};

const hasQuizWithSameName = (token: string, quizName: string) => {
    const authUserId = data.sessions.find(session => session.sessionId === token).authUserId;
    return data.quizzes.filter(quiz => quiz.authUserId === authUserId).find(quiz => quiz.name === quizName);
};

export{
    isValidToken,
    isValidQuiz,
    isQuizOwner,
    hasQuizWithSameName
}