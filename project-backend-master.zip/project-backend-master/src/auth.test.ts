import { adminAuthRegister, adminAuthLogin, adminUserPasswordUpdate, adminUserDetailsUpdate, adminUserDetails, adminAuthLogout } from './auth';
import { clear } from './other';
// import validator from 'validator';
import { setData, getData } from './dataStore';

describe('adminAuthRegister', () => {
  test('Check successful registration', () => {
    clear();
    const authUserId = adminAuthRegister(
      'sophia@gmail.com',
      '1234abcd',
      'Sophia',
      'Maghirang'
    );
    expect(authUserId).toStrictEqual({ authUserId });
  });

  test('check duplicate email', () => {
    clear();
    adminAuthRegister(
      'sophia@gmail.com',
      '1234abcd!@#$',
      'Sophia',
      'Maghirang'
    );
    const authUserId2 = adminAuthRegister(
      'sophia@gmail.com',
      '1234abcd!@#$',
      'Sophia',
      'Maghirang'
    );
    expect(authUserId2).toStrictEqual({ error: 'Email already used' });
  });

  test('check fail on short passwords', () => {
    clear();
    const authUserId1 = adminAuthRegister(
      'sophia@gmail.com',
      '',
      'Sophia',
      'Maghirang'
    );
    expect(authUserId1).toStrictEqual({ error: 'Password is too short' });

    const authUserId2 = adminAuthRegister(
      'sophia@gmail.com',
      '1',
      'Sophia',
      'Maghirang'
    );
    expect(authUserId2).toStrictEqual({ error: 'Password is too short' });

    const authUserId3 = adminAuthRegister(
      'sophia@gmail.com',
      '12',
      'Sophia',
      'Maghirang'
    );
    expect(authUserId3).toStrictEqual({ error: 'Password is too short' });

    const authUserId4 = adminAuthRegister(
      'sophia@gmail.com',
      '123',
      'Sophia',
      'Maghirang'
    );
    expect(authUserId4).toStrictEqual({ error: 'Password is too short' });

    const authUserId5 = adminAuthRegister(
      'sophia@gmail.com',
      '1234',
      'Sophia',
      'Maghirang'
    );
    expect(authUserId5).toStrictEqual({ error: 'Password is too short' });

    const authUserId6 = adminAuthRegister(
      'sophia@gmail.com',
      '12345',
      'Sophia',
      'Maghirang'
    );
    expect(authUserId6).toStrictEqual({ error: 'Password is too short' });

    const authUserId7 = adminAuthRegister(
      'sophia@gmail.com',
      '123456',
      'Sophia',
      'Maghirang'
    );
    expect(authUserId7).toStrictEqual({ error: 'Password is too short' });

    const authUserId8 = adminAuthRegister(
      'sophia@gmail.com',
      '1234567',
      'Sophia',
      'Maghirang'
    );
    expect(authUserId8).toStrictEqual({ error: 'Password is too short' });
  });

  test('Email does not satisfy validator', () => {
    clear();
    const result1 = adminAuthRegister(
      '@gmail.com',
      '123abcd',
      'Sophia',
      'Maghirang'
    );
    expect(result1).toStrictEqual({ error: 'Email is not validated' });

    const result2 = adminAuthRegister(
      'sophia@gmail',
      '123abcd',
      'Sophia',
      'Maghirang'
    );
    expect(result2).toStrictEqual({ error: 'Email is not validated' });
  });

  test('NameFirst contains invalid character', () => {
    clear();
    const firstName1 = adminAuthRegister(
      'sophia@gmail.com',
      '123',
      'Sophia123',
      'Maghirang'
    );
    expect(firstName1).toStrictEqual({
      error: 'First name contains invalid character'
    });

    const firstName2 = adminAuthRegister(
      'sophia@gmail.com',
      '123',
      'Sophi@a',
      'Maghirang'
    );
    expect(firstName2).toStrictEqual({
      error: 'First name contains invalid character'
    });
  });

  test('check NameFirst less than 2 or more than 20 characters', () => {
    clear();
    const authUserId2 = adminAuthRegister(
      'sophia@gmail.com',
      '1234abcd',
      'S',
      'Maghirang'
    );
    expect(authUserId2).toStrictEqual({
      error: 'First Name is too short'
    });

    const authUserId3 = adminAuthRegister(
      'sophia@gmail.com',
      '1234abcd',
      'Sophiaaaaaaaaaaaaaaaa',
      'Maghirang'
    );
    expect(authUserId3).toStrictEqual({
      error: 'First Name is too long'
    });
  });

  test('check NameLast for invalid characters', () => {
    clear();
    const authUserId1 = adminAuthRegister(
      'sophia@gmail.com',
      '1234abcd',
      'Sophia',
      'Maghirang88'
    );
    expect(authUserId1).toStrictEqual({
      error: 'Last Name has invalid characters'
    });

    const authUserId2 = adminAuthRegister(
      'sophia@gmail.com',
      '1234abcd',
      'Sophia',
      'Maghirang$$'
    );
    expect(authUserId2).toStrictEqual({
      error: 'Last Name has invalid characters'
    });

    const authUserId3 = adminAuthRegister(
      'sophia@gmail.com',
      '1234abcd',
      'Sophia',
      'Maghirang@@'
    );
    expect(authUserId3).toStrictEqual({
      error: 'Last Name has invalid characters'
    });

    const authUserId4 = adminAuthRegister(
      'sophia@gmail.com',
      '1234abcd',
      'Sophia',
      'Maghirang%%'
    );
    expect(authUserId4).toStrictEqual({
      error: 'Last Name has invalid characters'
    });

    const authUserId5 = adminAuthRegister(
      'sophia@gmail.com',
      '1234abcd',
      'Sophia',
      'Maghirang!!'
    );
    expect(authUserId5).toStrictEqual({
      error: 'Last Name has invalid characters'
    });
  });

  test('check NameLast less than 2 or more than 20 characters', () => {
    clear();
    const authUserId2 = adminAuthRegister(
      'sophia@gmail.com',
      '1234abcd',
      'Sophia',
      'M'
    );
    expect(authUserId2).toStrictEqual({
      error: 'Last Name is too short'
    });

    const authUserId3 = adminAuthRegister(
      'sophia@gmail.com',
      '1234abcd',
      'Sophia',
      'Maghiranggggggggggggg'
    );
    expect(authUserId3).toStrictEqual({
      error: 'Last Name is too long'
    });
  });

  test('Password does not contain at least one number and at least one letter', () => {
    clear();
    const authUserId1 = adminAuthRegister(
      'sophia@gmail.com',
      'abcdefgh',
      'Sophia',
      'Maghirang'
    );
    expect(authUserId1).toStrictEqual({
      error: 'Password does not contain at least one number'
    });

    const authUserId2 = adminAuthRegister(
      'sophia@gmail.com',
      '12345678',
      'Sophia',
      'Maghirang'
    );
    expect(authUserId2).toStrictEqual({
      error: 'Password does not contain at least one letter'
    });
  });
});

describe('adminAuthLogin', () => {
  test('check if email does not exist', () => {
    const authUserId = adminAuthLogin('fare@gmail.com', 'testing123');
    expect(authUserId).toEqual({ error: 'Email does not exist' });
  });

  test('checking password correctness', () => {
    const authUserId = adminAuthLogin('faren@gmail.com', 'testing12');
    expect(authUserId).toEqual({ error: 'Wrong password' });
  });

  test('Login successful first user', () => {
    const authUserId = adminAuthLogin('faren@gmail.com', 'testing123');
    expect(authUserId).toEqual({ authUserId: 1 });
  });

  test('Login successful second user', () => {
    const authUserId2 = adminAuthLogin('sophia@gmail.com', '123testing');
    expect(authUserId2).toEqual({ authUserId: 2 });
  });
});

describe('adminUserPasswordUpdate', () => {
  test('Password is less than 8 characters', () => {
    clear();
    adminAuthRegister('sop@gmail.com', 'OldPass1234', 'Sophia', 'Maghirang');
    const result = adminUserPasswordUpdate(1, 'OldPass1234', 'NewPas4');
    expect(result).toStrictEqual({ error: 'New password is too short' });
  });

  test('Password does not contain at least one number and at least one letter', () => {
    clear();
    adminAuthRegister('sop@gmail.com', 'OldPass1234', 'Sophia', 'Maghirang');
    const result1 = adminUserPasswordUpdate(1, 'OldPass1234', 'NewPassword');
    expect(result1).toStrictEqual({ error: 'New password does not contain at least one number' });

    const result2 = adminUserPasswordUpdate(1, 'OldPass1234', '12345678');
    expect(result2).toStrictEqual({ error: 'New password does not contain at least one letter' });
  });

  test('Old Password is not the correct old password', () => {
    clear();
    adminAuthRegister('sop@gmail.com', 'OldPass1234', 'Sophia', 'Maghirang');
    const result = adminUserPasswordUpdate(1, 'WrongOldPassword123', 'NewPass1234');
    expect(result).toStrictEqual({ error: 'Old password is incorrect' });
  });

  test('Old Password and New Password match exactly', () => {
    clear();
    adminAuthRegister('sop@gmail.com', 'OldPass1234', 'Sophia', 'Maghirang');
    const result = adminUserPasswordUpdate(1, 'OldPass1234', 'OldPass1234');
    expect(result).toStrictEqual({ error: 'Old Password and New Password match exactly' });
  });

  test('New Password has already been used before by this user', () => {
    clear();
    const data = getData();
    const user = {
      authUserId: 1,
      email: 'sop@gmail.com',
      password: 'OldPass1234',
      nameFirst: 'Sophia',
      nameLast: 'Maghirang',
      numSuccesfulLogins: 0,
      numFailedPasswordsSinceLastLogin: 0,
      quizOwn: [],
      passwordLog: ['OldPass1234', 'OldPass12345']
    };
    data.users.push(user);
    setData(data);

    const result = adminUserPasswordUpdate(1, 'OldPass1234', 'OldPass12345');
    expect(result).toStrictEqual({ error: 'New Password has already been used before' });
  });

  test('Password updated successfully', () => {
    clear();
    adminAuthRegister('sop@gmail.com', 'OldPass1234', 'Sophia', 'Maghirang');
    const result = adminUserPasswordUpdate(1, 'OldPass1234', 'NewPass1234');
    expect(result).toStrictEqual({});
  });
});

describe('adminUserDetailsUpdate', () => {
//   beforeEach(() => {
//     setData({
//       users: [
//         {
//           authUserId: 1,
//           email: 'sophia@gmail.com',
//           nameFirst: 'Sophia',
//           nameLast: 'Maghirang'
//         }
//       ],
//     });
//   });

  test('check if email address is already being used', () => {
    clear();
    adminAuthRegister(
      'sop@gmail.com',
      'OldPass1234',
      'Sophia',
      'Maghirang'
    );
    const emailExistence = adminUserDetailsUpdate(
      1,
      'sop@gmail.com',
      'Sophia',
      'Maghirang'
    );
    expect(emailExistence).toStrictEqual({
      error: 'Email already used'
    });
  });

  test('check if Email satisfy validator', () => {
    clear();
    adminAuthRegister(
      'sop@gmail.com',
      'OldPass1234',
      'Sophia',
      'Maghirang'
    );
    const emailValid = adminUserDetailsUpdate(
      1,
      '@gmail.com',
      'Sophia',
      'Maghirang'
    );
    expect(emailValid).toStrictEqual({ error: 'Invalid email' });
  });

  test('check nameFirst for special characters', () => {
    clear();
    adminAuthRegister(
      'sop@gmail.com',
      'OldPass1234',
      'Sophia',
      'Maghirang'
    );
    const nameFirstSymbols = adminUserDetailsUpdate(
      1,
      'sophia@gmail.com',
      'Sophia@%&',
      'Maghirang'
    );
    expect(nameFirstSymbols).toStrictEqual({
      error: 'First name contains special character'
    });
  });

  test('check nameFirst length', () => {
    clear();
    adminAuthRegister(
      'sop@gmail.com',
      'OldPass1234',
      'Sophia',
      'Maghirang'
    );
    const nameFirstLength1 = adminUserDetailsUpdate(
      1,
      'sophia@gmail.com',
      'S',
      'Maghirang'
    );
    expect(nameFirstLength1).toStrictEqual({
      error: 'First Name is too short'
    });

    const nameFirstLength2 = adminUserDetailsUpdate(
      1,
      'sophia@gmail.com',
      'Sophiaaaaaaaaaaaaaaaa',
      'Maghirang'
    );
    expect(nameFirstLength2).toStrictEqual({
      error: 'First Name is too long'
    });
  });

  test('check nameLast for special characters', () => {
    clear();
    adminAuthRegister(
      'sop@gmail.com',
      'OldPass1234',
      'Sophia',
      'Maghirang'
    );
    const nameFirstSymbols = adminUserDetailsUpdate(
      1,
      'sophia@gmail.com',
      'Sophia',
      'Maghirang#@$'
    );
    expect(nameFirstSymbols).toStrictEqual({
      error: 'Last name contains special characters'
    });
  });

  test('check nameLast length', () => {
    clear();
    adminAuthRegister(
      'sop@gmail.com',
      'OldPass1234',
      'Sophia',
      'Maghirang'
    );
    const nameLastLength = adminUserDetailsUpdate(
      1,
      'sophia@gmail.com',
      'Sophia',
      'M'
    );
    expect(nameLastLength).toStrictEqual({
      error: 'Last Name is too short'
    });

    const nameLastLength2 = adminUserDetailsUpdate(
      1,
      'sophia@gmail.com',
      'Sophia',
      'Maghiranggggggggggggg'
    );
    expect(nameLastLength2).toStrictEqual({
      error: 'Last Name is too long'
    });
  });

  test('adminUserDetailsUpdate success', () => {
    clear();
    adminAuthRegister(
      'sop@gmail.com',
      'OldPass1234',
      'Sophia',
      'Maghirang'
    );
    const result = adminUserDetailsUpdate(
      1,
      'sophia@gmail.com',
      'Sophia',
      'Maghirang'
    );
    expect(result).toStrictEqual({});
  });
});

describe('adminUserDetails', () => {
  test('Retrieve user details for valid user ID after registered', () => {
    expect(adminUserDetails(1)).toStrictEqual({
      user: {
        userId: 1,
        name: 'Faren Lesmana',
        email: 'faren@gmail.com',
        numSuccessfulLogins: 1,
        numFailedPasswordsSinceLastLogin: 0
      }
    });
  });

  test('Retrieve user details for valid user ID after one login', () => {
    adminAuthLogin('faren@gmail.com', 'testing123');
    const result = adminUserDetails(1);

    expect(result).toStrictEqual({
      user: {
        userId: 1,
        name: 'Faren Lesmana',
        email: 'faren@gmail.com',
        numSuccessfulLogins: 2,
        numFailedPasswordsSinceLastLogin: 0
      }
    });
  });

  test('Retrieve user details for valid user ID after one failed login', () => {
    adminAuthLogin('faren@gmail.com', 'testing');
    const result = adminUserDetails(1);

    expect(result).toStrictEqual({
      user: {
        userId: 1,
        name: 'Faren Lesmana',
        email: 'faren@gmail.com',
        numSuccessfulLogins: 1,
        numFailedPasswordsSinceLastLogin: 1
      }
    });
  });

  test('Retrieve user details for valid user ID after one failed and two succesful logins', () => {
    adminAuthLogin('faren@gmail.com', 'testing');
    adminAuthLogin('faren@gmail.com', 'testing123');
    adminAuthLogin('faren@gmail.com', 'testing123');
    const result = adminUserDetails(1);

    expect(result).toStrictEqual({
      user: {
        userId: 1,
        name: 'Faren Lesmana',
        email: 'faren@gmail.com',
        numSuccessfulLogins: 3,
        numFailedPasswordsSinceLastLogin: 0
      }
    });
  });

  test('Retrieve user details for valid user ID after five failed logins', () => {
    adminAuthLogin('faren@gmail.com', 'testing12');
    adminAuthLogin('faren@gmail.com', 'testing1');
    adminAuthLogin('faren@gmail.com', 'testing');
    adminAuthLogin('faren@gmail.com', 'testin');
    adminAuthLogin('faren@gmail.com', 'testi');
    const result = adminUserDetails(1);

    expect(result).toStrictEqual({
      user: {
        userId: 1,
        name: 'Faren Lesmana',
        email: 'faren@gmail.com',
        numSuccessfulLogins: 1,
        numFailedPasswordsSinceLastLogin: 5
      }
    });
  });

  test('Error for invalid user ID', () => {
    const result = adminUserDetails(999);
    expect(result.error).toBe('AuthUserId is not a valid user');
  });
});

// function initializeTestData() {
//   setData({
//     users: [
//       {
//         authUserId: 1,
//         nameFirst: 'Faren',
//         nameLast: 'Lesmana',
//         email: 'faren@gmail.com',
//         password: 'testing123',
//         numSuccesfulLogins: 1,
//         numFailedPasswordsSinceLastLogin: 0,
//         quizOwn: [1],
//         passwordLog: ["oldPassword"]
//       },
//       {
//         authUserId: 2,
//         nameFirst: 'Sophia',
//         nameLast: 'Magirang',
//         email: 'sophia@gmail.com',
//         password: '123testing',
//         numSuccesfulLogins: 1,
//         numFailedPasswordsSinceLastLogin: 0,
//         quizOwn: [1],
//         passwordLog: ["oldPassword"]
//       }
//     ],
//   });
// }

describe('adminAuthLogout', () => {
  let login: any;
  beforeEach(() => {
    adminAuthRegister('faren@gmail.com', 'testing123', 'Faren', 'Lesmana');
    login = adminAuthLogin('faren@gmail.com', 'testing123');
  });

  test('Error for invalid user ID', () => {
    const result = adminAuthLogout(999);
    expect(result.error).toBe('AuthUserId is not a valid user');
  });

  test('Succesful', () => {
    const result = adminAuthLogout(login.id);
    expect(result).toBe({});
  });
});
