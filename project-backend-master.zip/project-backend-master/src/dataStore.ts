// YOU SHOULD MODIFY THIS OBJECT BELOW
import fs from 'fs';
// let data = {
//   users: [],
//   quizzes: [],
// };

// export interface Data {
//   users: User[];
//   quizzes: Quiz[];
// }
type Answer = {
  answerId: number,
  answer: string,
  colour: string,
  correct: boolean

}

type token = {
  sessionId: string
}

type Session = {
  token: token,
  authUserId: number,
  active: boolean,
}

type Question = {
    questionId: number,
    question: string,
    duration: number,
    points: number,
    answers: Answer[],
    correct: boolean,
    newPosition: number,
};

type Quiz = {
  authUserId: number,
  quizId: number,
  name: string,
  timeCreated: number,
  timeLastEdited: number,
  description: string,
  numQuestions: 0,
  questions: Question[],
  duration: number
};

type User = {
    authUserId: number,
    email: string;
    password: string;
    nameFirst: string;
    nameLast: string;
    numSuccesfulLogins: number;
    numFailedPasswordsSinceLastLogin: number;
    quizOwn: Quiz[];
    passwordLog: string[];
};

type TooKah = {
  users: User[],
  quizzes: Quiz[],
  quizTrash: Quiz[],
  sessions: Session[],
  counter: number
};

let data : TooKah = {
  users: [],
  quizzes: [],
  quizTrash: [],
  sessions: [],
  counter: 0
};

const databasefile = './datastore.json';
const load = (databasefile: string) => {
  const datastr = fs.readFileSync(databasefile);
  data = JSON.parse(String(datastr));
};

const save = (databasefile: string) => {
  fs.writeFileSync(databasefile, JSON.stringify(data));
};

const getData = () => {
  load(databasefile);
  return data;
};

const setData = (newData: TooKah) => {
  data = newData;
  save(databasefile);
  return {};
};

// YOU SHOULDNT NEED TO MODIFY THE FUNCTIONS BELOW IN ITERATION 1

/*
Example usage
    let store = getData()
    console.log(store) # Prints { 'names': ['Hayden', 'Tam', 'Rani', 'Giuliana', 'Rando'] }

    names = store.names

    names.pop()
    names.push('Jake')

    console.log(store) # Prints { 'names': ['Hayden', 'Tam', 'Rani', 'Giuliana', 'Jake'] }
    setData(store)
*/

// Use get() to access the data
// function getData(): Data {
//   return data;
// }

// // Use set(newData) to pass in the entire data object, with modifications made
// function setData(newData: Data): void {
//   data = newData;
// }
// function setQuizzesData(newdataQuizzes: Quiz[]): void {
//   return newdataQuizzes;
// }

export { getData, setData, save, load, User, Question, Quiz, TooKah, Session, Answer };
